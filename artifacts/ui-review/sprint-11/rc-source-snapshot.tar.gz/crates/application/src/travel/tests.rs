//! TravelResearchService 集成测试（Mock 全依赖，不触网，需求 #二十五）。

use std::sync::{Arc, Mutex};

use devtoolbox_core::travel::{
    CityGuide, CityInfo, FactCategory, GuideMeta, MapCoordinates, ResearchPhase, StepStatus,
    TravelDateRange, TravelFact, TravelResearchEvent,
};

use crate::travel::mocks::{
    MockChatProvider, MockDataProvider, MockSearchProvider, MockWebFetcher, search_result,
};
use crate::travel::ports::TravelStorePort;
use devtoolbox_core::travel::{SearchResult, TravelDocument};

/// 内存版 Travel 存储（Gate 8：测试不再依赖 SQLite；语义与 SQLite 缓存一致）。
#[derive(Default)]
pub struct FakeTravelStore {
    guides: std::sync::Mutex<std::collections::HashMap<(String, u8), CityGuide>>,
    search_results: std::sync::Mutex<std::collections::HashMap<String, Vec<SearchResult>>>,
    documents: std::sync::Mutex<std::collections::HashMap<String, TravelDocument>>,
}

impl TravelStorePort for FakeTravelStore {
    fn get_guide(&self, city: &str, days: u8, _now: i64) -> Result<Option<CityGuide>, String> {
        let guides = self.guides.lock().expect("guides poisoned");
        Ok(guides.get(&(city.to_string(), days)).cloned())
    }

    fn upsert_guide(&self, guide: &CityGuide, now: i64) -> Result<CityGuide, String> {
        let mut stored = guide.clone();
        stored.meta.updated_at = now;
        self.guides
            .lock()
            .expect("guides poisoned")
            .insert((stored.city.name.clone(), stored.meta.days), stored.clone());
        Ok(stored)
    }

    fn get_search_results(
        &self,
        query: &str,
        _now: i64,
    ) -> Result<Option<Vec<SearchResult>>, String> {
        let results = self.search_results.lock().expect("search poisoned");
        Ok(results.get(query).cloned())
    }

    fn put_search_results(
        &self,
        query: &str,
        results: &[SearchResult],
        _now: i64,
    ) -> Result<(), String> {
        self.search_results
            .lock()
            .expect("search poisoned")
            .insert(query.to_string(), results.to_vec());
        Ok(())
    }

    fn get_document(&self, url: &str, _now: i64) -> Result<Option<TravelDocument>, String> {
        let documents = self.documents.lock().expect("documents poisoned");
        Ok(documents.get(url).cloned())
    }

    fn put_document(&self, document: &TravelDocument, _now: i64) -> Result<(), String> {
        self.documents
            .lock()
            .expect("documents poisoned")
            .insert(document.url.clone(), document.clone());
        Ok(())
    }
}
use crate::travel::service::TravelResearchService;
use crate::{ApplicationError, travel::TravelResearchRequest};

fn request(city: &str) -> TravelResearchRequest {
    TravelResearchRequest {
        city: city.to_string(),
        natural_language: None,
        today: None,
        arrival: None,
        departure: None,
        days: 3,
        month: None,
        date_range: None,
        preferences: vec![],
        force: false,
    }
}

fn fushun_request() -> TravelResearchRequest {
    TravelResearchRequest {
        city: "抚顺".to_string(),
        natural_language: None,
        today: None,
        arrival: None,
        departure: None,
        days: 2,
        month: Some(9),
        date_range: Some(TravelDateRange {
            start: "2026-09-05".to_string(),
            end: "2026-09-06".to_string(),
        }),
        preferences: vec!["历史".to_string(), "美食".to_string(), "自然".to_string()],
        force: true,
    }
}

/// 构造服务 + 事件收集器。
fn harness(
    providers: Vec<Box<dyn devtoolbox_core::travel::SearchProvider>>,
    fetcher: Box<dyn devtoolbox_core::travel::WebFetcher>,
    llm: Option<Arc<dyn devtoolbox_core::personal_ai::ChatModelProvider>>,
) -> (TravelResearchService, Arc<Mutex<Vec<TravelResearchEvent>>>) {
    harness_with_data(providers, fetcher, llm, Vec::new())
}

/// 构造服务 + 事件收集器（带结构化数据 Provider）。
fn harness_with_data(
    providers: Vec<Box<dyn devtoolbox_core::travel::SearchProvider>>,
    fetcher: Box<dyn devtoolbox_core::travel::WebFetcher>,
    llm: Option<Arc<dyn devtoolbox_core::personal_ai::ChatModelProvider>>,
    data_providers: Vec<Box<dyn devtoolbox_core::travel::TravelDataProvider>>,
) -> (TravelResearchService, Arc<Mutex<Vec<TravelResearchEvent>>>) {
    let store: Arc<dyn TravelStorePort> = Arc::new(FakeTravelStore::default());
    let events: Arc<Mutex<Vec<TravelResearchEvent>>> = Arc::new(Mutex::new(Vec::new()));
    let service = TravelResearchService::new(providers, fetcher, llm, data_providers, store);
    (service, events)
}

fn guide_json(summary: &str) -> String {
    format!(
        r#"{{"city": {{"name": "杭州", "name_en": "Hangzhou"}}, "summary": "{summary}", "highlights": ["西湖"]}}"#
    )
}

fn facts_json(official: bool) -> String {
    if official {
        r#"[{"category":"opening_hours","subject":"西湖","value":"07:00-18:00","confidence":0.9}]"#
            .to_string()
    } else {
        r#"[{"category":"opening_hours","subject":"西湖","value":"08:00-17:00","confidence":0.9}]"#
            .to_string()
    }
}

/// 默认 happy path 依赖：1 个搜索 Provider + 1 个抓取器 + LLM 队列。
/// happy provider 产生 2 个文档 → 队列 = [扩展, 事实(文档1), 事实(文档2), 攻略]。
fn happy_llm_queue() -> MockChatProvider {
    MockChatProvider::new([
        r#"["杭州 宋韵文化体验"]"#.to_string(),
        facts_json(true),
        r#"[{"category":"food","subject":"龙井虾仁","value":"杭帮菜经典"}]"#.to_string(),
        guide_json("西湖列世界遗产，免费开放，建议游玩一天。").to_string(),
    ])
}

const OFFICIAL_URL: &str = "https://hz.gov.cn/westlake";
const PLATFORM_URL: &str = "https://you.ctrip.com/hangzhou";

fn happy_provider() -> MockSearchProvider {
    MockSearchProvider::new(
        "mock",
        vec![
            search_result(
                OFFICIAL_URL,
                "杭州西湖 官方介绍",
                "西湖是世界文化遗产，全天开放。",
            ),
            search_result(PLATFORM_URL, "杭州 三日游攻略", "路线与美食推荐。"),
        ],
    )
}

fn happy_fetcher() -> MockWebFetcher {
    MockWebFetcher::new()
        .with_page(
            OFFICIAL_URL,
            "西湖景区",
            "西湖位于杭州，是著名景点。开放时间 07:00-18:00。",
        )
        .with_page(PLATFORM_URL, "杭州攻略", "推荐西湖、灵隐寺，三日游路线。")
}

#[tokio::test]
async fn full_research_produces_structured_guide() {
    let (service, events) = harness(
        vec![Box::new(happy_provider())],
        Box::new(happy_fetcher()),
        Some(Arc::new(happy_llm_queue())),
    );
    let collector = events.clone();
    let guide = service
        .research_city(&request("杭州"), &move |event| {
            collector.lock().expect("poisoned").push(event);
        })
        .await
        .expect("research")
        .guide;

    assert_eq!(guide.city.name, "杭州");
    assert_eq!(guide.city.name_en.as_deref(), Some("Hangzhou"));
    assert!(guide.summary.contains("西湖"));
    assert_eq!(guide.highlights, vec!["西湖"]);
    assert!(guide.meta.llm_used);
    assert_eq!(guide.meta.days, 3);
    // LLM 攻略 + 程序验证合并：开放时间应落到景点上（官方来源优先）
    let westlake = guide
        .attractions
        .iter()
        .find(|a| a.name.contains("西湖"))
        .or_else(|| guide.attractions.first());
    if let Some(attraction) = westlake
        && let Some(hours) = &attraction.opening_hours
    {
        assert_eq!(hours.value, "07:00-18:00");
    }
    // 来源应完整保留
    assert!(
        guide.sources.len() >= 2,
        "sources: {:?}",
        guide.sources.len()
    );
    // 进度事件完整
    let locked = events.lock().expect("poisoned");
    assert!(
        locked
            .iter()
            .any(|e| e.phase == ResearchPhase::PlanQueries && e.status == StepStatus::Done)
    );
    assert!(
        locked
            .iter()
            .any(|e| e.phase == ResearchPhase::FetchDocuments && e.status == StepStatus::Done)
    );
    assert!(
        locked
            .iter()
            .any(|e| e.phase == ResearchPhase::SaveGuide && e.status == StepStatus::Done)
    );
    assert!(locked.iter().any(|e| e.seq > 0));
    // 攻略已落库
    drop(locked);
}

#[tokio::test]
async fn provider_failure_falls_back_to_secondary() {
    let mut primary = MockSearchProvider::new("primary", vec![]);
    primary
        .errors
        .insert("*".to_string(), "waf blocked".to_string());
    let secondary = MockSearchProvider::new(
        "secondary",
        vec![search_result(OFFICIAL_URL, "杭州 介绍", "snippet")],
    );
    let secondary_calls = secondary.calls.clone();
    let (service, _events) = harness(
        vec![Box::new(primary), Box::new(secondary)],
        Box::new(happy_fetcher()),
        None,
    );
    let guide = service
        .research_city(&request("杭州"), &|_| {})
        .await
        .expect("research with fallback")
        .guide;
    // 主 Provider 全挂时备选 Provider 顶上，研究仍成功
    assert!(!guide.sources.is_empty());
    assert!(!secondary_calls.lock().expect("poisoned").is_empty());
}

#[tokio::test]
async fn all_providers_failing_fails_research() {
    let mut failing = MockSearchProvider::new("broken", vec![]);
    failing.errors.insert("*".to_string(), "down".to_string());
    let (service, events) = harness(
        vec![Box::new(failing)],
        Box::new(MockWebFetcher::new()),
        None,
    );
    let collector = events.clone();
    let result = service
        .research_city(&request("杭州"), &move |event| {
            collector.lock().expect("poisoned").push(event);
        })
        .await;
    assert!(matches!(result, Err(ApplicationError::TravelFailed(_))));
}

#[tokio::test]
async fn partial_page_failures_keep_snippets() {
    let provider = MockSearchProvider::new(
        "mock",
        vec![
            search_result("https://a.gov.example", "官方A", "摘要A 开放时间"),
            search_result("https://b.example", "站点B", "摘要B 美食"),
        ],
    );
    let fetcher = MockWebFetcher::new()
        .with_page("https://a.gov.example", "官方A", "A 的正文内容。")
        .with_error("https://b.example", "403 forbidden");
    let llm = MockChatProvider::new([
        "[\"杭州 补充主题\"]".to_string(),
        r#"[{"category":"attraction","subject":"A","value":"介绍"}]"#.to_string(),
        r#"[{"category":"food","subject":"B","value":"小吃"}]"#.to_string(),
        guide_json("部分页面不可用。").to_string(),
    ]);
    let (service, _events) = harness(
        vec![Box::new(provider)],
        Box::new(fetcher),
        Some(Arc::new(llm)),
    );
    let guide = service
        .research_city(&request("杭州"), &|_| {})
        .await
        .expect("partial success")
        .guide;
    // 失败页面仍以「仅摘要」出现在来源里
    let snippet_source = guide
        .sources
        .iter()
        .find(|s| s.url == "https://b.example")
        .expect("snippet source kept");
    assert_eq!(
        snippet_source.state,
        devtoolbox_core::travel::ContentState::SnippetOnly
    );
    assert!(guide.meta.notes.iter().any(|n| n.contains("未能抓取全文")));
}

#[tokio::test]
async fn llm_failure_falls_back_to_sources_only() {
    let llm = MockChatProvider::new(["ERR:service unavailable".to_string()]);
    let (service, _events) = harness(
        vec![Box::new(happy_provider())],
        Box::new(happy_fetcher()),
        Some(Arc::new(llm)),
    );
    let guide = service
        .research_city(&request("杭州"), &|_| {})
        .await
        .expect("research keeps working without llm")
        .guide;
    assert!(!guide.meta.llm_used);
    assert!(!guide.sources.is_empty());
    // 降级说明写入 notes，不编造 AI 内容：summary 为降级文案
    assert!(
        guide.summary.contains("暂无 AI 整理")
            || guide.meta.notes.iter().any(|n| n.contains("降级"))
    );
}

#[tokio::test]
async fn no_llm_configured_still_returns_sources() {
    let (service, events) = harness(
        vec![Box::new(happy_provider())],
        Box::new(happy_fetcher()),
        None,
    );
    let collector = events.clone();
    let guide = service
        .research_city(&request("杭州"), &move |event| {
            collector.lock().expect("poisoned").push(event);
        })
        .await
        .expect("research without llm")
        .guide;
    assert!(!guide.meta.llm_used);
    assert!(guide.sources.len() >= 2);
    assert!(guide.meta.notes.iter().any(|n| n.contains("未配置 LLM")));
    let locked = events.lock().expect("poisoned");
    assert!(
        locked
            .iter()
            .any(|e| e.phase == ResearchPhase::ExtractFacts && e.status == StepStatus::Skipped)
    );
}

#[tokio::test]
async fn illegal_llm_json_is_tolerated() {
    // happy provider 产生 2 个文档 → 队列 = [扩展, 非JSON(文档1), 事实(文档2), 攻略]
    let llm = MockChatProvider::new([
        "[\"杭州 补充\"]".to_string(),
        "not json at all".to_string(),
        r#"[{"category":"food","subject":"龙井虾仁","value":"杭帮菜"}]"#.to_string(),
        guide_json("攻略依然生成。").to_string(),
    ]);
    let (service, _events) = harness(
        vec![Box::new(happy_provider())],
        Box::new(happy_fetcher()),
        Some(Arc::new(llm)),
    );
    let guide = service
        .research_city(&request("杭州"), &|_| {})
        .await
        .expect("illegal json tolerated")
        .guide;
    assert!(guide.meta.llm_used, "guide 由 LLM 生成");
    assert_eq!(guide.summary, "攻略依然生成。");
    // LLM 攻略里没有龙井虾仁，但合并层应把已验证事实补进去（food 类暂不强制，至少不报错）
    assert!(guide.meta.notes.iter().any(|n| n.contains("提取失败")));
}

#[tokio::test]
async fn conflicting_facts_resolve_by_authority() {
    let provider = MockSearchProvider::new(
        "mock",
        vec![
            search_result(OFFICIAL_URL, "官方发布", "官方 开放时间"),
            search_result(PLATFORM_URL, "平台攻略", "平台 开放时间"),
        ],
    );
    let fetcher = MockWebFetcher::new()
        .with_page(OFFICIAL_URL, "西湖景区-官方", "开放时间 07:00-18:00。")
        .with_page(PLATFORM_URL, "西湖景区-平台", "开放时间 08:00-17:00。");
    // 官方文档在前（权重更高 → 排在抓取队列前面）
    let llm = MockChatProvider::new([
        "[]".to_string(),
        facts_json(true).to_string(),
        facts_json(false).to_string(),
        r#"{"city":{"name":"杭州"},"attractions":[{"name":"西湖"}]}"#.to_string(),
    ]);
    let (service, _events) = harness(
        vec![Box::new(provider)],
        Box::new(fetcher),
        Some(Arc::new(llm)),
    );
    let guide = service
        .research_city(&request("杭州"), &|_| {})
        .await
        .expect("conflict resolved")
        .guide;
    let attraction = guide
        .attractions
        .iter()
        .chain(guide.alternatives.iter())
        .find(|a| a.name.contains("西湖"))
        .expect("西湖 attraction");
    let hours = attraction
        .opening_hours
        .as_ref()
        .expect("verified hours merged");
    assert_eq!(hours.value, "07:00-18:00", "官方来源应优先");
    assert_eq!(hours.primary_source, "official");
    assert!(hours.has_conflict, "存在两个版本应标记冲突");
    assert!(guide.meta.notes.iter().any(|n| n.contains("多个来源版本")));
}

#[tokio::test]
async fn cache_hit_skips_network() {
    let store: Arc<dyn TravelStorePort> = Arc::new(FakeTravelStore::default());
    let now = crate::time::now_unix();
    let cached_guide = CityGuide {
        city: CityInfo {
            name: "杭州".to_string(),
            ..CityInfo::default()
        },
        meta: GuideMeta {
            generated_at: now,
            updated_at: now,
            days: 3,
            date_range: None,
            llm_used: true,
            notes: vec!["缓存测试".to_string()],
        },
        summary: "缓存中的攻略".to_string(),
        ..CityGuide::default()
    };
    store.upsert_guide(&cached_guide, now).expect("seed cache");

    let cache_hit_provider = MockSearchProvider::new("should-not-be-called", vec![]);
    let service = TravelResearchService::new(
        vec![Box::new(cache_hit_provider)],
        Box::new(MockWebFetcher::new()),
        None,
        Vec::new(),
        store,
    );
    let outcome = service
        .research_city(&request("杭州"), &|_| {})
        .await
        .expect("cache hit");
    // Gate 7：缓存决策是结构化字段，不依赖事件文案匹配。
    assert!(outcome.from_cache);
    assert_eq!(outcome.guide.summary, "缓存中的攻略");
}

#[tokio::test]
async fn empty_city_is_rejected() {
    let (service, _events) = harness(
        vec![Box::new(MockSearchProvider::new("mock", vec![]))],
        Box::new(MockWebFetcher::new()),
        None,
    );
    let result = service.research_city(&request("  "), &|_| {}).await;
    assert!(matches!(result, Err(ApplicationError::EmptyCity)));
}

#[tokio::test]
async fn no_search_results_fails_cleanly() {
    let (service, _events) = harness(
        vec![Box::new(MockSearchProvider::new("empty", vec![]))],
        Box::new(MockWebFetcher::new()),
        None,
    );
    let result = service.research_city(&request("杭州"), &|_| {}).await;
    assert!(matches!(result, Err(ApplicationError::TravelFailed(_))));
}

#[tokio::test]
async fn parse_query_list_handles_json_and_lines() {
    let json = r#"["杭州 宋韵", "杭州 秋季赏桂"]"#;
    let parsed = crate::travel::service::parse_query_list(json);
    assert_eq!(parsed.len(), 2);
    assert_eq!(parsed[0], "杭州 宋韵");

    let lines = "- 杭州 徒步路线\n- 杭州 骑行\n";
    let parsed = crate::travel::service::parse_query_list(lines);
    assert_eq!(parsed.len(), 2);
}

#[test]
fn structured_search_intents_are_validated_and_categorized() {
    let raw = r#"[{"query":"抚顺 历史与文化体验","category":"culture_history","purpose":"补足历史偏好","priority":0.8},{"query":"抚顺 随便","category":"not_a_category"},{"query":"外地 景点","category":"nature"}]"#;
    let intents = crate::travel::service::parse_search_intents(raw, "抚顺");
    assert_eq!(intents.len(), 1);
    assert_eq!(
        intents[0].intent,
        devtoolbox_core::travel::SearchIntentCategory::CultureHistory
    );
    assert_eq!(
        intents[0].category,
        devtoolbox_core::travel::QueryCategory::Attractions
    );
    assert_eq!(intents[0].priority, 0.8);
}

#[tokio::test]
async fn fushun_two_day_guide_is_curated_and_deduplicated() {
    let provider = MockSearchProvider::new(
        "mock",
        vec![search_result(
            "https://fushun.example/guide",
            "抚顺旅行资料",
            "景点与路线",
        )],
    );
    let fetcher = MockWebFetcher::new().with_page(
        "https://fushun.example/guide",
        "抚顺旅行资料",
        "抚顺景点、历史、美食与自然路线。",
    );
    let attractions = [
        ("萨尔浒风景名胜区", "自然山水，适合半日游。"),
        ("萨尔浒风景区", "自然山水，适合半日游。"),
        ("清永陵", "满清历史遗存，适合历史偏好。"),
        ("赫图阿拉城", "可以集中了解满族历史。"),
        ("抚顺市博物馆", "适合用一小时了解城市历史。"),
        ("西露天矿", "工业遗产景观，适合摄影。"),
        ("劳动公园", "市区内的轻松散步点。"),
    ];
    let attraction_json = attractions
        .iter()
        .map(|(name, why)| format!(r#"{{"name":"{name}","why_go":"{why}","why_for_this_trip":"与两天路线匹配","area":"市区","suggested_duration":"2 小时","best_for":["历史"],"source_ids":[]}}"#))
        .collect::<Vec<_>>()
        .join(",");
    let guide_json = format!(
        r#"{{"city":{{"name":"抚顺"}},"summary":"工业历史与满族文化，配合东北本地美食。","attractions":[{attraction_json}],"accommodation_areas":[{{"name":"新抚区","note":"市区交通方便"}},{{"name":"顺城区"}},{{"name":"东洲区"}},{{"name":"不应展示的区域"}}],"restaurants":[{{"name":"本地麻辣拌","area":"新抚区"}}]}}"#
    );
    let llm = MockChatProvider::new(["[]".to_string(), "[]".to_string(), guide_json]);
    let (service, _events) = harness(
        vec![Box::new(provider)],
        Box::new(fetcher),
        Some(Arc::new(llm)),
    );
    let guide = service
        .research_city(&fushun_request(), &|_| {})
        .await
        .expect("fushun guide")
        .guide;
    assert_eq!(guide.meta.days, 2);
    assert!(guide.attractions.len() <= 6);
    assert_eq!(guide.itinerary_days.len(), 2);
    assert!(guide.attractions.iter().all(|item| item.why_go.is_some()
        && item.suggested_duration.is_some()
        && item.area.is_some()));
    assert!(
        guide
            .attractions
            .iter()
            .filter(|item| item.name.contains("萨尔浒"))
            .count()
            <= 1
    );
    assert!(guide.accommodation_areas.len() <= 3);
    assert!(
        !guide
            .attractions
            .iter()
            .any(|item| item.why_go.as_deref() == Some("抚顺旅游必去景点推荐"))
    );
}

fn amap_fact(category: FactCategory, subject: &str, value: &str) -> TravelFact {
    TravelFact {
        category,
        subject: subject.to_string(),
        value: value.to_string(),
        source_id: "https://restapi.amap.com".to_string(),
        confidence: 0.8,
        fetched_at: 1_700_000_000,
        coordinates: (category == FactCategory::Attraction).then_some(MapCoordinates {
            longitude: 120.134,
            latitude: 30.211,
        }),
        poi_id: None,
        area: None,
        address: None,
    }
}

#[tokio::test]
async fn data_provider_facts_enrich_guide_and_sources() {
    // 模拟高德 POI + 和风天气：填入钥匙才有这些事实（未配置时 providers 为空，见其他用例）
    let data = MockDataProvider::new("amap-poi")
        .with_facts(
            "poi",
            vec![
                amap_fact(FactCategory::Attraction, "龙井村", "西湖区 龙井路"),
                amap_fact(FactCategory::Food, "龙井虾仁", "西湖区 特色菜"),
            ],
        )
        .with_facts(
            "weather",
            vec![TravelFact {
                category: FactCategory::Weather,
                subject: "杭州天气".to_string(),
                value: "2026-09-01 晴 24~33°C；2026-09-02 多云 25~32°C".to_string(),
                source_id: "https://devapi.qweather.com".to_string(),
                confidence: 0.9,
                fetched_at: 1_700_000_000,
                coordinates: None,
                poi_id: None,
                area: None,
                address: None,
            }],
        );
    let llm = MockChatProvider::new([
        "[]".to_string(),
        r#"[]"#.to_string(),
        r#"[]"#.to_string(),
        r#"{"city":{"name":"杭州"},"summary":"基本攻略"}"#.to_string(),
    ]);
    let (service, _events) = harness_with_data(
        vec![Box::new(happy_provider())],
        Box::new(happy_fetcher()),
        Some(Arc::new(llm)),
        vec![Box::new(data)],
    );
    let guide = service
        .research_city(&request("杭州"), &|_| {})
        .await
        .expect("research with data providers")
        .guide;
    // 只有经过编辑补齐理由/时长/区域的条目进入主推荐；裸 POI 作为备选保留
    assert!(
        guide.alternatives.iter().any(|a| a.name.contains("龙井村")),
        "alternatives: {:?}",
        guide.alternatives
    );
    assert!(guide.foods.iter().any(|f| f.name.contains("龙井虾仁")));
    assert!(
        guide
            .alternatives
            .iter()
            .find(|item| item.name.contains("龙井村"))
            .and_then(|item| item.coordinates.as_ref())
            .is_some()
    );
    // 和风天气进入独立天气卡片数据。
    let weather = guide.weather.expect("weather card data");
    assert_eq!(weather.days.len(), 2);
    assert_eq!(weather.days[0].text_day, "晴");
    // 数据源作为可信来源出现在 Sources（A 级）
    let amap_source = guide
        .sources
        .iter()
        .find(|s| s.url == "https://restapi.amap.com")
        .expect("amap source listed");
    assert_eq!(amap_source.level, devtoolbox_core::travel::SourceLevel::A);
    assert!(guide.meta.notes.iter().any(|n| n.contains("已接入数据源")));
    // 数据源标题使用人类可读标签
    assert!(
        guide
            .sources
            .iter()
            .any(|s| s.title.contains("高德地图 POI"))
    );
}

#[tokio::test]
async fn amap_poi_fallback_keeps_fushun_itinerary_and_restaurants_readable() {
    let poi = vec![
        TravelFact {
            category: FactCategory::Attraction,
            subject: "萨尔浒风景区".to_string(),
            value: "东洲区 景区路".to_string(),
            source_id: "https://restapi.amap.com".to_string(),
            confidence: 0.8,
            fetched_at: 1_700_000_000,
            coordinates: Some(MapCoordinates {
                longitude: 124.2,
                latitude: 41.9,
            }),
            poi_id: Some("poi-sah".to_string()),
            area: Some("东洲区".to_string()),
            address: Some("景区路".to_string()),
        },
        TravelFact {
            category: FactCategory::Attraction,
            subject: "抚顺市博物馆".to_string(),
            value: "新抚区 迎宾路".to_string(),
            source_id: "https://restapi.amap.com".to_string(),
            confidence: 0.8,
            fetched_at: 1_700_000_000,
            coordinates: Some(MapCoordinates {
                longitude: 123.9,
                latitude: 41.88,
            }),
            poi_id: Some("poi-museum".to_string()),
            area: Some("新抚区".to_string()),
            address: Some("迎宾路".to_string()),
        },
        TravelFact {
            category: FactCategory::Food,
            subject: "二中正宗四川麻辣拌（城东店）".to_string(),
            value: "顺城区 裕城路".to_string(),
            source_id: "https://restapi.amap.com".to_string(),
            confidence: 0.8,
            fetched_at: 1_700_000_000,
            coordinates: Some(MapCoordinates {
                longitude: 123.91,
                latitude: 41.88,
            }),
            poi_id: Some("poi-food".to_string()),
            area: Some("顺城区".to_string()),
            address: Some("裕城路".to_string()),
        },
    ];
    let data = MockDataProvider::new("amap-poi").with_facts("poi", poi);
    let (service, _events) = harness_with_data(
        vec![Box::new(happy_provider())],
        Box::new(happy_fetcher()),
        None,
        vec![Box::new(data)],
    );
    let guide = service
        .research_city(&fushun_request(), &|_| {})
        .await
        .expect("fallback guide")
        .guide;

    assert!(!guide.meta.llm_used);
    assert!(!guide.attractions.is_empty());
    assert_eq!(guide.itinerary_days.len(), 2);
    assert!(guide.itinerary_days.iter().any(|day| !day.stops.is_empty()));
    assert!(!guide.restaurants.is_empty());
    assert!(
        guide
            .food_summary
            .as_deref()
            .is_none_or(|text| !text.contains("裕城路"))
    );
    assert!(guide.restaurants[0].route_day.is_some());
    assert!(guide.restaurants[0].distance_to_route.is_some());
    assert!(guide.attractions.iter().all(|item| {
        item.why_go.is_some() && item.suggested_duration.as_deref() == Some("待确认")
    }));
}

#[tokio::test]
async fn data_provider_failure_is_partial_success() {
    let data = MockDataProvider::new("amap-poi").with_error("poi", "invalid key");
    let (service, events) = harness_with_data(
        vec![Box::new(happy_provider())],
        Box::new(happy_fetcher()),
        None,
        vec![Box::new(data)],
    );
    let collector = events.clone();
    let guide = service
        .research_city(&request("杭州"), &move |event| {
            collector.lock().expect("poisoned").push(event);
        })
        .await
        .expect("data provider failure must not abort research")
        .guide;
    assert!(!guide.sources.is_empty());
    assert!(
        guide
            .meta
            .notes
            .iter()
            .any(|n| n.contains("数据源") && n.contains("失败"))
    );
    let locked = events.lock().expect("poisoned");
    assert!(
        locked
            .iter()
            .any(|e| e.phase == ResearchPhase::DataSources && e.status == StepStatus::Failed)
    );
}

#[tokio::test]
async fn without_data_keys_providers_skipped() {
    // 未配置 Key → 无数据 Provider → 阶段跳过，攻略照常
    let (service, events) = harness(
        vec![Box::new(happy_provider())],
        Box::new(happy_fetcher()),
        None,
    );
    let collector = events.clone();
    let guide = service
        .research_city(&request("杭州"), &move |event| {
            collector.lock().expect("poisoned").push(event);
        })
        .await
        .expect("research without keys")
        .guide;
    assert!(!guide.sources.is_empty());
    assert!(
        guide
            .meta
            .notes
            .iter()
            .any(|n| n.contains("未配置数据源 Key"))
    );
    let locked = events.lock().expect("poisoned");
    assert!(
        locked
            .iter()
            .any(|e| e.phase == ResearchPhase::DataSources && e.status == StepStatus::Skipped)
    );
}

#[tokio::test]
async fn llm_transport_failure_stops_remaining_requests() {
    // 查询扩展成功后，第一个事实抽取发生传输错误；不应继续对每个文档重试，
    // 也不应在最后再发一次必然失败的攻略生成请求。
    let llm = MockChatProvider::new([
        "[]".to_string(),
        "ERR:error decoding response body".to_string(),
    ]);
    let calls = llm.calls.clone();
    let (service, _events) = harness(
        vec![Box::new(happy_provider())],
        Box::new(happy_fetcher()),
        Some(Arc::new(llm)),
    );
    let guide = service
        .research_city(&request("杭州"), &|_| {})
        .await
        .expect("fallback guide")
        .guide;
    assert_eq!(
        *calls.lock().expect("calls"),
        2,
        "stop after first transport failure"
    );
    assert!(
        guide
            .meta
            .notes
            .iter()
            .any(|note| note.contains("停止本次剩余 LLM 请求"))
    );
    assert!(!guide.meta.llm_used);
}

// ---------------------------------------------------------------------------
// V5 §67：Provider 迁移行为冻结 —— travel 经 ChatModelProvider 后错误语义不变。
// ---------------------------------------------------------------------------

/// travel_complete 产生的错误必须保留 `travel llm request failed: …` 前缀，
/// `is_llm_transport_error` 判定与迁移前一致（模型 Provider 统一不改用户体验）。
#[tokio::test]
async fn llm_error_prefix_frozen_after_provider_migration() {
    let llm = Arc::new(MockChatProvider::new([
        "ERR:service unavailable".to_string()
    ]));
    let error = crate::travel::service::travel_complete(llm.as_ref(), "s", "u")
        .await
        .unwrap_err();
    assert!(
        error.starts_with("travel llm request failed: "),
        "prefix lost: {error}"
    );
    assert!(crate::travel::service::is_llm_transport_error(&error));
}

/// 模型返回空内容 → 受控错误（也是 `travel llm request failed` 语义）。
#[tokio::test]
async fn travel_complete_empty_content_is_controlled_error() {
    let llm = Arc::new(MockChatProvider::new(["".to_string()]));
    // 空字符串仍视为有效内容（与迁移前一致：模型输出空串由 parse 层决定）。
    let ok = crate::travel::service::travel_complete(llm.as_ref(), "s", "u").await;
    assert!(ok.is_ok());
}

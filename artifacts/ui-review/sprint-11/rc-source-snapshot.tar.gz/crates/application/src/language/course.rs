//! 英语课程学习服务（NCE 主课程的应用层编排）。
//!
//! 分工：
//! - 课程内容（Course/Book/Lesson/Sentence/Vocab）→ `CourseStorePort`（本文件端口）
//! - 单词 SRS / 掌握度 / 复习排期 → 平台 `LearningService`（不在此复制）
//! - 词典查询 → `DictionaryService`（业务页不直接碰 ECDICT 存储）
//!
//! 所有 id 稳定：`nce:{book}:{lesson}` / `language:word:en:{lemma}`，重导入不丢进度。

use std::sync::Arc;

use serde::{Deserialize, Serialize};

use devtoolbox_core::language::{
    BookSummary, CheckKind, Course, CourseBook, CourseLesson, LearningPlan, LessonListEntry,
    LessonProgress, LessonSentence, LessonStage, LessonVocab, MinedCard, MinedCardKind, QuizAnswer,
    QuizItem, QuizResult, ROADMAP, RoadmapMetrics, RoadmapWeek, ShadowAttempt, ShadowStats,
    WordEntry, WordMark, WordOccurrence, mine_lesson, mined_card_id, summarize_shadow_attempts,
};
use devtoolbox_core::learning::{
    LearningAction, LearningEvent, LearningProgress, LearningStatus, ReviewCardType, ReviewRating,
    UniversalReviewCard,
};

use crate::error::ApplicationError;
use crate::learning::ports::LearningPortError;
use crate::learning::service::LearningService;

/// Language 模块在平台学习库里的 module 名（与 learning.rs 保持一致）。
const MODULE: &str = "language";

fn err(message: String) -> ApplicationError {
    ApplicationError::Language { message }
}

fn platform(error: LearningPortError) -> ApplicationError {
    err(error.to_string())
}

/// 数据现状：用户打开「导入」时最想知道的三个问题——
/// 教材在哪、词典在哪、缺什么。
#[derive(Clone, Debug, Serialize)]
pub struct DataStatus {
    /// 用户数据目录（教材/音频落地位置）。
    pub data_dir: String,
    /// 已导入教材的**来源目录**（首次导入时记下，之后界面直接显示）。
    pub nce_source: Option<String>,
    /// 已导入课程概览（册数 / 课时数 / 音频数）。
    pub nce_books: usize,
    pub nce_lessons: usize,
    pub nce_lessons_with_audio: usize,
    /// 已导入词典词条数。
    pub dict_entries: i64,
}

/// 返回数据现状（只读，不改任何数据）。
///
/// 泛型接受任何 [`CourseStorePort`] 实现——应用层不依赖 infrastructure 的具体 store。
pub fn data_status(store: &dyn CourseStorePort, data_dir: &std::path::Path) -> DataStatus {
    let books = store.courses().unwrap_or_default();
    let nce_books = books.iter().filter(|course| course.code == "nce").count();
    let mut nce_lessons = 0usize;
    let mut with_audio = 0usize;
    for course in books.iter().filter(|course| course.code == "nce") {
        for book in store.course_books(&course.id).unwrap_or_default() {
            for entry in store.book_lessons(&book.id).unwrap_or_default() {
                nce_lessons += 1;
                if entry.lesson.audio_path.is_some() {
                    with_audio += 1;
                }
            }
        }
    }
    // 源目录在导入时记进计划（只用于界面显示「你的教材在哪」）。
    let source = store
        .learning_plan("eng")
        .ok()
        .flatten()
        .and_then(|plan| plan.nce_source_dir);
    DataStatus {
        data_dir: data_dir.display().to_string(),
        nce_source: source,
        nce_books,
        nce_lessons,
        nce_lessons_with_audio: with_audio,
        dict_entries: store.dict_count().unwrap_or(0),
    }
}

// ============================================================================
// 端口
// ============================================================================

/// 课程存储端口（实现 = infrastructure `LanguageStore` 的 course 部分）。
pub trait CourseStorePort: Send + Sync {
    fn courses(&self) -> Result<Vec<Course>, String>;
    fn course_books(&self, course_id: &str) -> Result<Vec<CourseBook>, String>;
    fn book(&self, book_id: &str) -> Result<Option<CourseBook>, String>;
    fn book_lessons(&self, book_id: &str) -> Result<Vec<LessonListEntry>, String>;
    fn course_lesson(&self, lesson_id: &str) -> Result<Option<CourseLesson>, String>;
    fn lesson_sentences(&self, lesson_id: &str) -> Result<Vec<LessonSentence>, String>;
    fn lesson_vocab(&self, lesson_id: &str) -> Result<Vec<LessonVocab>, String>;
    /// 本课每个词的用户自评（word -> mark）。
    fn lesson_vocab_marks(
        &self,
        lesson_id: &str,
    ) -> Result<std::collections::HashMap<String, Option<String>>, String>;
    /// 记录用户在本课的自评。
    fn set_lesson_vocab_mark(
        &self,
        lesson_id: &str,
        word: &str,
        mark: Option<&str>,
    ) -> Result<(), String>;
    fn book_summary(&self, book_id: &str) -> Result<BookSummary, String>;
    fn lesson_progress(&self, lesson_id: &str) -> Result<Option<LessonProgress>, String>;
    fn save_lesson_progress(&self, progress: &LessonProgress) -> Result<(), String>;
    fn latest_learning_lesson(&self) -> Result<Option<LessonListEntry>, String>;
    fn recent_lesson_entries(&self, limit: usize) -> Result<Vec<LessonListEntry>, String>;
    fn study_seconds_since(&self, day_start: i64) -> Result<i64, String>;
    fn study_streak_days(&self, now: i64) -> Result<u32, String>;
    fn learning_plan(&self, language: &str) -> Result<Option<LearningPlan>, String>;
    fn save_learning_plan(&self, plan: &LearningPlan) -> Result<(), String>;
    fn record_word_occurrence(&self, occurrence: &WordOccurrence) -> Result<(), String>;
    fn word_occurrences(&self, word: &str, limit: usize) -> Result<Vec<WordOccurrence>, String>;
    fn word_occurrence_count(&self, word: &str) -> Result<i64, String>;
    fn dict_lookup(&self, word: &str) -> Result<Option<WordEntry>, String>;
    fn dict_search(&self, query: &str, limit: usize) -> Result<Vec<WordEntry>, String>;
    fn dict_count(&self) -> Result<i64, String>;
    fn lesson_title_search(&self, query: &str, limit: usize) -> Result<Vec<CourseLesson>, String>;
    /// 写入一次跟读尝试（V13 W2；id 幂等）。
    fn insert_shadow_attempt(&self, attempt: &ShadowAttempt) -> Result<(), String>;
    /// 跟读尝试（时间倒序；`lesson_id` 为 `None` 取全部）。
    fn shadow_attempts(
        &self,
        lesson_id: Option<&str>,
        limit: usize,
    ) -> Result<Vec<ShadowAttempt>, String>;
}

// ============================================================================
// DictionaryService
// ============================================================================

/// 统一词典服务：业务页面只调它，不直接查询 ECDICT 存储。
pub struct DictionaryService {
    store: Arc<dyn CourseStorePort>,
}

impl DictionaryService {
    #[must_use]
    pub fn new(store: Arc<dyn CourseStorePort>) -> Self {
        Self { store }
    }

    /// 查词（大小写不敏感 + 词形还原）。
    pub fn lookup(&self, word: &str) -> Result<Option<WordEntry>, ApplicationError> {
        self.store.dict_lookup(word).map_err(err)
    }

    pub fn search(&self, query: &str, limit: usize) -> Result<Vec<WordEntry>, ApplicationError> {
        self.store.dict_search(query, limit).map_err(err)
    }

    /// 词典是否已导入（UI 决定要不要显示「先导入词典」提示）。
    pub fn is_ready(&self) -> Result<bool, ApplicationError> {
        self.store.dict_count().map(|count| count > 0).map_err(err)
    }
}

// ============================================================================
// CourseService DTO
// ============================================================================

/// English 首页（学习驾驶舱）所需的全部数据。
#[derive(Clone, Debug, Serialize)]
pub struct TodayDashboard {
    /// 是否已导入课程。
    pub imported: bool,
    /// 词典是否就绪。
    pub dict_ready: bool,
    pub plan: Option<LearningPlan>,
    /// 继续学习（最近有进度的课）。
    pub continue_lesson: Option<LessonListEntry>,
    /// 当前书中下一课（第一个未开始）。
    pub next_lesson: Option<LessonListEntry>,
    pub current_book: Option<CourseBook>,
    pub book_summary: Option<BookSummary>,
    /// 今日到期复习卡数（平台 module=language）。
    pub due_reviews: u32,
    /// 今日已学秒数。
    pub study_seconds_today: i64,
    pub streak_days: u32,
    /// 已学单词总数（平台进度 module=language + word）。
    pub words_learned: u32,
    pub recent_lessons: Vec<LessonListEntry>,
}

/// Book 页。
#[derive(Clone, Debug, Serialize)]
pub struct BookView {
    pub book: CourseBook,
    pub summary: BookSummary,
    pub lessons: Vec<LessonListEntry>,
}

/// 课时生词 + 用户掌握状态。
#[derive(Clone, Debug, Serialize)]
pub struct VocabWithState {
    #[serde(flatten)]
    pub vocab: LessonVocab,
    /// `new` / `learning` / `known`（平台进度推导）。
    pub state: String,
    /// 用户在本课的自评：`Some("know" | "fuzzy" | "unknown")`，未标过为 `None`。
    ///
    /// 课前预习靠它决定谁还该出现——标过「认识」的词不再出现在队列里。
    pub mark: Option<String>,
    /// 用户在其它地方见过它几次（occurrences 特色能力）。
    pub seen_count: i64,
}

/// Lesson 工作台的完整数据包。
#[derive(Clone, Debug, Serialize)]
pub struct LessonDetail {
    pub lesson: CourseLesson,
    pub book: Option<CourseBook>,
    pub sentences: Vec<LessonSentence>,
    pub vocab: Vec<VocabWithState>,
    pub progress: LessonProgress,
}

/// 查词浮层的完整数据包。
#[derive(Clone, Debug, Serialize)]
pub struct WordLookup {
    pub entry: Option<WordEntry>,
    pub seen_count: i64,
    pub occurrences: Vec<WordOccurrence>,
    /// 平台学习状态（没学过 = None）。
    pub learning: Option<LearningProgress>,
}

/// English 统计页。
#[derive(Clone, Debug, Serialize)]
pub struct EnglishProgress {
    pub lessons_completed: u32,
    pub lessons_learning: u32,
    pub study_seconds_total: i64,
    pub words_learned: u32,
    pub words_mastered: u32,
    /// 复习掌握度（平台平均分 0–100；诚实命名为 mastery 而非 retention）。
    pub review_mastery: f64,
    pub due_reviews: u32,
    pub streak_days: u32,
    pub books: Vec<BookProgressView>,
}

#[derive(Clone, Debug, Serialize)]
pub struct BookProgressView {
    pub book: CourseBook,
    pub summary: BookSummary,
}

/// 英语学习搜索（词典 + 课时）。
#[derive(Clone, Debug, Serialize)]
pub struct EnglishSearchResult {
    pub words: Vec<WordEntry>,
    pub lessons: Vec<CourseLesson>,
}

/// 进度更新补丁（前端工作台心跳）。
#[derive(Clone, Debug, Deserialize)]
pub struct ProgressPatch {
    pub stage: Option<LessonStage>,
    pub position_ms: Option<i64>,
    pub sentence_seq: Option<u32>,
    pub vocab_index: Option<u32>,
    pub shadow_seq: Option<u32>,
    /// 本次累加的学习秒数（心跳差值）。
    pub study_seconds_delta: Option<i64>,
}

// ============================================================================
// CourseService
// ============================================================================

pub struct CourseService {
    store: Arc<dyn CourseStorePort>,
    platform: Arc<LearningService>,
}

/// 单词在平台学习库里的实体 id（`en:{lemma}`）。
fn word_entity_id(lemma: &str) -> String {
    format!("en:{}", lemma.to_ascii_lowercase())
}

fn word_entity_key(lemma: &str) -> String {
    format!("{MODULE}:word:{}", word_entity_id(lemma))
}

fn word_card_id(lemma: &str) -> String {
    format!("language:nce-word:{}", lemma.to_ascii_lowercase())
}

impl CourseService {
    #[must_use]
    pub fn new(store: Arc<dyn CourseStorePort>, platform: Arc<LearningService>) -> Self {
        Self { store, platform }
    }

    // ========================================================================
    // Today 驾驶舱
    // ========================================================================

    pub fn today(&self, now: i64) -> Result<TodayDashboard, ApplicationError> {
        let plan = self.store.learning_plan("eng").map_err(err)?;
        let courses = self.store.courses().map_err(err)?;
        let imported = courses.iter().any(|course| course.code == "nce");
        let dict_ready = self.store.dict_count().map_err(err)? > 0;

        let continue_lesson = self.store.latest_learning_lesson().map_err(err)?;
        // 还没设置计划时，**自动选第一本有课的册**——首页必须回答「我今天该学什么」，
        // 而不是显示「未设置」让用户自己做决定（任务书 §26）。
        let fallback_book = self
            .store
            .course_books("nce")
            .map_err(err)?
            .into_iter()
            .next();
        let current_book = plan
            .as_ref()
            .and_then(|plan| plan.book_id.clone())
            .and_then(|book_id| self.store.book(&book_id).ok().flatten())
            .or(fallback_book);
        let (book_summary, next_lesson) = match &current_book {
            Some(book) => {
                let lessons = self.store.book_lessons(&book.id).map_err(err)?;
                let next = lessons
                    .iter()
                    .find(|entry| {
                        entry.status == devtoolbox_core::language::LessonStatus::NotStarted
                    })
                    .cloned();
                (Some(self.store.book_summary(&book.id).map_err(err)?), next)
            }
            None => (None, None),
        };

        let stats = self.platform.get_review_stats(now).map_err(platform)?;
        let due_reviews = stats.by_module.get(MODULE).copied().unwrap_or(0);
        let day_start = now - now.rem_euclid(86_400);
        let words = self
            .platform
            .list_progress(Some(MODULE), None, 10_000)
            .map_err(platform)?;
        let words_learned = words
            .iter()
            .filter(|progress| progress.entity_type == "word")
            .count() as u32;

        Ok(TodayDashboard {
            imported,
            dict_ready,
            plan,
            continue_lesson,
            next_lesson,
            current_book,
            book_summary,
            due_reviews,
            study_seconds_today: self.store.study_seconds_since(day_start).map_err(err)?,
            streak_days: self.store.study_streak_days(now).map_err(err)?,
            words_learned,
            recent_lessons: self.store.recent_lesson_entries(6).map_err(err)?,
        })
    }

    // ========================================================================
    // 课程浏览
    // ========================================================================

    pub fn library(&self) -> Result<Vec<CourseBook>, ApplicationError> {
        self.store.course_books("nce").map_err(err)
    }

    pub fn book_view(&self, book_id: &str) -> Result<Option<BookView>, ApplicationError> {
        let Some(book) = self.store.book(book_id).map_err(err)? else {
            return Ok(None);
        };
        Ok(Some(BookView {
            summary: self.store.book_summary(book_id).map_err(err)?,
            lessons: self.store.book_lessons(book_id).map_err(err)?,
            book,
        }))
    }

    // ========================================================================
    // Lesson 工作台
    // ========================================================================

    pub fn lesson_detail(
        &self,
        lesson_id: &str,
        now: i64,
    ) -> Result<Option<LessonDetail>, ApplicationError> {
        let Some(lesson) = self.store.course_lesson(lesson_id).map_err(err)? else {
            return Ok(None);
        };
        let book = self.store.book(&lesson.book_id).map_err(err)?;
        let sentences = self.store.lesson_sentences(lesson_id).map_err(err)?;
        let vocab = self.store.lesson_vocab(lesson_id).map_err(err)?;
        let progress = self
            .store
            .lesson_progress(lesson_id)
            .map_err(err)?
            .unwrap_or_else(|| LessonProgress::new(lesson_id, now));
        // 本课每个词的用户自评（决定课前队列：标过「认识」的不再出现）。
        let marks = self.store.lesson_vocab_marks(lesson_id).map_err(err)?;
        let vocab = vocab
            .into_iter()
            .map(|word| {
                let state = self.word_state(&word.word);
                let mark = marks.get(&word.word).cloned().flatten();
                let seen_count = self.store.word_occurrence_count(&word.word).unwrap_or(0);
                VocabWithState {
                    vocab: word,
                    state,
                    mark,
                    seen_count,
                }
            })
            .collect();
        Ok(Some(LessonDetail {
            lesson,
            book,
            sentences,
            vocab,
            progress,
        }))
    }

    /// 单词掌握状态：平台进度 → new/learning/known。
    fn word_state(&self, lemma: &str) -> String {
        let key = word_entity_key(lemma);
        match self.platform.get_progress(&key) {
            Ok(Some(progress)) => match progress.status {
                LearningStatus::Familiar | LearningStatus::Mastered => "known".to_string(),
                _ => "learning".to_string(),
            },
            _ => "new".to_string(),
        }
    }

    /// 更新课时进度（工作台心跳；合并补丁，不动未提供的字段）。
    pub fn update_lesson_progress(
        &self,
        lesson_id: &str,
        patch: ProgressPatch,
        now: i64,
    ) -> Result<LessonProgress, ApplicationError> {
        if self.store.course_lesson(lesson_id).map_err(err)?.is_none() {
            return Err(err(format!("lesson not found: {lesson_id}")));
        }
        let mut progress = self
            .store
            .lesson_progress(lesson_id)
            .map_err(err)?
            .unwrap_or_else(|| LessonProgress::new(lesson_id, now));
        if let Some(stage) = patch.stage {
            progress.stage = stage;
        }
        if let Some(position_ms) = patch.position_ms {
            progress.position_ms = position_ms.max(0);
        }
        if let Some(seq) = patch.sentence_seq {
            progress.sentence_seq = seq;
        }
        if let Some(index) = patch.vocab_index {
            progress.vocab_index = index;
        }
        if let Some(seq) = patch.shadow_seq {
            progress.shadow_seq = seq;
        }
        if let Some(delta) = patch.study_seconds_delta {
            progress.study_seconds += delta.max(0);
        }
        progress.updated_at = now;
        self.store.save_lesson_progress(&progress).map_err(err)?;
        Ok(progress)
    }

    /// 完成一课：进度标记 + 平台事件 + 生成「明天复习这一课」的平台复习卡。
    pub fn complete_lesson(
        &self,
        lesson_id: &str,
        quiz_score: Option<u32>,
        now: i64,
    ) -> Result<LessonProgress, ApplicationError> {
        let lesson = self
            .store
            .course_lesson(lesson_id)
            .map_err(err)?
            .ok_or_else(|| err(format!("lesson not found: {lesson_id}")))?;
        let mut progress = self
            .store
            .lesson_progress(lesson_id)
            .map_err(err)?
            .unwrap_or_else(|| LessonProgress::new(lesson_id, now));
        progress.stage = LessonStage::Done;
        progress.completed_at = progress.completed_at.or(Some(now));
        progress.quiz_score = quiz_score.or(progress.quiz_score);
        progress.updated_at = now;
        self.store.save_lesson_progress(&progress).map_err(err)?;

        self.platform
            .record_event(
                &LearningEvent {
                    id: String::new(),
                    module: MODULE.to_string(),
                    entity_type: "lesson".to_string(),
                    entity_id: lesson_id.to_string(),
                    entity_title: Some(format!(
                        "NCE{} Lesson {} {}",
                        lesson.book_id.rsplit(':').next().unwrap_or(""),
                        lesson.lesson_no,
                        lesson.title
                    )),
                    action: LearningAction::Complete,
                    timestamp: now,
                    duration_ms: None,
                    metadata: serde_json::json!({ "quiz_score": progress.quiz_score }),
                    source: Some("language-course".to_string()),
                },
                now,
            )
            .map_err(platform)?;

        // 课时复习卡：明天复习（让「完成」进入闭环，不是终点）。
        let card = UniversalReviewCard {
            id: format!("language:nce-lesson:{lesson_id}"),
            module: MODULE.to_string(),
            entity_id: lesson_id.to_string(),
            entity_type: "lesson".to_string(),
            card_type: ReviewCardType::Recall,
            prompt: format!("复习 Lesson {} {}", lesson.lesson_no, lesson.title),
            answer: "重新听一遍 + 复述要点".to_string(),
            options: None,
            hint: None,
            context: Some(lesson.book_id.clone()),
            source_title: None,
            user_note: None,
            due_at: now + 86_400,
            interval_days: 1.0,
            ease: 2.5,
            mastery_score: 0.0,
            repetition_count: 0,
            lapses: 0,
            last_reviewed_at: None,
            created_at: now,
        };
        self.platform.upsert_review_card(&card).map_err(platform)?;
        Ok(progress)
    }

    // ========================================================================
    // 单词学习
    // ========================================================================

    /// 课前单词三态标记：Know / Fuzzy / Unknown。
    ///
    /// 编排：occurrence（哪里学的）+ 平台复习卡（立即排一次对应评分）+
    /// 平台事件（掌握度单点真相）。
    pub fn mark_word(
        &self,
        lesson_id: &str,
        word: &str,
        mark: WordMark,
        now: i64,
    ) -> Result<LearningProgress, ApplicationError> {
        let lemma = word.trim().to_ascii_lowercase();
        if lemma.is_empty() {
            return Err(err("empty word".to_string()));
        }
        let entry = self.store.dict_lookup(&lemma).map_err(err)?;
        let translation = entry
            .as_ref()
            .and_then(|e| e.translation_zh.clone())
            .or_else(|| entry.as_ref().and_then(|e| e.definition_en.clone()))
            .unwrap_or_else(|| lemma.clone());

        // 1) 遇见记录（幂等键：word+lesson）。
        let _ = self.store.record_word_occurrence(&WordOccurrence {
            word: lemma.clone(),
            source_type: "lesson".to_string(),
            source_id: lesson_id.to_string(),
            sentence: None,
            occurred_at: now,
        });

        // 2) 平台复习卡（卡片内容来自真实词典数据）。
        let card = UniversalReviewCard {
            id: word_card_id(&lemma),
            module: MODULE.to_string(),
            entity_id: word_entity_id(&lemma),
            entity_type: "word".to_string(),
            card_type: ReviewCardType::Recall,
            prompt: lemma.clone(),
            answer: translation,
            options: None,
            hint: entry.as_ref().and_then(|e| e.phonetic.clone()),
            context: Some(lesson_id.to_string()),
            source_title: None,
            user_note: None,
            due_at: now,
            interval_days: 0.0,
            ease: 2.5,
            mastery_score: 0.0,
            repetition_count: 0,
            lapses: 0,
            last_reviewed_at: None,
            created_at: now,
        };
        self.platform.upsert_review_card(&card).map_err(platform)?;

        // 2.5) 记录「用户在本课怎么说的」——课前预习据此把「认识」的词移出队列，
        //      重进课程时也能看到上次的判断。
        self.store
            .set_lesson_vocab_mark(lesson_id, &lemma, Some(mark.as_str()))
            .map_err(err)?;

        // 3) 立即按自评排期：Know=Easy / Fuzzy=Hard / Unknown=Again（今天再见）。
        let rating = match mark {
            WordMark::Know => ReviewRating::Easy,
            WordMark::Fuzzy => ReviewRating::Hard,
            WordMark::Unknown => ReviewRating::Again,
        };
        self.platform
            .submit_review(&card.id, rating, now)
            .map_err(platform)?;

        // 4) 平台进度（get_progress 的 key 与事件 entity 对应）。
        self.platform
            .get_progress(&word_entity_key(&lemma))
            .map_err(platform)?
            .ok_or_else(|| err("progress missing after review".to_string()))
    }

    /// 查词浮层：词典 + 遇见历史 + 学习状态；同时记一次 lookup occurrence。
    pub fn lookup_word(
        &self,
        word: &str,
        context_sentence: Option<&str>,
        source_lesson: Option<&str>,
        now: i64,
    ) -> Result<WordLookup, ApplicationError> {
        let normalized = word.trim().to_ascii_lowercase();
        let entry = self.store.dict_lookup(&normalized).map_err(err)?;
        let lemma = entry
            .as_ref()
            .map(|e| e.lemma.clone())
            .unwrap_or_else(|| normalized.clone());
        if !lemma.is_empty() {
            let _ = self.store.record_word_occurrence(&WordOccurrence {
                word: lemma.clone(),
                source_type: "lookup".to_string(),
                source_id: format!("{}:{now}", source_lesson.unwrap_or("global")),
                sentence: context_sentence.map(str::to_string),
                occurred_at: now,
            });
        }
        let learning = self
            .platform
            .get_progress(&word_entity_key(&lemma))
            .map_err(platform)?;
        Ok(WordLookup {
            entry,
            seen_count: self.store.word_occurrence_count(&lemma).map_err(err)?,
            occurrences: self.store.word_occurrences(&lemma, 8).map_err(err)?,
            learning,
        })
    }

    // ========================================================================
    // Quiz
    // ========================================================================

    /// 从本课真实数据生成 Quiz（词汇选择 / 填空 / 听写 / 翻译）。
    pub fn generate_quiz(&self, lesson_id: &str) -> Result<Vec<QuizItem>, ApplicationError> {
        let sentences = self.store.lesson_sentences(lesson_id).map_err(err)?;
        let vocab = self.store.lesson_vocab(lesson_id).map_err(err)?;
        if sentences.is_empty() {
            return Err(err("lesson has no sentences".to_string()));
        }
        let mut items = Vec::new();

        // 1) 词汇选择（最多 5 题）：正确答案 + 同课其它词的中文做干扰项。
        let with_translation: Vec<&LessonVocab> = vocab
            .iter()
            .filter(|word| word.translation_zh.is_some())
            .take(8)
            .collect();
        let pool: Vec<String> = with_translation
            .iter()
            .filter_map(|word| first_meaning(word.translation_zh.as_deref()))
            .collect();
        for (index, word) in with_translation.iter().take(5).enumerate() {
            let Some(correct) = first_meaning(word.translation_zh.as_deref()) else {
                continue;
            };
            let mut options: Vec<String> = pool
                .iter()
                .filter(|candidate| **candidate != correct)
                .take(3)
                .cloned()
                .collect();
            // 不编造干扰项：本课候选不足时，选项可以少于 4 个。
            let answer = if options.is_empty() {
                options.push(correct.clone());
                0
            } else {
                index % (options.len() + 1)
            };
            options.insert(answer, correct);
            items.push(QuizItem::Vocabulary {
                word: word.word.clone(),
                phonetic: word.phonetic.clone(),
                options,
                answer,
            });
        }

        // 2) 填空（最多 3 题）：课文原句挖掉本课生词（用词形 surface 替换）。
        let mut fill_count = 0;
        'outer: for word in vocab.iter().filter(|w| w.translation_zh.is_some()) {
            for sentence in &sentences {
                if let Some(blanked) = blank_word(&sentence.english, word) {
                    items.push(QuizItem::FillBlank {
                        sentence: blanked,
                        chinese: sentence.chinese.clone(),
                        answer: word.surface.clone().unwrap_or_else(|| word.word.clone()),
                    });
                    fill_count += 1;
                    if fill_count >= 3 {
                        break 'outer;
                    }
                    continue 'outer;
                }
            }
        }

        // 3) 听写（最多 2 句）：挑 4–12 词的中等句。
        let dictation: Vec<&LessonSentence> = sentences
            .iter()
            .filter(|sentence| {
                let words = sentence.english.split_whitespace().count();
                (4..=12).contains(&words)
            })
            .take(2)
            .collect();
        for sentence in dictation {
            items.push(QuizItem::Dictation {
                lesson_id: lesson_id.to_string(),
                sentence_seq: sentence.sequence,
                start_ms: sentence.start_ms,
                end_ms: sentence.end_ms,
                answer: sentence.english.clone(),
            });
        }

        // 4) 翻译（最多 2 句）：有中文的句子，自评对错。
        for sentence in sentences
            .iter()
            .filter(|sentence| sentence.chinese.is_some())
            .take(2)
        {
            items.push(QuizItem::Translate {
                chinese: sentence.chinese.clone().unwrap_or_default(),
                reference: sentence.english.clone(),
            });
        }

        Ok(items)
    }

    /// 提交 Quiz：计分 + 错词进 SRS（今天再见）+ 课时进度。
    pub fn submit_quiz(
        &self,
        lesson_id: &str,
        answers: &[QuizAnswer],
        now: i64,
    ) -> Result<QuizResult, ApplicationError> {
        if answers.is_empty() {
            return Err(err("empty quiz submission".to_string()));
        }
        let vocab = self.store.lesson_vocab(lesson_id).map_err(err)?;
        let correct = answers.iter().filter(|answer| answer.correct).count() as u32;
        let total = answers.len() as u32;
        let score = correct * 100 / total;

        // 错题对应词（Vocabulary/FillBlank 题序与 generate_quiz 的 vocab 序对齐的
        // 部分由前端把 word 放进 user_answer；这里兜底：把答错题相关的本课生词标记 Again）。
        let mut wrong_words = Vec::new();
        for answer in answers.iter().filter(|answer| !answer.correct) {
            if let Some(word) = answer
                .user_answer
                .as_deref()
                .and_then(|raw| raw.split('|').next())
                .map(str::trim)
                .filter(|raw| !raw.is_empty())
            {
                let lemma = word.to_ascii_lowercase();
                if vocab.iter().any(|v| v.word == lemma) {
                    wrong_words.push(lemma.clone());
                    let _ = self.mark_word(lesson_id, &lemma, WordMark::Unknown, now);
                }
            }
        }

        // 课时进度：记录分数；>=60 视为完成本课。
        let progress = if score >= 60 {
            self.complete_lesson(lesson_id, Some(score), now)?
        } else {
            let mut progress = self
                .store
                .lesson_progress(lesson_id)
                .map_err(err)?
                .unwrap_or_else(|| LessonProgress::new(lesson_id, now));
            progress.stage = LessonStage::Quiz;
            progress.quiz_score = Some(score);
            progress.updated_at = now;
            self.store.save_lesson_progress(&progress).map_err(err)?;
            progress
        };
        let _ = progress;

        Ok(QuizResult {
            lesson_id: lesson_id.to_string(),
            total,
            correct,
            score,
            wrong_words,
            finished_at: now,
        })
    }

    // ========================================================================
    // 计划 / 统计 / 搜索
    // ========================================================================

    pub fn get_plan(&self) -> Result<Option<LearningPlan>, ApplicationError> {
        self.store.learning_plan("eng").map_err(err)
    }

    pub fn save_plan(&self, plan: &LearningPlan) -> Result<(), ApplicationError> {
        self.store.save_learning_plan(plan).map_err(err)
    }

    /// 第一次学习活动所在的日期（当天 00:00，Unix 秒）；没有记录返回 `None`。
    ///
    /// 用途：路线图的「第几周」必须有**真实起点**。没有记录就返回 `None`，
    /// 由界面询问用户，而不是从今天倒推一个假的开始日。
    pub fn first_study_day(&self, now: i64) -> Option<i64> {
        let recent = self
            .platform
            .list_progress(Some(MODULE), None, 20_000)
            .ok()?;
        let earliest = recent
            .iter()
            .map(|row| row.last_studied_at)
            .filter(|at| *at > 0)
            .min()?;
        let day = earliest.div_euclid(86_400) * 86_400;
        // 未来的时间戳（时钟不准 / 手改库）不当开始日。
        if day > now { None } else { Some(day) }
    }

    pub fn english_progress(&self, now: i64) -> Result<EnglishProgress, ApplicationError> {
        let books = self.store.course_books("nce").map_err(err)?;
        let mut book_views = Vec::new();
        let mut lessons_completed = 0;
        let mut lessons_learning = 0;
        let mut study_total = 0;
        for book in &books {
            let summary = self.store.book_summary(&book.id).map_err(err)?;
            lessons_completed += summary.completed_lessons;
            lessons_learning += summary.learning_lessons;
            study_total += summary.study_seconds;
            book_views.push(BookProgressView {
                book: book.clone(),
                summary,
            });
        }
        let progress_rows = self
            .platform
            .list_progress(Some(MODULE), None, 20_000)
            .map_err(platform)?;
        let words: Vec<&LearningProgress> = progress_rows
            .iter()
            .filter(|progress| progress.entity_type == "word")
            .collect();
        let stats = self.platform.get_review_stats(now).map_err(platform)?;
        // 掌握度均值：平台 `MasteryCalculator` 写在每行 learning_progress 上，这里
        // 只做平均（不重算规则）。
        let review_mastery = if words.is_empty() {
            0.0
        } else {
            let sum: f64 = words.iter().map(|progress| progress.mastery_score).sum();
            (sum / words.len() as f64 * 10.0).round() / 10.0
        };
        Ok(EnglishProgress {
            lessons_completed,
            lessons_learning,
            study_seconds_total: study_total,
            words_learned: words.len() as u32,
            words_mastered: words
                .iter()
                .filter(|progress| progress.status == LearningStatus::Mastered)
                .count() as u32,
            review_mastery,
            due_reviews: stats.by_module.get(MODULE).copied().unwrap_or(0),
            streak_days: self.store.study_streak_days(now).map_err(err)?,
            books: book_views,
        })
    }

    pub fn search(
        &self,
        query: &str,
        limit: usize,
    ) -> Result<EnglishSearchResult, ApplicationError> {
        Ok(EnglishSearchResult {
            words: self.store.dict_search(query, limit).map_err(err)?,
            lessons: self.store.lesson_title_search(query, limit).map_err(err)?,
        })
    }
}

// ============================================================================
// SpeakingService（V13 W2：跟读发音评分）
// ============================================================================

/// 一次跟读评分的结果（含词级差异，直接给界面展示）。
#[derive(Clone, Debug, Serialize)]
pub struct ShadowScoreResult {
    pub attempt: ShadowAttempt,
    /// 整体印象（三项均分）。
    pub overall: u8,
    /// 漏说的词。
    pub missing: Vec<String>,
    /// 说错的词。
    pub wrong: Vec<String>,
    /// 多说的词。
    pub extra: Vec<String>,
}

/// 跟读评分的失败分类（前端据此区分「你得再说一次」与「服务坏了」）。
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum SpeakingError {
    /// 没有识别到内容 —— **不给分**，这不是学习者的问题。
    EmptyTranscript,
    /// 课文里没有这一句（客户端指错了位置）。
    SentenceNotFound { lesson_id: String, sequence: u32 },
    /// 存储层失败。
    Storage(String),
}

impl std::fmt::Display for SpeakingError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::EmptyTranscript => write!(
                formatter,
                "没有识别到语音内容，无法评分（请确认麦克风权限与网络）"
            ),
            Self::SentenceNotFound {
                lesson_id,
                sequence,
            } => write!(
                formatter,
                "课文里没有第 {sequence} 句（lesson {lesson_id}）"
            ),
            Self::Storage(message) => write!(formatter, "{message}"),
        }
    }
}

/// 一次跟读打分的输入（前端提供的部分；**目标句不在其中**，由服务端查库）。
#[derive(Clone, Debug, Default)]
pub struct ShadowScoreInput {
    pub sentence_seq: u32,
    /// 语音识别转写（必须来自真实识别结果）。
    pub transcript: String,
    /// 实际开口时长（毫秒）。
    pub duration_ms: u64,
    /// 目标句参考朗读时长（毫秒；0 = 不参与流利度计算）。
    pub target_ms: u64,
    /// 超过阈值的长停顿（毫秒数组）。
    pub long_pauses_ms: Vec<u64>,
}

/// 跟读评分服务。
///
/// ## 铁律：没有转写就没有分数
///
/// 输入的 `transcript` 必须来自**真实的语音识别结果**（浏览器 Web Speech）。
/// 没拿到转写时前端根本不会调用本服务 —— 服务端也不会替它编一个分数。
/// 识别可用但结果是空串时，返回受控错误而不是记一条 0 分。
///
/// ## 目标句由服务端查库得到
///
/// 请求只带 `lesson_id` + `sentence_seq`；目标文本从 `language_sentences` 读。
/// 信任前端传来的「目标句」等于让用户自己给自己判分。
pub struct SpeakingService {
    store: Arc<dyn CourseStorePort>,
}

/// 跟读尝试的进程内自增序号（让同一秒内的多次尝试也各有 id）。
static ATTEMPT_SEQ: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

fn next_attempt_seq() -> u64 {
    ATTEMPT_SEQ.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
}

impl SpeakingService {
    #[must_use]
    pub fn new(store: Arc<dyn CourseStorePort>) -> Self {
        Self { store }
    }

    /// 对一次跟读尝试评分并落库。
    pub fn score_attempt(
        &self,
        lesson_id: &str,
        input: ShadowScoreInput,
        now: i64,
    ) -> Result<ShadowScoreResult, SpeakingError> {
        let sentence_seq = input.sentence_seq;
        // 识别结果常常带首尾空白与换行；trim 后再判空，否则「只听到噪声」
        // 会被当成一次真实尝试记成 0 分。
        let trimmed = input.transcript.trim();
        if trimmed.is_empty() {
            return Err(SpeakingError::EmptyTranscript);
        }
        let sentences = self
            .store
            .lesson_sentences(lesson_id)
            .map_err(|error| SpeakingError::Storage(error.to_string()))?;
        let target = sentences
            .iter()
            .find(|item| item.sequence == sentence_seq)
            .ok_or_else(|| SpeakingError::SentenceNotFound {
                lesson_id: lesson_id.to_string(),
                sequence: sentence_seq,
            })?
            .english
            .clone();
        let score = devtoolbox_core::language::speaking::score(
            &target,
            trimmed,
            input.duration_ms,
            input.target_ms,
            &input.long_pauses_ms,
        );
        let diff = devtoolbox_core::language::speaking::compare_words(
            &devtoolbox_core::language::speaking::tokenize(&target),
            &devtoolbox_core::language::speaking::tokenize(trimmed),
        );
        let attempt = ShadowAttempt {
            // id 含进程内自增序号：同一秒内连续跟读两句（或重试）也不会互相覆盖。
            id: format!(
                "shadow:{lesson_id}:{sentence_seq}:{now}:{}",
                next_attempt_seq()
            ),
            lesson_id: lesson_id.to_string(),
            sentence_seq,
            target,
            transcript: trimmed.to_string(),
            accuracy: score.accuracy,
            completeness: score.completeness,
            fluency: score.fluency,
            duration_ms: input.duration_ms,
            created_at: now,
        };
        self.store
            .insert_shadow_attempt(&attempt)
            .map_err(|error| SpeakingError::Storage(error.to_string()))?;
        Ok(ShadowScoreResult {
            overall: attempt.overall(),
            attempt,
            missing: diff.missing,
            wrong: diff.wrong,
            extra: diff.extra,
        })
    }

    /// 跟读统计（`lesson_id` 为 `None` 时跨课汇总；`since` 为 0 表示不限时间）。
    pub fn stats(
        &self,
        lesson_id: Option<&str>,
        since: i64,
    ) -> Result<ShadowStats, ApplicationError> {
        let mut attempts = self.store.shadow_attempts(lesson_id, 1_000).map_err(err)?;
        if since > 0 {
            attempts.retain(|attempt| attempt.created_at >= since);
        }
        Ok(summarize_shadow_attempts(&attempts))
    }

    /// 最近若干次尝试（按时间倒序）。
    pub fn recent_attempts(
        &self,
        lesson_id: Option<&str>,
        limit: usize,
    ) -> Result<Vec<ShadowAttempt>, ApplicationError> {
        self.store
            .shadow_attempts(lesson_id, limit.clamp(1, 200))
            .map_err(err)
    }
}

// ============================================================================
// MiningService（V13 W3：句子挖掘 → 复习卡）
// ============================================================================

/// 挖掘服务：把读过的课文句变成**要主动回忆**的复习卡。
///
/// ## 为什么要有
///
/// 学完一课，用户认得 200 个词，却很难在无提示下说出课文句子 —— 而真实交流
/// 靠的是整句产出。这里从**本课真实句子**里挖空 / 听写 / 中译英，做成卡片进
/// **同一个 SRS**：复习时先看句、再回忆，测的是「用」不是「认」。
///
/// ## 边界
///
/// - 卡片 id 内容派生（`lesson + 句号 + 类型`）→ 重复挖掘**幂等**，不产生重复卡；
/// - 只有本课真实存在的句子才成卡（短句、缺译文的句子跳过，**不编造**）；
/// - 不改动教材内容，只新增复习卡。
pub struct MiningService {
    store: Arc<dyn CourseStorePort>,
    platform: Arc<LearningService>,
}

/// 句子卡的实体 id。
fn sentence_entity_id(lesson_id: &str, sequence: u32) -> String {
    format!("en-sentence:{lesson_id}:{sequence}")
}

impl MiningService {
    #[must_use]
    pub fn new(store: Arc<dyn CourseStorePort>, platform: Arc<LearningService>) -> Self {
        Self { store, platform }
    }

    /// 挖掘一课的候选卡（不落库；给界面预览「本课可以挖 N 张」）。
    pub fn preview(
        &self,
        lesson_id: &str,
        max_per_kind: usize,
    ) -> Result<Vec<MinedCard>, ApplicationError> {
        let sentences = self.store.lesson_sentences(lesson_id).map_err(err)?;
        let vocab: Vec<String> = self
            .store
            .lesson_vocab(lesson_id)
            .map_err(err)?
            .into_iter()
            .map(|item| item.word)
            .collect();
        Ok(mine_lesson(&sentences, &vocab, max_per_kind.clamp(1, 50)))
    }

    /// 挖掘并写入复习卡（幂等：已存在的卡会被原样覆盖，不重复计数）。
    ///
    /// 返回实际写入的卡数量。
    pub fn mine_into_review(
        &self,
        lesson_id: &str,
        max_per_kind: usize,
        now: i64,
    ) -> Result<MinedReport, ApplicationError> {
        let cards = self.preview(lesson_id, max_per_kind)?;
        let mut written = 0_usize;
        for card in &cards {
            let entity_id = sentence_entity_id(lesson_id, card.sequence);
            let review_card = UniversalReviewCard {
                id: mined_card_id(lesson_id, card),
                module: MODULE.to_string(),
                entity_id: entity_id.clone(),
                entity_type: "sentence".to_string(),
                card_type: review_card_type(card.kind),
                prompt: review_prompt(card),
                answer: card.answer.clone(),
                // 填空/听写用播放按钮 + 中文提示，不给选择项（选择题测不出产出）。
                options: None,
                hint: card.chinese.clone(),
                // 语境就是原句：复习时先看句再回忆。
                context: Some(card.sentence.clone()),
                source_title: None,
                user_note: None,
                due_at: now,
                interval_days: 0.0,
                ease: 2.5,
                mastery_score: 0.0,
                repetition_count: 0,
                lapses: 0,
                last_reviewed_at: None,
                created_at: now,
            };
            self.platform
                .upsert_review_card(&review_card)
                .map_err(platform)?;
            // 同步登记学习进度：句子也是一个学习对象（掌握度 / 今日面板可见）。
            let event = LearningEvent {
                id: String::new(),
                module: MODULE.to_string(),
                entity_type: "sentence".to_string(),
                entity_id,
                entity_title: Some(card.sentence.clone()),
                action: LearningAction::Study,
                timestamp: now,
                duration_ms: None,
                metadata: serde_json::json!({
                    "card_kind": card.kind.as_str(),
                    "reason": card.reason,
                }),
                source: Some("nce-mining".to_string()),
            };
            let _ = self.platform.record_event(&event, now);
            written += 1;
        }
        Ok(MinedReport {
            lesson_id: lesson_id.to_string(),
            cards: written,
            items: cards,
        })
    }
}

/// 挖掘结果（界面展示用）。
#[derive(Clone, Debug, Serialize)]
pub struct MinedReport {
    pub lesson_id: String,
    pub cards: usize,
    pub items: Vec<MinedCard>,
}

/// 卡的类型 → 平台复习卡类型。
fn review_card_type(kind: MinedCardKind) -> ReviewCardType {
    match kind {
        MinedCardKind::Cloze => ReviewCardType::FillBlank,
        MinedCardKind::Dictation | MinedCardKind::Translate => ReviewCardType::Qa,
    }
}

/// 题干：填空给挖空句；听写只写「听写这一句」；中译英给中文。
fn review_prompt(card: &MinedCard) -> String {
    match card.kind {
        MinedCardKind::Cloze => card.prompt.clone().unwrap_or_else(|| card.sentence.clone()),
        MinedCardKind::Dictation => "听写这一句".to_string(),
        MinedCardKind::Translate => card
            .chinese
            .clone()
            .unwrap_or_else(|| card.sentence.clone()),
    }
}

// ============================================================================
// RoadmapService（V13 W6：26 周能力路线图）
// ============================================================================

/// 一条检查项的展示形态（静态计划 → 接口 DTO）。
#[derive(Clone, Debug, Serialize)]
pub struct RoadmapCheckView {
    pub label: String,
    pub kind: String,
    pub current: u32,
    pub threshold: u32,
    pub unit: String,
    /// 是否自动判定（`self_reported` 为 false：界面要说明这是自己填的）。
    pub auto: bool,
    /// 达标 / 未达标。
    pub met: bool,
}

/// 一次能力检查的展示形态。
#[derive(Clone, Debug, Serialize)]
pub struct RoadmapCheckpointView {
    pub week: u32,
    pub focus: String,
    pub can_do: String,
    pub checks: Vec<RoadmapCheckView>,
    /// 全部自动项达标。
    pub complete: bool,
}

/// 路线图（当前所在位置 + 全部检查点）。
#[derive(Clone, Debug, Serialize)]
pub struct RoadmapView {
    /// 开始日期（Unix 秒）；没有记录时为 `None`。
    pub started_at: Option<i64>,
    /// 当前第几周（没有开始日时为 `None`）。
    pub current_week: Option<u32>,
    /// 距下一个检查点还有几天（没有开始日时为 `None`）。
    pub days_to_next: Option<i64>,
    /// 当前对应的检查点（`None` = 还没到第一个检查点）。
    pub current_checkpoint: Option<RoadmapCheckpointView>,
    /// 全部检查点。
    pub checkpoints: Vec<RoadmapCheckpointView>,
    /// 真实指标（界面上要能看到数字从哪来）。
    pub metrics: RoadmapMetricsView,
}

/// 真实指标的展示形态。
#[derive(Clone, Copy, Debug, Serialize)]
pub struct RoadmapMetricsView {
    pub lessons_completed: u32,
    pub spoken_minutes: i64,
    pub review_mastery: f64,
    pub sentence_cards: u32,
    pub words_learned: u32,
    pub streak_days: u32,
}

/// 路线图服务：把**静态计划**与**真实统计**拼成一张可执行的图。
///
/// ## 诚实边界（这一层最容易变成自欺欺人）
///
/// - 每一项都显示 `current / threshold`，不达标就显示不达标；
/// - **没有开始日就不显示「第几周」** —— 替用户编一个起点会让整张图失真；
/// - `self_reported` 项（敢不敢说、能不能听懂）**不参与自动判定**，
///   界面标注为自评；
/// - 数据全部来自已有服务的真实统计（课程进度 / 跟读记录 / 平台复习），不额外估算。
pub struct RoadmapService {
    course: Arc<CourseService>,
    speaking: Arc<SpeakingService>,
    platform: Arc<LearningService>,
}

impl RoadmapService {
    #[must_use]
    pub fn new(
        course: Arc<CourseService>,
        speaking: Arc<SpeakingService>,
        platform: Arc<LearningService>,
    ) -> Self {
        Self {
            course,
            speaking,
            platform,
        }
    }

    /// 组装路线图。
    pub fn view(&self, now: i64) -> Result<RoadmapView, ApplicationError> {
        let progress = self.course.english_progress(now)?;
        // 开口时长来自真实跟读记录（V13 W2），没有记录就是 0。
        let spoken = self.speaking.stats(None, 0)?;
        // 句子卡数量：来自平台复习卡里 entity_type = "sentence" 的真实卡片。
        let sentence_cards = self
            .platform
            .list_progress(Some(MODULE), None, 20_000)
            .map_err(platform)?
            .iter()
            .filter(|row| row.entity_type == "sentence")
            .count() as u32;
        // 开始日：取最近一次学习活动所在的**那一天 00:00**（本地语义），
        // 没有学习记录就 `None` —— 界面会问「从哪天开始算」，而不是替你编一个。
        let started_at = self.course.first_study_day(now);

        let metrics = RoadmapMetrics {
            lessons_completed: progress.lessons_completed,
            spoken_seconds: spoken.spoken_seconds,
            review_mastery: progress.review_mastery,
            sentence_cards,
            words_learned: progress.words_learned,
            streak_days: progress.streak_days,
        };

        let checkpoints: Vec<RoadmapCheckpointView> = ROADMAP
            .iter()
            .map(|week| checkpoint_view(week, &metrics))
            .collect();
        let current_week = started_at
            .map(|start| devtoolbox_core::language::current_week(start, now).unwrap_or(0));
        let next = current_week.and_then(|week| {
            ROADMAP
                .iter()
                .find(|item| item.week > week)
                .map(|item| i64::from(item.week))
        });
        // 距下一个检查点：目标周的第一天 − 今天。
        let days_to_next = match (started_at, next) {
            (Some(start), Some(target)) => Some(target * 7 - ((now - start) / 86_400)),
            _ => None,
        };
        Ok(RoadmapView {
            started_at,
            current_week,
            days_to_next,
            current_checkpoint: current_week
                .and_then(devtoolbox_core::language::latest_checkpoint)
                .map(|plan| checkpoint_view(plan, &metrics)),
            checkpoints,
            metrics: RoadmapMetricsView {
                lessons_completed: metrics.lessons_completed,
                spoken_minutes: metrics.spoken_seconds / 60,
                review_mastery: metrics.review_mastery,
                sentence_cards: metrics.sentence_cards,
                words_learned: metrics.words_learned,
                streak_days: metrics.streak_days,
            },
        })
    }
}

/// 静态计划 → 展示形态（逐项算达标）。
fn checkpoint_view(week: &RoadmapWeek, metrics: &RoadmapMetrics) -> RoadmapCheckpointView {
    let checks: Vec<RoadmapCheckView> = week
        .checks
        .iter()
        .map(|check| {
            let auto = check.kind != CheckKind::SelfReported;
            // 开口时长的内部单位是秒，展示单位是分钟 —— **两边都换算**，
            // 否则界面会出现「0 / 720 分钟」这种自相矛盾的数字。
            let (current, threshold) = if check.kind == CheckKind::SpokenSeconds {
                (
                    u32::try_from(metrics.spoken_seconds / 60).unwrap_or(0),
                    check.threshold / 60,
                )
            } else {
                (check.current(metrics), check.threshold)
            };
            RoadmapCheckView {
                label: check.label.to_string(),
                kind: format!("{:?}", check.kind).to_lowercase(),
                current,
                threshold,
                unit: check.unit().to_string(),
                auto,
                met: auto && check.is_met(metrics),
            }
        })
        .collect();
    RoadmapCheckpointView {
        week: week.week,
        focus: week.focus.to_string(),
        can_do: week.can_do.to_string(),
        checks,
        complete: devtoolbox_core::language::week_complete(week, metrics),
    }
}

/// 中文释义的第一条（`v. 犹豫；迟疑；踌躇` → 保留原样；多行取首行）。
fn first_meaning(translation: Option<&str>) -> Option<String> {
    translation?
        .lines()
        .map(str::trim)
        .find(|line| !line.is_empty())
        .map(str::to_string)
}

/// 把句子里的目标词挖空（大小写不敏感、整词匹配、保留原句其它部分）。
fn blank_word(sentence: &str, vocab: &LessonVocab) -> Option<String> {
    let targets = [vocab.surface.clone(), Some(vocab.word.clone())];
    for target in targets.into_iter().flatten() {
        let lower_sentence = sentence.to_ascii_lowercase();
        let lower_target = target.to_ascii_lowercase();
        let mut search_from = 0;
        while let Some(found) = lower_sentence[search_from..].find(&lower_target) {
            let start = search_from + found;
            let end = start + lower_target.len();
            let before_ok = start == 0
                || !lower_sentence[..start]
                    .chars()
                    .next_back()
                    .is_some_and(char::is_alphanumeric);
            let after_ok = end >= lower_sentence.len()
                || !lower_sentence[end..]
                    .chars()
                    .next()
                    .is_some_and(char::is_alphanumeric);
            if before_ok && after_ok {
                return Some(format!("{}_____{}", &sentence[..start], &sentence[end..]));
            }
            search_from = end;
        }
    }
    None
}

#[cfg(test)]
mod tests;

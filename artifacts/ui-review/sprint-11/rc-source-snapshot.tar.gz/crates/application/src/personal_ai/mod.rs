//! Personal AI Hub — application 层（V4）。
//!
//! 依赖方向：`devtoolbox-application::personal_ai` 只依赖 `devtoolbox-core::personal_ai`
//! 与 application 内既有 use case（如 `history::HistoryService`），零 infra 引用。
//! 组合根（apps/desktop）负责装配 Provider / Session / History 端口。

pub mod agent;
pub mod args;
pub mod cancellation;
pub mod context;
pub mod conversation;
pub mod documents;
pub mod exploration;
pub mod files;
pub mod geography;
pub mod history;
pub mod json_schema;
pub mod knowledge;
pub mod language;
pub mod learning;
pub mod memory;
pub mod news;
pub mod prompt;
pub mod registry;
pub mod retrieval;
pub mod rss;
pub mod runtime;
pub mod server;
pub mod session;
pub mod study_board;
pub mod travel;

pub use agent::{AgentConfig, PersonalAgent, PersonalHub};
pub use cancellation::AgentRunRegistry;
pub use context::{ContextBudget, ContextBundle, ModuleContextProvider, bundle_to_text};
pub use conversation::{ConversationService, ConversationStore, ConversationStoreError};
pub use documents::{
    DocumentsProviderOwned, DocumentsTools, documents_tool_names, register_documents,
};
pub use exploration::{
    GeographyReference, HistoryStoryContext, LocationHistoryLookup, ReviewedCrosswalk,
    VerifiedHistoryEvent, VerifiedLocationHistory, register_exploration,
};
pub use files::{FilesProviderOwned, FilesTools, files_tool_names, register_files};
pub use geography::{
    GeographyProviderOwned, GeographyTools, geography_tool_names, register_geography,
};
pub use history::{HistoryProviderOwned, HistoryTools, history_tool_names, register_history};
pub use knowledge::{
    KnowledgeProviderOwned, KnowledgeTools, knowledge_tool_names, register_knowledge,
};
pub use language::{LanguageProviderOwned, LanguageTools, language_tool_names, register_language};
pub use learning::{LearningReviewQuery, LearningTools, register_learning};
pub use memory::{MemoryProviderOwned, MemoryTools, memory_tool_names, register_memory};
pub use news::{NewsProviderOwned, NewsTools, news_tool_names, register_news};
pub use registry::{ModuleRegistration, ModuleRegistry, ToolExecutor, ToolRegistry, allowed_risk};
pub use retrieval::RetrievalAugmenter;
pub use rss::{RssProviderOwned, RssTools, register_rss, rss_tool_names};
pub use runtime::{ToolLoopConfig, ToolLoopOutcome, run_tool_loop};
pub use server::{ServerProviderOwned, ServerTools, register_server, server_tool_names};
pub use session::{InMemorySessionStore, SessionStore};
pub use study_board::{
    StudyBoardProviderOwned, StudyBoardTools, register_study_board, study_board_tool_names,
};
pub use travel::{
    TravelContextProvider, TravelTools, register_travel, register_travel_with_proposals,
    travel_tool_names,
};

/// agent 循环测试（Fake provider 五种场景，V4 §79）。
#[cfg(test)]
mod tests {}

// 这些依赖由同一 package 的 library target 使用；显式引用让 binary target 的
// workspace 级 `unused_crate_dependencies` lint 保持有效。
use devtoolbox_application as _;
use devtoolbox_core as _;
use devtoolbox_infrastructure as _;
use devtoolbox_runtime as _;
use parking_lot as _;
use reqwest as _;
use serde as _;
use serde_json as _;
use tauri as _;
use tauri_plugin_dialog as _;
use tauri_plugin_opener as _;
#[cfg(feature = "e2e")]
use tauri_plugin_wdio as _;
#[cfg(feature = "e2e")]
use tauri_plugin_wdio_webdriver as _;

fn main() {
    devtoolbox_desktop::run();
}

// 测试 target 使用 dev-dependencies；显式引用让 bin target 的 lint 满意。
#[cfg(test)]
use tempfile as _;

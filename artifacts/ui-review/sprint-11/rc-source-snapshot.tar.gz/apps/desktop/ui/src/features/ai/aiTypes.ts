/**
 * Personal AI 前端数据契约（V4 §11/§12/§13/§15）。
 *
 * 与后端 `crates/core/src/personal_ai/` 的 serde 形状一一对应；
 * 只读契约：字段名与后端冻结一致，勿改名。
 */
import type {
 DocumentType,
 MemoryCategory,
 MemorySensitivity,
 MemorySourceType,
 MemoryStatus,
} from "../knowledge/knowledgeTypes";

export interface AppEntityRef {
 kind: string;
 id: string;
 label?: string | null;
}

export interface AppContextPayload {
 module?: string | null;
 page?: string | null;
 entity?: AppEntityRef | null;
 selection?: { kind: string; id: string; text?: string | null } | null;
 view_state?: unknown;
}

export type AgentContentPart =
 | { type: "text"; text: string }
 | { type: "image"; data: string; mime: string; source: string; caption?: string | null };

export interface AgentRequest {
 message: string;
 parts?: AgentContentPart[];
 session_id?: string | null;
 app_context: AppContextPayload;
 /** 启用的模块列表（status.modules[].id）；空 = 全部 */
 capabilities: string[];
 locale?: string | null;
}

export interface AgentMessage {
 role: "user" | "assistant" | "tool";
 content: string;
}

export interface ToolTraceEntry {
 tool: string;
 ok: boolean;
 duration_ms: number;
 note?: string | null;
}

/** 单次 worker run（V9 §75：只含结构与计数，无 CoT / 无 secret）。 */
export interface OrchestrationRun {
  task_id: string;
  agent_id: string;
  state: string;
  status: string;
  duration_ms: number;
  tool_calls: number;
  tokens: number;
  error_code?: string | null;
}

/** 编排追踪视图（V9 §72/§74；V10 §20 决策遥测）。 */
export interface OrchestrationTrace {
  trace_id: string;
  decision: string;
  plan_rationale: string;
  runs: OrchestrationRun[];
  review?: string | null;
  merged: boolean;
  stopped_early?: string | null;
  /** V10：实际生效的决策 provider（rule / jev）。 */
  decision_provider?: string | null;
  /** V10：决策策略 label。 */
  decision_strategy?: string | null;
  /** V10：置信档位 high / uncertain / low。 */
  decision_confidence?: string | null;
  decision_reason_code?: string | null;
  decision_latency_ms?: number | null;
  /** V10：是否发生过 provider fallback。 */
  decision_fallback?: boolean;
  /** V10：shadow 模式下影子 provider 的策略（仅 label）。 */
  shadow_decision?: string | null;
  worker_count?: number;
}

/** 决策策略中文标签（V10 §38：只展示 label，禁止展示隐藏推理）。 */
export const DECISION_STRATEGY_LABELS: Record<string, string> = {
  direct: "直接回答",
  research_only: "检索取证",
  plan_and_research: "规划 + 检索",
  research_and_review: "检索 + 审查",
  bounded_multi_agent: "有界多 Agent",
};

export const DECISION_PROVIDER_LABELS: Record<string, string> = {
  rule: "规则",
  jev: "Jev",
};

export const DECISION_CONFIDENCE_LABELS: Record<string, string> = {
  high: "高",
  uncertain: "不确定",
  low: "低",
};

export function decisionStrategyLabel(strategy: string): string {
  return DECISION_STRATEGY_LABELS[strategy] ?? strategy;
}

export function decisionProviderLabel(provider: string): string {
  return DECISION_PROVIDER_LABELS[provider] ?? provider;
}

export function decisionConfidenceLabel(confidence: string): string {
  return DECISION_CONFIDENCE_LABELS[confidence] ?? confidence;
}

/** Agent 执行阶段（V11 过程可见性；label 由后端给，前端不翻译）。 */
export type AgentStageName =
  | "preparing"
  | "deciding"
  | "orchestrating"
  | "thinking"
  | "calling_tool"
  | "composing"
  | "done"
  | "failed";

export interface AgentProgressEvent {
  trace_id?: string | null;
  stage: AgentStageName;
  /** 阶段内细节（策略名 / 耗时 / 失败原因）。 */
  detail?: string | null;
  /** 失败时的稳定错误码（failed 阶段）。 */
  error_code?: string | null;
}

export const AGENT_STAGE_LABELS: Record<AgentStageName, string> = {
  preparing: "准备上下文",
  deciding: "选择策略",
  orchestrating: "多 Agent 执行",
  thinking: "模型思考",
  calling_tool: "调用工具",
  composing: "生成回答",
  done: "完成",
  failed: "失败",
};

/** 阶段顺序（用于渲染进度条；failed/done 是终止态）。 */
export const AGENT_STAGE_ORDER: AgentStageName[] = [
  "preparing",
  "deciding",
  "thinking",
  "calling_tool",
  "composing",
  "done",
];

/** 错误码 → 用户可读诊断（不知道也回落到原文，不隐藏信息）。 */
export const AGENT_ERROR_DIAGNOSIS: Record<string, string> = {
  personal_ai_model_unavailable:
    "模型不可用：未配置 AI（设置 → AI 填 base_url 与 model），或网络不可达。",
  personal_ai_provider_timeout: "模型响应超时：可提高 ai.timeout_secs 或换更快的模型。",
  personal_ai_provider_error: "模型返回错误：见下方详情（多为接口/参数/权限问题）。",
  personal_ai_tool_not_found: "工具不存在：模型尝试调用未注册的工具。",
  personal_ai_tool_invalid_argument: "工具参数不合法：模型给出的参数未通过校验。",
  personal_ai_tool_execution_failed: "工具执行失败：见下方工具轨迹。",
  personal_ai_max_tool_rounds: "工具调用轮数超限：请把问题拆小，或检查是否陷入循环。",
  personal_ai_session_error: "会话存储错误。",
  personal_ai_unsupported_input:
    "当前模型不支持这类输入（如图片）：切换到支持视觉的模型，或用文字描述。",
};

export function agentErrorDiagnosis(code: string | null | undefined, fallback: string): string {
  if (code && AGENT_ERROR_DIAGNOSIS[code]) {
    return `${AGENT_ERROR_DIAGNOSIS[code]}\n原始信息：${fallback}`;
  }
  return fallback;
}

/** Agent 角色中文标签（§76 UI）。 */
export const AGENT_ROLE_LABELS: Record<string, string> = {
  research: "检索",
  planner: "规划",
  reviewer: "审查",
  synthesizer: "综合",
};

export const AGENT_STATE_LABELS: Record<string, string> = {
  pending: "排队中",
  running: "进行中",
  completed: "已完成",
  failed: "失败",
  cancelled: "已取消",
  timed_out: "超时",
};

export function agentRoleLabel(id: string): string {
  return AGENT_ROLE_LABELS[id] ?? id;
}

export function agentStateLabel(state: string): string {
  return AGENT_STATE_LABELS[state] ?? state;
}

export type AgentActionKind =
 | "navigate"
 | "open_entity"
 | "refresh_view"
 | "show_panel"
 | "open_document"
 | "open_file"
 | "confirm_memory"
 /** V7：请求用户确认一个 SYSTEM 操作（携带确认票据）。 */
 | "confirm_action"
 /** V7：打开一个已注册应用（URL 来自注册表）。 */
 | "open_app";

export interface AgentAction {
 type: AgentActionKind;
 module: string;
 target: Record<string, unknown>;
}

export type UiBlockKind =
 | "entity_list"
 | "entity_card"
 | "source_list"
 | "key_value"
 | "timeline_preview"
 | "memory_list"
 | "document_list"
 | "document_card"
 | "document_reference"
 | "file_list";

export interface UiBlock {
 kind: UiBlockKind;
 title: string;
 data: unknown;
}

export interface AgentUsage {
 input_tokens: number;
 output_tokens: number;
 total_tokens: number;
 duration_ms: number;
 tool_rounds: number;
}

export type AgentCitationRole = "current_entity" | "verified_association" | "story_context" | "evidence";

export interface AgentCitation {
 module: string;
 entity_type: string;
 entity_id: string;
 title: string;
 role: AgentCitationRole;
 source_ids?: string[];
}

export interface AgentProposedChange {
 id: string;
 operation: string;
 title: string;
 expires_at: number;
 expected_revision?: number | null;
 before: unknown;
 after: unknown;
}

export interface AgentResponse {
 session_id: string;
 trace_id?: string | null;
 citations?: AgentCitation[];
 proposed_changes?: AgentProposedChange[];
 message: string;
 actions: AgentAction[];
 ui_blocks: UiBlock[];
 tool_trace: ToolTraceEntry[];
 usage?: AgentUsage | null;
 messages: AgentMessage[];
 provider?: string | null;
 model?: string | null;
 /** 多 Agent 编排追踪（无则未委派）。 */
 orchestration?: OrchestrationTrace | null;
}

export interface ToolSpecLite {
 name: string;
 description: string;
 risk: "read" | "safe_write" | "sensitive_write" | "system";
 module: string;
}

export interface ModuleDescriptorLite {
 id: string;
 display_name: string;
 description: string;
 capabilities: string[];
 tools: string[];
}

export interface AiStatus {
 configured: boolean;
 provider: string | null;
 model: string | null;
 modules: ModuleDescriptorLite[];
 tools: ToolSpecLite[];
}

/** EntityList UI Block 的条目形状（宽松兼容后端 schemas）。 */
export interface EntityListItem {
 id?: string;
 entity_id?: string;
 kind?: string;
 title?: string;
 name?: string;
 subtitle?: string | null;
 start_year?: number | null;
 end_year?: number | null;
}

export function entityListItems(block: UiBlock): EntityListItem[] {
 const raw = block.data;
 if (!Array.isArray(raw)) return [];
 return raw as EntityListItem[];
}

// ---------------------------------------------------------------------------
// Personal Knowledge UI Blocks（V6 §5）—— 形状与后端模块适配器冻结一致
// ---------------------------------------------------------------------------

/** `memory_list` UI Block 的条目。 */
export interface MemoryListItem {
 id: string;
 category: MemoryCategory;
 category_label?: string | null;
 content: string;
 status?: MemoryStatus | null;
 source_type?: MemorySourceType | null;
 sensitivity?: MemorySensitivity | null;
 updated_at?: number | null;
 needs_confirmation?: boolean | null;
}

/** `document_list` UI Block 的条目。 */
export interface DocumentListItem {
 document_id: string;
 title: string;
 document_type?: DocumentType | null;
 relative_path?: string | null;
 location?: string | null;
 snippet?: string | null;
 score?: number | null;
 modified_at?: number | null;
}

/** `document_card` UI Block 的数据。 */
export interface DocumentCardData {
 document_id: string;
 title: string;
 document_type?: DocumentType | null;
 path?: string | null;
 relative_path?: string | null;
 size_bytes?: number | null;
 modified_at?: number | null;
 chunk_count?: number | null;
 content_available?: boolean | null;
 index_error?: string | null;
}

/** `document_reference` UI Block 的数据。 */
export interface DocumentReferenceData {
 document_id: string;
 title: string;
 location?: string | null;
 snippet?: string | null;
}

/** `file_list` UI Block 的条目。 */
export interface FileListItem {
 file_id?: string | null;
 file_name: string;
 relative_path?: string | null;
 path?: string | null;
 extension?: string | null;
 size_bytes?: number | null;
 modified_at?: number | null;
 restricted?: boolean | null;
}

/** Block 的 `data.items` 数组（形状不符时返回空数组，渲染层优雅降级）。 */
function blockItems<T>(block: UiBlock): T[] {
 const items = (block.data as { items?: unknown } | null | undefined)?.items;
 return Array.isArray(items) ? (items as T[]) : [];
}

export function memoryListItems(block: UiBlock): MemoryListItem[] {
 return blockItems<MemoryListItem>(block);
}

export function documentListItems(block: UiBlock): DocumentListItem[] {
 return blockItems<DocumentListItem>(block);
}

export function fileListItems(block: UiBlock): FileListItem[] {
 return blockItems<FileListItem>(block);
}

export function documentCardData(block: UiBlock): DocumentCardData | null {
 const data = block.data;
 if (!data || typeof data !== "object" || Array.isArray(data)) return null;
 return data as DocumentCardData;
}

export function documentReferenceData(
 block: UiBlock,
): DocumentReferenceData | null {
 const data = block.data;
 if (!data || typeof data !== "object" || Array.isArray(data)) return null;
 return data as DocumentReferenceData;
}

// ---------------------------------------------------------------------------
// History Enrichment（V5 Gate 4/8）—— 与后端 core/history_enrichment 契约一致
// ---------------------------------------------------------------------------

export type EnrichmentState =
 | "MISSING"
 | "GENERATING"
 | "READY"
 | "STALE"
 | "FAILED"
 | "REVIEWED";

export interface EnrichmentSectionInfo {
 section: "overview" | "background" | "impact";
 state: EnrichmentState;
}

export interface EnrichmentClaimDto {
 text: string;
 source_ids: string[];
}

export interface EnrichmentPayloadDto {
 section: string;
 content: string;
 claims: EnrichmentClaimDto[];
 uncertainties: string[];
 controversies: string[];
}

export interface EnrichmentMetadataDto {
 generated_at: number;
 refreshed_at: number;
 model: string | null;
 provider: string | null;
 prompt_version: string;
 schema_version: number;
 canonical_revision: string | null;
 source_ids: string[];
 generation_count: number;
}

export interface EnrichmentViewDto {
 key: {
  entity_type: string;
  entity_id: string;
  section: string;
  locale: string;
  schema_version: number;
 };
 state: EnrichmentState;
 payload: EnrichmentPayloadDto | null;
 metadata: EnrichmentMetadataDto | null;
 error: string | null;
}

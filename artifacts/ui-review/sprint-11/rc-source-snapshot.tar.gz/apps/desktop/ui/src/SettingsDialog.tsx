import { Database, X } from "@phosphor-icons/react";
import { useCallback, useEffect, useState } from "react";
import type {
  AiSettings,
  KnowledgeRoot,
  KnowledgeSettings,
  McpSettings,
  ServerApplicationDescriptor,
  ServerServiceDescriptor,
  ServerSettings,
  SourceInfo,
  SecretSettingsField,
  SecretSettingsStatus,
  SecretSettingsUpdate,
  TravelSearchBackend,
  TravelSettings,
} from "./types";
import { languageClient } from "./features/language/languageClient";
import { travelClient } from "./features/travel/travelClient";
import { allThemes, getTheme } from "./theme/ThemeManager";
import { errorMessage, isTauriRuntime } from "./utils";

interface SettingsDialogProps {
  themeId: string;
  onThemeChange: (themeId: string) => void;
  rssRefreshMinutes: number;
  onRefreshMinutesChange: (minutes: number) => void;
  travel: TravelSettings;
  onTravelChange: (travel: TravelSettings) => void;
  secretStatus: SecretSettingsStatus;
  onSecretsChange: (update: SecretSettingsUpdate) => Promise<void>;
  ai: AiSettings;
  onAiChange: (ai: AiSettings) => void;
  knowledge: KnowledgeSettings;
  onKnowledgeChange: (knowledge: KnowledgeSettings) => void;
  server: ServerSettings;
  onServerChange: (server: ServerSettings) => void;
  onClose: () => void;
}

const REFRESH_CHOICES = [15, 30, 60];

const SEARCH_BACKENDS: { value: TravelSearchBackend; label: string }[] = [
  { value: "auto", label: "自动（Bing 中国 → 百度）" },
  { value: "searxng", label: "本地 SearXNG（推荐自托管）" },
  { value: "baidu", label: "百度" },
  { value: "bing", label: "Bing 中国" },
];

/**
 * 全局设置。
 * 目前包含:Appearance(界面风格)、RSS(刷新间隔)与 Travel(搜索后端 / LLM / 可选数据源 Key)。
 * Travel 全部为可选配置：未配置时模块仍可运行（搜索用默认后端、无 LLM 降级为来源列表）。
 */
export function SettingsDialog({
  themeId,
  onThemeChange,
  rssRefreshMinutes,
  onRefreshMinutesChange,
  travel,
  onTravelChange,
  secretStatus,
  onSecretsChange,
  ai,
  onAiChange,
  knowledge,
  onKnowledgeChange,
  server,
  onServerChange,
  onClose,
}: SettingsDialogProps) {
  const current = getTheme(themeId);
  const canManageSettings = isTauriRuntime();
  const [testing, setTesting] = useState<"llm" | "amap" | "qweather" | null>(null);
  const [testResults, setTestResults] = useState<
    Partial<Record<"llm" | "amap" | "qweather", string>>
  >({});
  const [secretDrafts, setSecretDrafts] = useState<
    Partial<Record<SecretSettingsField, string>>
  >({});
  const [secretNotice, setSecretNotice] = useState("");
  const [savingSecrets, setSavingSecrets] = useState(false);
  const updateTravel = (patch: Partial<TravelSettings>) =>
    onTravelChange({ ...travel, ...patch });
  const updateAi = (patch: Partial<AiSettings>) =>
    onAiChange({ ...ai, ...patch });
  const updateKnowledge = (patch: Partial<KnowledgeSettings>) =>
    onKnowledgeChange({ ...knowledge, ...patch });
  const persistSecretUpdates = async (updates: SecretSettingsUpdate["updates"]) => {
    if (!isTauriRuntime() || updates.length === 0) return;
    setSavingSecrets(true);
    setSecretNotice("");
    try {
      await onSecretsChange({ updates });
      const saved = new Set(updates.map((item) => item.field));
      setSecretDrafts((current) => {
        const next = { ...current };
        saved.forEach((field) => delete next[field]);
        return next;
      });
      setSecretNotice("凭据已安全保存到本机后端。");
    } catch (error) {
      setSecretNotice(`保存凭据失败：${errorMessage(error)}`);
    } finally {
      setSavingSecrets(false);
    }
  };
  const saveSecretFields = (fields: SecretSettingsField[]) =>
    void persistSecretUpdates(
      fields
        .filter((field) => secretDrafts[field] !== undefined)
        .map((field) => ({ field, value: secretDrafts[field] || null })),
    );
  const clearSecret = (field: SecretSettingsField) =>
    void persistSecretUpdates([{ field, value: null }]);
  const changeSecretDraft = (field: SecretSettingsField, value: string) =>
    setSecretDrafts((current) => ({ ...current, [field]: value }));

  const runTest = async (kind: "llm" | "amap" | "qweather") => {
    if (!isTauriRuntime()) return;
    setTesting(kind);
    setTestResults((current) => ({ ...current, [kind]: "" }));
    try {
      const result =
        kind === "llm"
          ? await travelClient.testLlm({
              baseUrl: travel.llm_base_url ?? "",
              apiKey: secretDrafts.travel_llm_api_key ?? null,
              model: travel.llm_model ?? "",
            })
          : kind === "amap"
            ? await travelClient.testAmap({
                apiKey: secretDrafts.travel_amap_api_key ?? "",
                apiHost: null,
              })
            : await travelClient.testQweather({
                apiKey: secretDrafts.travel_qweather_api_key ?? "",
                apiHost: travel.qweather_api_host,
              });
      setTestResults((current) => ({ ...current, [kind]: result }));
    } catch (error) {
      setTestResults((current) => ({
        ...current,
        [kind]: `连接失败：${errorMessage(error)}`,
      }));
    } finally {
      setTesting(null);
    }
  };
  return (
    <div className="settings-backdrop" onMouseDown={onClose}>
      <section
        className="settings-dialog"
        onMouseDown={(event) => event.stopPropagation()}
        aria-label="设置"
      >
        <header>
          <div>
            <h2>设置</h2>
            <p className="settings-subtitle">
              个性化 DevToolbox 的外观与行为。
            </p>
          </div>
          <button title="关闭设置" onClick={onClose}>
            <X size={16} />
          </button>
        </header>
        <div className="settings-body">
          {!canManageSettings ? (
            <p className="settings-hint" role="status">
              当前为网页预览：配置更改不会持久化，凭据保存和 Provider 测试仅可在本机桌面应用中使用；服务端认证管理接口尚未启用。
            </p>
          ) : null}
          {secretNotice ? <p className="settings-hint" role="status">{secretNotice}</p> : null}
          <section className="settings-section">
            {/* 主题控件已由 <select> 改为 radiogroup，这里不再有对应的表单 id；
                保留 htmlFor 会指向不存在的 #ui-theme-select。 */}
            <span className="settings-label">界面风格</span>
            <p className="settings-hint">
              切换立即生效,无需重启;下次启动自动恢复。
            </p>
            <div className="settings-theme-grid" role="radiogroup" aria-label="主题选择">
              {allThemes().map((theme) => {
                const isActive = theme.id === current.id;
                return (
                  <button
                    key={theme.id}
                    type="button"
                    className={"theme-card-option" + (isActive ? " active" : "")}
                    onClick={() => onThemeChange(theme.id)}
                    role="radio"
                    aria-checked={isActive}
                  >
                    <div className="theme-card-header">
                      <strong>{theme.name}</strong>
                      <span className="theme-card-appearance">
                        {theme.appearance === "light" ? "浅色" : "深色"}
                      </span>
                    </div>
                    {theme.previewColors ? (
                      <div className="theme-color-dots">
                        {theme.previewColors.map((color, idx) => (
                          <span
                            key={idx}
                            className="theme-color-dot"
                            style={{ backgroundColor: color }}
                            title={color}
                          />
                        ))}
                      </div>
                    ) : null}
                  </button>
                );
              })}
            </div>
            <p className="settings-theme-description" style={{ marginTop: 8 }}>
              {current.description}
            </p>
          </section>
          <section className="settings-section">
            <label className="settings-label">Geography · 地图服务</label>
            <p className="settings-hint">
              地形图使用 MapLibre 与公开地理数据。高德 JS SDK 需要把 Key 暴露给浏览器，因此当前不在客户端加载；行政区边界服务端代理尚未接入。
            </p>
            {secretStatus.geography_amap_api_key_configured || secretStatus.geography_amap_security_js_code_configured ? (
              <div>
                <p className="settings-hint">检测到旧的高德浏览器凭据，仍安全保存在后端且不会传给页面；目前不会被地图使用。</p>
                <button
                  className="settings-test-button"
                  disabled={savingSecrets || !isTauriRuntime()}
                  onClick={() => void persistSecretUpdates([
                    { field: "geography_amap_api_key", value: null },
                    { field: "geography_amap_security_js_code", value: null },
                  ])}
                >
                  清除未使用的高德凭据
                </button>
              </div>
            ) : null}
          </section>
          <section className="settings-section">
            <label className="settings-label" htmlFor="rss-refresh-select">
              RSS 刷新频率
            </label>
            <p className="settings-hint">后台按此间隔自动拉取订阅更新。</p>
            <select
              className="settings-select"
              id="rss-refresh-select"
              value={rssRefreshMinutes}
              onChange={(event) =>
                onRefreshMinutesChange(Number(event.target.value))
              }
            >
              {REFRESH_CHOICES.map((minutes) => (
                <option key={minutes} value={minutes}>
                  每 {minutes} 分钟
                </option>
              ))}
            </select>
          </section>
          <section className="settings-section">
            <label className="settings-label" htmlFor="travel-backend-select">
              Travel · 搜索后端
            </label>
            <p className="settings-hint">
              优先使用国内可访问的搜索引擎；SearXNG 未配置 / 不可用时自动回退
              Bing 中国。海外搜索仅作可选的后续扩展，不作为必需依赖。
            </p>
            <select
              className="settings-select"
              id="travel-backend-select"
              value={travel.search_backend}
              onChange={(event) =>
                updateTravel({
                  search_backend: event.target.value as TravelSearchBackend,
                })
              }
            >
              {SEARCH_BACKENDS.map((backend) => (
                <option key={backend.value} value={backend.value}>
                  {backend.label}
                </option>
              ))}
            </select>
            {travel.search_backend === "searxng" ? (
              <>
                <label
                  className="settings-label"
                  htmlFor="travel-searxng-url"
                  style={{ marginTop: 10 }}
                >
                  SearXNG 地址
                </label>
                <input
                  className="settings-select"
                  id="travel-searxng-url"
                  type="text"
                  placeholder="http://localhost:8080"
                  value={travel.searxng_url ?? ""}
                  onChange={(event) =>
                    updateTravel({ searxng_url: event.target.value || null })
                  }
                />
              </>
            ) : null}
          </section>
          <section className="settings-section">
            <label className="settings-label" htmlFor="travel-llm-base">
              Travel · LLM（OpenAI Compatible）
            </label>
            <p className="settings-hint">
              用于补充搜索主题、提取事实与生成结构化攻略。支持 DeepSeek / Qwen /
              OpenAI / 本地 Ollama（http://localhost:11434/v1）。留空时 Travel
              以“来源列表”模式运行。
            </p>
            <input
              className="settings-select"
              id="travel-llm-base"
              type="text"
              placeholder="https://api.deepseek.com/v1"
              value={travel.llm_base_url ?? ""}
              onChange={(event) =>
                updateTravel({ llm_base_url: event.target.value || null })
              }
            />
            <label
              className="settings-label"
              htmlFor="travel-llm-model"
              style={{ marginTop: 10 }}
            >
              模型
            </label>
            <input
              className="settings-select"
              id="travel-llm-model"
              type="text"
              placeholder="deepseek-chat / qwen-plus / qwen2.5:7b"
              value={travel.llm_model ?? ""}
              onChange={(event) =>
                updateTravel({ llm_model: event.target.value || null })
              }
            />
            <label
              className="settings-label"
              htmlFor="travel-llm-key"
              style={{ marginTop: 10 }}
            >
              API Key（本地 Ollama 可留空）
            </label>
            <input
              className="settings-select"
              id="travel-llm-key"
              disabled={!canManageSettings}
              type="password"
              placeholder={secretStatus.travel_llm_api_key_configured ? "已保存；输入新值以替换" : "sk-..."}
              value={secretDrafts.travel_llm_api_key ?? ""}
              onChange={(event) => changeSecretDraft("travel_llm_api_key", event.target.value)}
            />
            <button
              className="settings-test-button"
              disabled={!canManageSettings || savingSecrets || secretDrafts.travel_llm_api_key === undefined}
              onClick={() => saveSecretFields(["travel_llm_api_key"])}
            >
              保存 Travel LLM Key
            </button>
            {secretStatus.travel_llm_api_key_configured ? (
              <button className="settings-test-button" disabled={!canManageSettings || savingSecrets} onClick={() => clearSecret("travel_llm_api_key")}>清除已保存的 Key</button>
            ) : null}
            <button
              className="settings-test-button"
              disabled={
                !canManageSettings ||
                testing !== null ||
                !travel.llm_base_url?.trim() ||
                !travel.llm_model?.trim() ||
                (secretStatus.travel_llm_api_key_configured && !secretDrafts.travel_llm_api_key)
              }
              onClick={() => void runTest("llm")}
            >
              {testing === "llm" ? "正在测试…" : "测试 LLM 连接"}
            </button>
            {testResults.llm ? (
              <p
                className={
                  testResults.llm.startsWith("连接失败")
                    ? "settings-test-result failed"
                    : "settings-test-result"
                }
              >
                {testResults.llm}
              </p>
            ) : null}
          </section>
          <section className="settings-section">
            <label className="settings-label">Ask AI（Personal AI）</label>
            <p className="settings-hint">
              全局 AI 助手配置（OpenAI Compatible：DeepSeek / Qwen / OpenAI /
              本地 Ollama http://localhost:11434/v1）。未配置时 AI
              面板显示未配置状态，其余功能不受影响。Key 通过本机专用写入操作保存；普通配置读取仅返回 configured 状态，不返回原值，错误和日志也不会输出密钥。
            </p>
            <label className="settings-label" htmlFor="ai-base">
              API Base URL
            </label>
            <input
              className="settings-select"
              id="ai-base"
              type="text"
              placeholder="https://api.deepseek.com/v1"
              value={ai.base_url ?? ""}
              onChange={(event) =>
                updateAi({ base_url: event.target.value || null })
              }
            />
            <label
              className="settings-label"
              htmlFor="ai-model"
              style={{ marginTop: 10 }}
            >
              模型
            </label>
            <input
              className="settings-select"
              id="ai-model"
              type="text"
              placeholder="deepseek-chat / qwen-plus / qwen2.5:7b"
              value={ai.model ?? ""}
              onChange={(event) =>
                updateAi({ model: event.target.value || null })
              }
            />
            <label
              className="settings-label"
              htmlFor="ai-key"
              style={{ marginTop: 10 }}
            >
              API Key（本地 Ollama 可留空）
            </label>
            <input
              className="settings-select"
              id="ai-key"
              disabled={!canManageSettings}
              type="password"
              placeholder={secretStatus.ai_api_key_configured ? "已保存；输入新值以替换" : "sk-..."}
              value={secretDrafts.ai_api_key ?? ""}
              onChange={(event) => changeSecretDraft("ai_api_key", event.target.value)}
            />
            <button
              className="settings-test-button"
              disabled={!canManageSettings || savingSecrets || secretDrafts.ai_api_key === undefined}
              onClick={() => saveSecretFields(["ai_api_key"])}
            >
              保存 AI Key
            </button>
            {secretStatus.ai_api_key_configured ? (
              <button className="settings-test-button" disabled={!canManageSettings || savingSecrets} onClick={() => clearSecret("ai_api_key")}>清除已保存的 Key</button>
            ) : null}
            <label
              className="settings-label"
              htmlFor="ai-timeout"
              style={{ marginTop: 10 }}
            >
              超时（秒，可选）
            </label>
            <input
              className="settings-select"
              id="ai-timeout"
              type="number"
              min={1}
              placeholder="120"
              value={ai.timeout_secs ?? ""}
              onChange={(event) => {
                const value = event.target.value.trim();
                updateAi({
                  timeout_secs: value ? Number(value) : null,
                });
              }}
            />
          </section>
          <section className="settings-section">
            <label className="settings-label">Travel · 可选数据源 Key</label>
            <p className="settings-hint">
              高德 POI
              与和风天气已接入；百度地图预留。和风天气请填写控制台“设置”中的专属
              API Host（不再使用 devapi.qweather.com）。全部可选：不填时 Travel
              核心功能不受影响。
            </p>
            <input
              className="settings-select"
              type="password"
              disabled={!canManageSettings}
              placeholder={secretStatus.travel_amap_api_key_configured ? "已保存；输入新值以替换" : "高德 AMAP_API_KEY（Web服务类型）"}
              value={secretDrafts.travel_amap_api_key ?? ""}
              onChange={(event) => changeSecretDraft("travel_amap_api_key", event.target.value)}
              style={{ marginTop: 6 }}
            />
            <button
              className="settings-test-button"
              disabled={!canManageSettings || testing !== null || !secretDrafts.travel_amap_api_key?.trim()}
              onClick={() => void runTest("amap")}
            >
              {testing === "amap" ? "正在测试…" : "测试高德连接"}
            </button>
            {testResults.amap ? (
              <p
                className={
                  testResults.amap.startsWith("连接失败")
                    ? "settings-test-result failed"
                    : "settings-test-result"
                }
              >
                {testResults.amap}
              </p>
            ) : null}
            <input
              className="settings-select"
              type="text"
              placeholder="和风天气 API Host，例如 abc123.qweatherapi.com"
              value={travel.qweather_api_host ?? ""}
              onChange={(event) =>
                updateTravel({ qweather_api_host: event.target.value || null })
              }
              style={{ marginTop: 10 }}
            />
            <input
              className="settings-select"
              type="password"
              disabled={!canManageSettings}
              placeholder={secretStatus.travel_qweather_api_key_configured ? "已保存；输入新值以替换" : "和风天气 QWEATHER_API_KEY（可选）"}
              value={secretDrafts.travel_qweather_api_key ?? ""}
              onChange={(event) => changeSecretDraft("travel_qweather_api_key", event.target.value)}
              style={{ marginTop: 6 }}
            />
            <button
              className="settings-test-button"
              disabled={
                !canManageSettings ||
                testing !== null ||
                !secretDrafts.travel_qweather_api_key?.trim() ||
                !travel.qweather_api_host?.trim()
              }
              onClick={() => void runTest("qweather")}
            >
              {testing === "qweather" ? "正在测试…" : "测试和风天气连接"}
            </button>
            <input
              className="settings-select"
              type="password"
              disabled={!canManageSettings}
              placeholder={secretStatus.travel_baidu_map_api_key_configured ? "已保存；输入新值以替换" : "百度地图 BAIDU_MAP_API_KEY（预留）"}
              value={secretDrafts.travel_baidu_map_api_key ?? ""}
              onChange={(event) => changeSecretDraft("travel_baidu_map_api_key", event.target.value)}
              style={{ marginTop: 6 }}
            />
            <button
              className="settings-test-button"
              disabled={!canManageSettings || savingSecrets || ![
                "travel_amap_api_key",
                "travel_qweather_api_key",
                "travel_baidu_map_api_key",
              ].some((field) => secretDrafts[field as SecretSettingsField] !== undefined)}
              onClick={() => saveSecretFields([
                "travel_amap_api_key",
                "travel_qweather_api_key",
                "travel_baidu_map_api_key",
              ])}
            >
              保存数据源凭据
            </button>
            {secretStatus.travel_amap_api_key_configured ? <button className="settings-test-button" disabled={!canManageSettings || savingSecrets} onClick={() => clearSecret("travel_amap_api_key")}>清除高德 Key</button> : null}
            {secretStatus.travel_qweather_api_key_configured ? <button className="settings-test-button" disabled={!canManageSettings || savingSecrets} onClick={() => clearSecret("travel_qweather_api_key")}>清除和风天气 Key</button> : null}
            {secretStatus.travel_baidu_map_api_key_configured ? <button className="settings-test-button" disabled={!canManageSettings || savingSecrets} onClick={() => clearSecret("travel_baidu_map_api_key")}>清除百度地图 Key</button> : null}
            {testResults.qweather ? (
              <p
                className={
                  testResults.qweather.startsWith("连接失败")
                    ? "settings-test-result failed"
                    : "settings-test-result"
                }
              >
                {testResults.qweather}
              </p>
            ) : null}
          </section>
          <section className="settings-section">
            <label className="settings-label">Language · 语言数据（#90）</label>
            <p className="settings-hint">
              所有词条均可追溯来源；许可能力位（署名/商用/再分发/相同方式共享）在下方展示。内置
              Starter Pack 为真实数据子集，完整数据包用{" "}
              <code>language-data import …</code>{" "}
              导入（docs/language/DATA_SOURCES.md）。
            </p>
            <LanguageDataSection />
          </section>
          <KnowledgeSection
            knowledge={knowledge}
            onChange={updateKnowledge}
          />
          <ServerSection server={server} onChange={onServerChange} />
          <McpSection server={server} onChange={onServerChange} />
        </div>
      </section>
    </div>
  );
}

/** Language Data（#90）：来源/版本/许可/导入条目数 + 安装内置 Starter Pack。 */
function LanguageDataSection() {
  const [sources, setSources] = useState<SourceInfo[]>([]);
  const [installNotice, setInstallNotice] = useState("");
  const [installing, setInstalling] = useState(false);

  const reload = useCallback(async () => {
    if (!isTauriRuntime()) return;
    try {
      setSources(await languageClient.sources());
    } catch {
      // 设置面板静默失败
    }
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  const install = async () => {
    if (!isTauriRuntime() || installing) return;
    setInstalling(true);
    setInstallNotice("");
    try {
      const report = await languageClient.installStarter();
      setInstallNotice(
        `已安装：+${report.total_inserted} 条，更新 ${report.total_updated} 条`,
      );
      void reload();
    } catch (error) {
      setInstallNotice(`安装失败：${errorMessage(error)}`);
    } finally {
      setInstalling(false);
    }
  };

  return (
    <div className="lang-sources-settings">
      <button
        className="settings-test-button"
        onClick={() => void install()}
        disabled={installing}
      >
        <Database size={14} />
        {installing ? "安装中…" : "安装 Starter Pack（内置真实数据子集）"}
      </button>
      {installNotice ? (
        <p className="settings-test-result">{installNotice}</p>
      ) : null}
      {sources.length === 0 ? (
        <p className="settings-hint">
          尚未导入数据源（可点击上方按钮安装内置包）。
        </p>
      ) : (
        <ul className="lang-sources-list">
          {sources.map((item) => (
            <li key={item.source.id}>
              <div className="lang-source-row">
                <b>{item.source.name}</b>
                <span>
                  {item.source.license.kind}
                  {item.source.license.attribution_required ? " · 需署名" : ""}
                </span>
                <small>
                  {item.source.dataset_version} · {item.item_count} 条
                </small>
              </div>
              <p className="lang-muted">
                {item.source.attribution || item.source.homepage}
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/**
 * 知识库允许目录（V6 §44）：AI 只能在这些根内检索 / 读元数据 / 安全读取。
 * 空 = 未配置：Documents / Files 页面会如实报告未配置，而不是报错。
 */
function KnowledgeSection({
  knowledge,
  onChange,
}: {
  knowledge: KnowledgeSettings;
  onChange: (patch: Partial<KnowledgeSettings>) => void;
}) {
  const [draft, setDraft] = useState({ label: "", path: "" });
  const [notice, setNotice] = useState<string | null>(null);

  const addRoot = (scope: "file_roots" | "document_roots") => {
    const label = draft.label.trim();
    const path = draft.path.trim();
    if (!path) {
      setNotice("请填写目录绝对路径");
      return;
    }
    const id = `kn-${path.replace(/[^a-zA-Z0-9]+/g, "-").toLowerCase()}`;
    if (knowledge[scope].some((root) => root.path === path)) {
      setNotice("该目录已在列表中");
      return;
    }
    onChange({
      [scope]: [...knowledge[scope], { id, label: label || path, path, enabled: true }],
    } as Partial<KnowledgeSettings>);
    setDraft({ label: "", path: "" });
    setNotice(null);
  };

  const removeRoot = (scope: "file_roots" | "document_roots", id: string) =>
    onChange({ [scope]: knowledge[scope].filter((root) => root.id !== id) } as Partial<KnowledgeSettings>);

  const toggleRoot = (scope: "file_roots" | "document_roots", id: string) =>
    onChange({
      [scope]: knowledge[scope].map((root) =>
        root.id === id ? { ...root, enabled: !root.enabled } : root,
      ),
    } as Partial<KnowledgeSettings>);

  return (
    <section className="settings-section">
      <label className="settings-label">Knowledge · 知识库允许目录</label>
      <p className="settings-hint">
        AI 只能在这些目录内检索文件与文档，且<strong>只读</strong>
        ：不会写入、移动或删除任何文件。留空表示未配置（知识页会如实提示）。
      </p>

      {(["file_roots", "document_roots"] as const).map((scope) => (
        <div key={scope} style={{ marginTop: 12 }}>
          <span className="settings-label">
            {scope === "file_roots" ? "文件允许根（Files）" : "文档索引根（Documents，留空复用文件根）"}
          </span>
          {knowledge[scope].length === 0 ? (
            <p className="settings-hint">尚未配置。</p>
          ) : (
            <ul className="settings-roots">
              {knowledge[scope].map((root) => (
                <li key={root.id}>
                  <label>
                    <input
                      type="checkbox"
                      checked={root.enabled}
                      onChange={() => toggleRoot(scope, root.id)}
                    />
                    {root.label || root.path}
                    <code>{root.path}</code>
                  </label>
                  <button
                    className="settings-test-button"
                    onClick={() => removeRoot(scope, root.id)}
                  >
                    移除
                  </button>
                </li>
              ))}
            </ul>
          )}
          <div className="settings-root-form">
            <input
              className="settings-select"
              type="text"
              placeholder="显示名（可选）"
              value={draft.label}
              onChange={(event) => setDraft({ ...draft, label: event.target.value })}
            />
            <input
              className="settings-select"
              type="text"
              placeholder="目录绝对路径，例如 D:/notes"
              value={draft.path}
              onChange={(event) => setDraft({ ...draft, path: event.target.value })}
            />
            <button className="settings-test-button" onClick={() => addRoot(scope)}>
              添加
            </button>
          </div>
        </div>
      ))}

      <div className="settings-inline">
        <label className="settings-label">单文档索引上限（字节）</label>
        <input
          className="settings-select"
          type="number"
          min={1}
          value={knowledge.max_document_bytes}
          onChange={(event) =>
            onChange({ max_document_bytes: Number(event.target.value) || 1_000_000 })
          }
        />
        <label className="settings-label">单次安全读取字符上限</label>
        <input
          className="settings-select"
          type="number"
          min={1}
          value={knowledge.max_read_chars}
          onChange={(event) =>
            onChange({ max_read_chars: Number(event.target.value) || 20_000 })
          }
        />
        <label className="settings-label">索引文件数上限</label>
        <input
          className="settings-select"
          type="number"
          min={1}
          value={knowledge.max_indexed_files}
          onChange={(event) =>
            onChange({ max_indexed_files: Number(event.target.value) || 5_000 })
          }
        />
        <label className="settings-checkbox">
          <input
            type="checkbox"
            checked={knowledge.startup_sync}
            onChange={(event) => onChange({ startup_sync: event.target.checked })}
          />
          启动时执行一次轻量索引同步
        </label>
      </div>
      {notice ? <p className="settings-hint">{notice}</p> : null}
    </section>
  );
}

/**
 * Home Server 注册表（V7 §26/§42）。
 *
 * 显式注册：空 = AI 无可操作目标（fail-closed）。`provider_ref`
 * （launchd label）由 infrastructure 映射，模型永远看不到（§36）。
 */
function ServerSection({
  server,
  onChange,
}: {
  server: ServerSettings;
  onChange: (server: ServerSettings) => void;
}) {
  const [serviceDraft, setServiceDraft] = useState({
    id: "",
    displayName: "",
    providerRef: "",
  });
  const [appDraft, setAppDraft] = useState({ id: "", name: "", url: "" });
  const [notice, setNotice] = useState<string | null>(null);

  const patch = (next: Partial<ServerSettings>) => onChange({ ...server, ...next });

  const addService = () => {
    const id = serviceDraft.id.trim();
    const providerRef = serviceDraft.providerRef.trim();
    if (!/^[a-z0-9][a-z0-9._-]{0,63}$/.test(id)) {
      setNotice("服务 id 只能用小写字母/数字/._-（且以字母或数字开头）");
      return;
    }
    if (!providerRef) {
      setNotice("请填写 launchd label（provider_ref）");
      return;
    }
    if (server.services.some((service) => service.id === id)) {
      setNotice("该服务 id 已存在");
      return;
    }
    patch({
      services: [
        ...server.services,
        {
          id,
          display_name: serviceDraft.displayName.trim() || id,
          description: "",
          provider_type: "launchd",
          provider_ref: providerRef,
          health_check: { kind: "launchd" },
          log_sources: [],
          allowed_actions: ["restart"],
          tags: [],
        } satisfies ServerServiceDescriptor,
      ],
    });
    setServiceDraft({ id: "", displayName: "", providerRef: "" });
    setNotice(null);
  };

  const removeService = (id: string) =>
    patch({ services: server.services.filter((service) => service.id !== id) });

  const toggleServiceAction = (id: string) =>
    patch({
      services: server.services.map((service) =>
        service.id === id
          ? {
              ...service,
              allowed_actions: service.allowed_actions.includes("restart")
                ? service.allowed_actions.filter((action) => action !== "restart")
                : [...service.allowed_actions, "restart"],
            }
          : service,
      ),
    });

  const addApp = () => {
    const id = appDraft.id.trim();
    const url = appDraft.url.trim();
    if (!/^[a-z0-9][a-z0-9._-]{0,63}$/.test(id)) {
      setNotice("应用 id 只能用小写字母/数字/._-（且以字母或数字开头）");
      return;
    }
    if (!/^https?:\/\/\S+$/i.test(url)) {
      setNotice("URL 必须以 http:// 或 https:// 开头");
      return;
    }
    if (server.applications.some((app) => app.id === id)) {
      setNotice("该应用 id 已存在");
      return;
    }
    patch({
      applications: [
        ...server.applications,
        {
          id,
          name: appDraft.name.trim() || id,
          description: "",
          url,
          health_url: null,
          service_id: null,
          category: "",
          tags: [],
        } satisfies ServerApplicationDescriptor,
      ],
    });
    setAppDraft({ id: "", name: "", url: "" });
    setNotice(null);
  };

  const removeApp = (id: string) =>
    patch({ applications: server.applications.filter((app) => app.id !== id) });

  return (
    <section className="settings-section">
      <label className="settings-label">Home Server · 注册服务与应用</label>
      <p className="settings-hint">
        只管理<strong>显式注册</strong>的目标：未注册的服务/应用 AI
        一律拒绝操作。系统修改（如重启）必须经过确认卡，且全程审计。
      </p>

      <div className="settings-subsection">
        <span className="settings-label">服务（launchd）</span>
        {server.services.length === 0 ? (
          <p className="settings-hint">尚未注册服务。</p>
        ) : (
          <ul className="settings-roots">
            {server.services.map((service) => (
              <li key={service.id}>
                <label>
                  <input
                    type="checkbox"
                    checked={service.allowed_actions.includes("restart")}
                    onChange={() => toggleServiceAction(service.id)}
                  />
                  {service.display_name || service.id}
                  <code>{service.provider_ref}</code>
                </label>
                <button
                  className="settings-test-button"
                  onClick={() => removeService(service.id)}
                >
                  移除
                </button>
              </li>
            ))}
          </ul>
        )}
        <div className="settings-root-form">
          <input
            className="settings-select"
            type="text"
            placeholder="服务 id（如 self-tools）"
            value={serviceDraft.id}
            onChange={(event) =>
              setServiceDraft({ ...serviceDraft, id: event.target.value })
            }
          />
          <input
            className="settings-select"
            type="text"
            placeholder="显示名（可选）"
            value={serviceDraft.displayName}
            onChange={(event) =>
              setServiceDraft({ ...serviceDraft, displayName: event.target.value })
            }
          />
          <input
            className="settings-select"
            type="text"
            placeholder="launchd label（com.example.app）"
            value={serviceDraft.providerRef}
            onChange={(event) =>
              setServiceDraft({ ...serviceDraft, providerRef: event.target.value })
            }
          />
          <button className="settings-test-button" onClick={addService}>
            添加服务
          </button>
        </div>
      </div>

      <div className="settings-subsection">
        <span className="settings-label">个人应用</span>
        {server.applications.length === 0 ? (
          <p className="settings-hint">尚未注册应用。</p>
        ) : (
          <ul className="settings-roots">
            {server.applications.map((app) => (
              <li key={app.id}>
                <label>
                  {app.name || app.id}
                  <code>{app.url}</code>
                </label>
                <button
                  className="settings-test-button"
                  onClick={() => removeApp(app.id)}
                >
                  移除
                </button>
              </li>
            ))}
          </ul>
        )}
        <div className="settings-root-form">
          <input
            className="settings-select"
            type="text"
            placeholder="应用 id（如 geo-explorer）"
            value={appDraft.id}
            onChange={(event) => setAppDraft({ ...appDraft, id: event.target.value })}
          />
          <input
            className="settings-select"
            type="text"
            placeholder="名称（可选）"
            value={appDraft.name}
            onChange={(event) => setAppDraft({ ...appDraft, name: event.target.value })}
          />
          <input
            className="settings-select"
            type="text"
            placeholder="http://127.0.0.1:8080"
            value={appDraft.url}
            onChange={(event) => setAppDraft({ ...appDraft, url: event.target.value })}
          />
          <button className="settings-test-button" onClick={addApp}>
            添加应用
          </button>
        </div>
      </div>

      <div className="settings-inline">
        <label className="settings-label">确认有效期（秒，30–120）</label>
        <input
          className="settings-select"
          type="number"
          min={30}
          max={120}
          value={server.confirmation_ttl_secs}
          onChange={(event) =>
            patch({
              confirmation_ttl_secs: clampNumber(
                event.target.value,
                30,
                120,
                60,
              ),
            })
          }
        />
        <label className="settings-label">同一目标冷却（秒）</label>
        <input
          className="settings-select"
          type="number"
          min={0}
          value={server.cooldown_secs}
          onChange={(event) =>
            patch({ cooldown_secs: clampNumber(event.target.value, 0, 3_600, 60) })
          }
        />
        <label className="settings-label">每会话系统操作上限</label>
        <input
          className="settings-select"
          type="number"
          min={1}
          value={server.max_system_per_session}
          onChange={(event) =>
            patch({
              max_system_per_session: clampNumber(
                event.target.value,
                1,
                100,
                5,
              ),
            })
          }
        />
      </div>
      {notice ? <p className="settings-hint">{notice}</p> : null}
    </section>
  );
}

function clampNumber(raw: string, min: number, max: number, fallback: number): number {
  const parsed = Number.parseInt(raw, 10);
  if (Number.isNaN(parsed)) return fallback;
  return Math.min(max, Math.max(min, parsed));
}

/**
 * MCP 传输设置（V8 §89-§91）。
 *
 * 远程默认关闭：只有显式打开且（将来）配置身份提供者后才可能非 loopback
 * 绑定（§46 启动门禁在 Rust 侧强制）。secret 只显示 configured/not
 * configured（§91）。
 */
function McpSection({
  server,
  onChange,
}: {
  server: ServerSettings;
  onChange: (server: ServerSettings) => void;
}) {
  const mcp = server.mcp;
  const patch = (next: Partial<McpSettings>) =>
    onChange({ ...server, mcp: { ...mcp, ...next } });

  return (
    <section className="settings-section">
      <label className="settings-label">MCP · 外部 AI 接入</label>
      <p className="settings-hint">
        MCP 是<strong>协议适配层</strong>：外部 AI Client（Pi / Claude 等）通过它调用
        self-tools 已有的能力，不获得任何额外权限。工具风险、确认、审计与本地一致。
      </p>

      <div className="settings-inline">
        <label className="settings-checkbox">
          <input
            type="checkbox"
            checked={mcp.enabled}
            onChange={(event) => patch({ enabled: event.target.checked })}
          />
          启用 MCP
        </label>
        <label className="settings-checkbox">
          <input
            type="checkbox"
            checked={mcp.stdio_enabled}
            disabled={!mcp.enabled}
            onChange={(event) => patch({ stdio_enabled: event.target.checked })}
          />
          STDIO（本地 MCP Client）
        </label>
        <label className="settings-checkbox">
          <input
            type="checkbox"
            checked={mcp.http_enabled}
            disabled={!mcp.enabled}
            onChange={(event) => patch({ http_enabled: event.target.checked })}
          />
          Streamable HTTP（默认仅 loopback）
        </label>
      </div>

      <div className="settings-inline">
        <label className="settings-label">绑定地址</label>
        <input
          className="settings-select"
          type="text"
          placeholder="127.0.0.1"
          value={mcp.bind}
          disabled={!mcp.enabled || !mcp.http_enabled}
          onChange={(event) => patch({ bind: event.target.value })}
        />
        <label className="settings-label">端口</label>
        <input
          className="settings-select"
          type="number"
          min={1024}
          max={65535}
          value={mcp.port}
          disabled={!mcp.enabled || !mcp.http_enabled}
          onChange={(event) =>
            patch({ port: clampNumber(event.target.value, 1024, 65535, 8787) })
          }
        />
        <label className="settings-checkbox">
          <input
            type="checkbox"
            checked={mcp.remote_enabled}
            disabled={!mcp.enabled}
            onChange={(event) => patch({ remote_enabled: event.target.checked })}
          />
          允许局域网访问（需要已配置身份提供者，否则启动被拒）
        </label>
      </div>

      <p className="settings-hint">
        身份提供者：<strong>未配置</strong> —— 远程 MCP 保持只读且默认关闭（V8 §29/§42）。
      </p>
      <p className="settings-hint">
        本地 Client 配置示例会在桌面端生成（使用当前可执行文件路径，不写死用户目录）。
      </p>
    </section>
  );
}

//! 路由与序列化（Gate 9）：HTTP 边界只做路由 / 参数提取 / 错误契约转换，
//! 用例决策全部在 `devtoolbox_application::history::HistoryService`。
//!
//! - 只读：七个 History 端点 + `/health`，无任何写入端点；
//! - 无鉴权（Gate 9 边界）；不设置 CORS —— 默认无跨源放行，仅当显式配置来源
//!   时才可能有允许列表（当前交付不做）；
//! - 错误契约：`{"code": "...", "message": "..."}`，由 `ApplicationError`
//!   映射而来；HTTP 层不出现桌面端的 `CommandError`。

use std::sync::Arc;

use axum::extract::{Path, Query, State};
use axum::http::StatusCode;
use axum::response::{IntoResponse, Response};
use axum::routing::{get, post};
use axum::{Json, Router};
use serde::Serialize;
use serde_json::json;
use tracing::warn;

use devtoolbox_application::ApplicationError;
use devtoolbox_application::history::HistoryService;

/// 共享状态（组合根在 main.rs 装配；路由不感知存储细节）。
#[derive(Clone)]
struct AppState {
    service: Arc<HistoryService>,
}

/// 错误契约响应体：`{"code": .., "message": ..}`。
#[derive(Debug, Serialize)]
pub struct ErrorBody {
    pub code: String,
    pub message: String,
}

/// 组装全部路由：History + Language + English 课程（由组合根注入服务与存储）。
///
/// 参数多是**组合根的固有形状**（每个 bounded context 一个已装配好的服务），
/// 与 `personal_ai::build_hub` 等同一类；拆成 struct 只会把装配步骤挪个地方。
#[allow(clippy::too_many_arguments)]
#[must_use = "router must be served"]
pub fn router(
    service: Arc<HistoryService>,
    learning: Arc<devtoolbox_application::language::LanguageLearningService>,
    dictionary: Arc<devtoolbox_application::language::LanguageService>,
    content: Arc<dyn devtoolbox_application::language::LanguageStorePort>,
    // 英语课程（NCE）只读接口（写操作属桌面端）。
    course: Arc<devtoolbox_application::language::course::CourseService>,
    // 数据目录（readiness 探测用；与桌面端同一目录）。
    data_dir: std::path::PathBuf,
    // Personal Knowledge 运行时（两端共用同一份索引库）。
    knowledge: Arc<devtoolbox_infrastructure::knowledge_runtime::KnowledgeRuntime>,
    // 语言库（课时音频端点要直接读文件；路径只取自数据库，不接受前端传参）。
    language_store: Arc<parking_lot::Mutex<devtoolbox_infrastructure::language::LanguageStore>>,
    // Travel 运行时装配（与桌面端共用 provider 与 travel.db）。
    travel: Arc<crate::travel_api::TravelDeps>,
    // 语言数据导入的目录与进度跟踪。
    data_paths: Arc<crate::language_data_api::DataPaths>,
    import_tracker: Arc<crate::language_data_api::ImportTracker>,
    settings: Arc<dyn crate::ai_api::SettingsAccess>,
    ai_runner: Option<Arc<dyn crate::ai_api::AiChatRunner>>,
    // 平台 LearningService（Collections / Graph / Review Center / Home 今日面板）
    learning_os: Arc<devtoolbox_application::learning::LearningService>,
    geography: Arc<devtoolbox_application::geography::GeographyService>,
    news: Arc<devtoolbox_application::news::NewsService>,
    news_ingest: Arc<dyn devtoolbox_application::news::NewsIngestPort>,
    // 学习板用例服务（与桌面端命令共用；数据在 config/study_boards.db）。
    study_board: Arc<devtoolbox_application::study_board::StudyBoardService>,
    // 跟读发音评分（V13 W2）：目标句由服务端查库，没有转写就没有分数。
    speaking: Arc<devtoolbox_application::language::course::SpeakingService>,
    // 句子挖掘（V13 W3）：读过的课文句 → SRS 复习卡。
    mining: Arc<devtoolbox_application::language::course::MiningService>,
    // 26 周能力路线图（V13 W6）：静态计划 + 真实统计。
    roadmap: Arc<devtoolbox_application::language::course::RoadmapService>,
) -> Router {
    let exploration = Arc::new(
        devtoolbox_application::exploration::ExplorationService::new(
            Arc::clone(&geography),
            Arc::clone(&service),
        ),
    );
    Router::new()
        .route("/health", get(health))
        .route(
            "/api/v1/readiness",
            get(crate::readiness_api::readiness_report),
        )
        .route(
            "/api/v1/readiness/diagnostics",
            get(crate::readiness_api::readiness_diagnostics),
        )
        // Personal Knowledge（Memory / Documents / Files / 全局检索）：
        // 能力一直在 Rust 侧实现，但此前只有桌面装配，网页端只能显示「不支持」。
        .route(
            "/api/v1/memory/list",
            get(crate::knowledge_api::memory_list),
        )
        .route(
            "/api/v1/memory/stats",
            get(crate::knowledge_api::memory_stats),
        )
        .route(
            "/api/v1/documents/status",
            get(crate::knowledge_api::documents_status),
        )
        .route(
            "/api/v1/documents/recent",
            get(crate::knowledge_api::documents_recent),
        )
        .route(
            "/api/v1/documents/search",
            get(crate::knowledge_api::documents_search),
        )
        .route(
            "/api/v1/files/status",
            get(crate::knowledge_api::files_status),
        )
        .route(
            "/api/v1/files/recent",
            get(crate::knowledge_api::files_recent),
        )
        .route(
            "/api/v1/files/search",
            get(crate::knowledge_api::files_search),
        )
        .route(
            "/api/v1/search/global",
            get(crate::knowledge_api::global_search),
        )
        .route("/api/v1/history/home", get(home))
        .route("/api/v1/history/search", get(search))
        .route("/api/v1/history/periods/{id}", get(period))
        .route("/api/v1/history/events/{id}", get(event))
        .route("/api/v1/history/people/{id}", get(person))
        .route("/api/v1/history/works/{id}", get(work))
        .route("/api/v1/history/stories/{id}", get(story))
        .route(
            "/api/v1/language/languages",
            get(crate::language_api::languages),
        )
        .route(
            "/api/v1/language/sources",
            get(crate::language_api::sources),
        )
        .route(
            "/api/v1/language/course/today",
            get(crate::language_course_api::today),
        )
        .route(
            "/api/v1/language/course/books",
            get(crate::language_course_api::books),
        )
        .route(
            "/api/v1/language/course/book/{id}",
            get(crate::language_course_api::book),
        )
        .route(
            "/api/v1/language/course/lesson/{id}",
            get(crate::language_course_api::lesson).delete(crate::language_data_api::delete_lesson),
        )
        .route(
            "/api/v1/language/course/progress",
            get(crate::language_course_api::progress),
        )
        .route(
            "/api/v1/language/course/plan",
            get(crate::language_course_api::plan),
        )
        .route(
            "/api/v1/language/course/dict/{word}",
            get(crate::language_course_api::dict_lookup),
        )
        // 写路径：网页端要能真正「学」，不只是「看」。
        // 此前这里只有只读端点，点「不认识」直接报「尚无网页端接口」。
        .route(
            "/api/v1/language/course/lesson/{lesson_id}/progress",
            post(crate::language_write_api::update_progress),
        )
        .route(
            "/api/v1/language/course/lesson/{lesson_id}/complete",
            post(crate::language_write_api::complete_lesson),
        )
        .route(
            "/api/v1/language/course/lesson/{lesson_id}/mark-word",
            post(crate::language_write_api::mark_word),
        )
        .route(
            "/api/v1/language/course/lookup-word",
            post(crate::language_write_api::lookup_word),
        )
        .route(
            "/api/v1/language/course/quiz",
            get(crate::language_write_api::quiz),
        )
        .route(
            "/api/v1/language/course/quiz/submit",
            post(crate::language_write_api::submit_quiz),
        )
        .route(
            "/api/v1/language/course/plan",
            post(crate::language_write_api::save_plan),
        )
        .route(
            "/api/v1/language/course/lesson/{lesson_id}/audio",
            get(crate::language_write_api::lesson_audio),
        )
        .route(
            "/api/v1/language/course/search",
            get(crate::language_course_api::search),
        )
        .route("/api/v1/language/search", get(crate::language_api::search))
        .route(
            "/api/v1/language/sentences",
            get(crate::language_api::sentences),
        )
        .route(
            "/api/v1/language/sentences/{id}/study",
            get(crate::language_api::sentence_study),
        )
        .route(
            "/api/v1/language/items/{id}",
            get(crate::language_api::learning_item),
        )
        .route(
            "/api/v1/language/detail/{id}",
            get(crate::language_api::item_detail),
        )
        .route(
            "/api/v1/language/study-queue",
            get(crate::language_api::study_queue),
        )
        .route(
            "/api/v1/language/study",
            post(crate::language_api::record_study),
        )
        .route(
            "/api/v1/language/add-to-review",
            post(crate::language_api::add_to_review),
        )
        .route(
            "/api/v1/language/review-queue",
            get(crate::language_api::review_queue),
        )
        .route(
            "/api/v1/language/review",
            post(crate::language_api::submit_review),
        )
        .route(
            "/api/v1/language/mistakes",
            get(crate::language_api::mistakes),
        )
        .route(
            "/api/v1/language/lessons",
            get(crate::language_api::lessons).post(crate::language_api::create_lesson),
        )
        .route(
            "/api/v1/language/lessons/{id}",
            get(crate::language_api::lesson),
        )
        .route(
            "/api/v1/language/lessons/{id}/position",
            post(crate::language_api::save_lesson_position),
        )
        .route(
            "/api/v1/language/continue",
            get(crate::language_api::continue_lessons),
        )
        .route(
            "/api/v1/language/progress",
            get(crate::language_api::progress),
        )
        .route(
            "/api/v1/language/weak-items",
            get(crate::language_api::weak_items),
        )
        // ---- 设置状态与 AI：HTTP 只读脱敏状态；配置写入暂限本机 Tauri ----
        .route(
            "/api/v1/settings",
            get(crate::ai_api::get_settings).post(crate::ai_api::save_settings),
        )
        .route("/api/v1/ai/status", get(crate::ai_api::ai_status))
        .route("/api/v1/ai/chat", post(crate::ai_api::ai_chat))
        .route(
            "/api/v1/ai/runs/{trace_id}/cancel",
            post(crate::ai_api::ai_cancel_run),
        )
        .route(
            "/api/v1/ai/travel-changes/{proposal_id}/confirm",
            post(crate::ai_api::ai_confirm_travel_change),
        )
        .route(
            "/api/v1/ai/travel-changes/{proposal_id}/cancel",
            post(crate::ai_api::ai_cancel_travel_change),
        )
        // 语言数据导入（NCE 教材 / ECDICT 词典）：网页端也要能导入，
        // 否则「这台机器就是服务器」却只能靠人去点桌面应用导一次。
        .route(
            "/api/v1/language/data-status",
            get(crate::language_data_api::data_status),
        )
        .route(
            "/api/v1/language/nce/scan",
            post(crate::language_data_api::nce_scan),
        )
        .route(
            "/api/v1/language/nce/import",
            post(crate::language_data_api::nce_import),
        )
        .route(
            "/api/v1/language/dict/import",
            post(crate::language_data_api::dict_import),
        )
        .route(
            "/api/v1/language/dict/status",
            get(crate::language_data_api::dict_status),
        )
        .route(
            "/api/v1/language/import-status",
            get(crate::language_data_api::import_status),
        )
        // Travel（城市研究与攻略）：provider 装配已下沉，桌面与网页共用同一套。
        .route(
            "/api/v1/travel/research/start",
            post(crate::travel_api::travel_research_start),
        )
        .route(
            "/api/v1/travel/research/progress",
            get(crate::travel_api::travel_research_progress),
        )
        .route(
            "/api/v1/travel/recent-guides",
            get(crate::travel_api::travel_recent_guides),
        )
        .route(
            "/api/v1/travel/guide",
            get(crate::travel_api::travel_load_guide),
        )
        .route(
            "/api/v1/travel/plans/recent",
            get(crate::travel_api::travel_recent_plans),
        )
        .route(
            "/api/v1/travel/plans",
            get(crate::travel_api::travel_plan_get).post(crate::travel_api::travel_plan_save),
        )
        .route(
            "/api/v1/travel/test/llm",
            post(crate::travel_api::test_travel_llm),
        )
        .route(
            "/api/v1/travel/test/amap",
            post(crate::travel_api::test_travel_amap),
        )
        .route(
            "/api/v1/travel/test/qweather",
            post(crate::travel_api::test_travel_qweather),
        )
        // ---- Learning OS：Collections / Graph / Review Center / Home 今日面板 ----
        .route(
            "/api/v1/learning/progress",
            get(crate::learning_api::list_progress).post(crate::learning_api::record_event),
        )
        .route(
            "/api/v1/learning/progress/key",
            get(crate::learning_api::get_progress),
        )
        .route(
            "/api/v1/learning/review/queue",
            get(crate::learning_api::review_queue),
        )
        .route(
            "/api/v1/learning/review/stats",
            get(crate::learning_api::review_stats),
        )
        .route(
            "/api/v1/learning/review",
            post(crate::learning_api::submit_review),
        )
        .route(
            "/api/v1/learning/review/cards/{id}",
            get(crate::learning_api::get_review_card)
                .delete(crate::learning_api::delete_knowledge_review_card),
        )
        .route(
            "/api/v1/learning/review/cards/from-knowledge",
            post(crate::learning_api::save_knowledge_review_card),
        )
        .route("/api/v1/learning/today", get(crate::learning_api::today))
        .route("/api/v1/learning/graph", get(crate::learning_api::graph))
        .route(
            "/api/v1/learning/explore",
            get(crate::learning_api::explore),
        )
        .route(
            "/api/v1/learning/collections",
            get(crate::learning_api::list_collections).post(crate::learning_api::create_collection),
        )
        .route(
            "/api/v1/learning/collections/{id}",
            axum::routing::delete(crate::learning_api::delete_collection),
        )
        .route(
            "/api/v1/learning/collections/{id}/items",
            get(crate::learning_api::list_collection_items)
                .post(crate::learning_api::add_collection_item),
        )
        .route(
            "/api/v1/learning/collection-items/{id}/note",
            axum::routing::patch(crate::learning_api::update_collection_item_note),
        )
        .route(
            "/api/v1/learning/collection-items/remove",
            post(crate::learning_api::remove_collection_item),
        )
        // ---- Geography：此前网页端搜索走前端 12 条硬编码示例，不查真实库 ----
        .route("/api/v1/geography/home", get(crate::geography_api::home))
        .route(
            "/api/v1/geography/search",
            get(crate::geography_api::search),
        )
        .route(
            "/api/v1/geography/entities/{id}",
            get(crate::geography_api::detail),
        )
        .route(
            "/api/v1/exploration/geography/{id}/history",
            get(crate::exploration_api::location_history),
        )
        .route(
            "/api/v1/exploration/history-places/{id}/geography",
            get(crate::exploration_api::geography_for_history_place),
        )
        .route(
            "/api/v1/geography/favorite",
            post(crate::geography_api::toggle_favorite),
        )
        // ---- News：推荐源目录是 core 里的纯函数，网页端同样要能读到 ----
        .route(
            "/api/v1/news/recommended",
            get(crate::news_api::recommended),
        )
        .route("/api/v1/news/sources", get(crate::news_api::sources))
        // 网页端此前没有刷新入口（只有 Tauri 命令）—— 补上，与桌面端同一个用例。
        .route("/api/v1/news/refresh", post(crate::news_api::refresh))
        .route("/api/v1/news/headlines", get(crate::news_api::headlines))
        .route("/api/v1/news/search", get(crate::news_api::search))
        .route("/api/v1/news/starred", get(crate::news_api::starred))
        .route("/api/v1/news/sources", post(crate::news_api::add_source))
        .route(
            "/api/v1/news/sources/{id}/remove",
            post(crate::news_api::remove_source),
        )
        .route(
            "/api/v1/news/articles/{id}/star",
            post(crate::news_api::toggle_star),
        )
        .route(
            "/api/v1/news/articles/{id}/read",
            post(crate::news_api::mark_read),
        )
        // 学习板：此前画板只写浏览器 localStorage —— 换设备就没了，
        // 而且 AI 看到的板和用户画的板不是同一块。这里接出同一份用例。
        // 跟读评分 + 开口统计：progress 页的「说了多少」来自这里。
        .route(
            "/api/v1/language/shadow/score",
            post(crate::language_write_api::shadow_score),
        )
        .route(
            "/api/v1/language/shadow/stats",
            get(crate::language_write_api::shadow_stats),
        )
        .route(
            "/api/v1/english/roadmap",
            get(crate::language_course_api::roadmap),
        )
        .route(
            "/api/v1/language/mining/lesson/{lesson_id}",
            get(crate::language_write_api::mining_preview)
                .post(crate::language_write_api::mining_add),
        )
        .route(
            "/api/v1/study-boards",
            get(crate::study_board_api::list_boards).post(crate::study_board_api::save_board),
        )
        .route(
            "/api/v1/study-boards/{id}",
            get(crate::study_board_api::get_board),
        )
        .route(
            "/api/v1/study-boards/{id}/snapshots",
            post(crate::study_board_api::save_snapshot),
        )
        .layer(axum::Extension(Arc::clone(&content)))
        .layer(axum::Extension(Arc::clone(&dictionary)))
        .layer(axum::Extension(Arc::clone(&learning)))
        .layer(axum::Extension(Arc::clone(&settings)))
        .layer(axum::Extension(ai_runner))
        .layer(axum::Extension(Arc::clone(&learning_os)))
        .layer(axum::Extension(Arc::clone(&geography)))
        .layer(axum::Extension(exploration))
        .layer(axum::Extension(Arc::clone(&news)))
        .layer(axum::Extension(Arc::clone(&course)))
        .layer(axum::Extension(Arc::new(data_dir)))
        .layer(axum::Extension(knowledge))
        .layer(axum::Extension(language_store))
        .layer(axum::Extension(travel))
        .layer(axum::Extension(data_paths))
        .layer(axum::Extension(import_tracker))
        .layer(axum::Extension(Arc::clone(&news_ingest)))
        .layer(axum::Extension(study_board))
        .layer(axum::Extension(speaking))
        .layer(axum::Extension(mining))
        .layer(axum::Extension(roadmap))
        .with_state(AppState { service })
        // 显式擦除成 `Arc<dyn Fn()>`：`Extension<T>` 按具体类型匹配，
        // `Arc<fn() -> i64>` 与 `Arc<dyn Fn() -> i64 + Send + Sync>` 不是同一个类型。
        .layer(axum::Extension(
            Arc::new(devtoolbox_infrastructure::now_unix as fn() -> i64)
                as Arc<dyn Fn() -> i64 + Send + Sync>,
        ))
        .layer(axum::extract::DefaultBodyLimit::max(1024 * 1024))
        .layer(axum::middleware::from_fn(crate::security::local_http_guard))
}

async fn health() -> Json<serde_json::Value> {
    Json(json!({ "status": "ok" }))
}

/// 客户端参数问题（契约：与用例错误同形的 `{"code","message"}`）。
fn bad_request(message: impl Into<String>) -> Response {
    error_response(StatusCode::BAD_REQUEST, message.into())
}

/// 查询不存在（用例返回 `Ok(None)`）→ 404。
fn not_found(kind: &str, id: &str) -> Response {
    error_response(StatusCode::NOT_FOUND, format!("{kind} not found: {id}"))
}

/// 用例层失败 → 500（只读查询没有可恢复的客户端错误）。
fn use_case_error(error: ApplicationError) -> Response {
    warn!(error = %error, "history request failed");
    error_response(StatusCode::INTERNAL_SERVER_ERROR, error.to_string())
}

fn error_response(status: StatusCode, message: String) -> Response {
    (
        status,
        Json(ErrorBody {
            code: "history_error".to_string(),
            message,
        }),
    )
        .into_response()
}

fn ok_json(value: impl Serialize) -> Response {
    (StatusCode::OK, Json(value)).into_response()
}

async fn home(State(state): State<AppState>) -> Response {
    match state.service.home() {
        Ok(view) => ok_json(view),
        Err(error) => use_case_error(error),
    }
}

/// `GET /api/v1/history/search?q=…`；`q` 缺失 → 400 错误契约，`q` 为空 → 空结果。
/// （axum 0.8 没有 `Option<Query<T>>` 提取器，这里用 map 提取后自行判空。）
async fn search(
    State(state): State<AppState>,
    Query(params): Query<std::collections::HashMap<String, String>>,
) -> Response {
    let Some(q) = params.get("q") else {
        return bad_request("missing query parameter: q");
    };
    match state.service.search(q) {
        Ok(groups) => ok_json(groups),
        Err(error) => use_case_error(error),
    }
}

async fn period(State(state): State<AppState>, Path(id): Path<String>) -> Response {
    match state.service.period_detail(&id) {
        Ok(Some(detail)) => ok_json(detail),
        Ok(None) => not_found("period", &id),
        Err(error) => use_case_error(error),
    }
}

async fn event(State(state): State<AppState>, Path(id): Path<String>) -> Response {
    match state.service.event_detail(&id) {
        Ok(Some(detail)) => ok_json(detail),
        Ok(None) => not_found("event", &id),
        Err(error) => use_case_error(error),
    }
}

async fn person(State(state): State<AppState>, Path(id): Path<String>) -> Response {
    match state.service.person_detail(&id) {
        Ok(Some(detail)) => ok_json(detail),
        Ok(None) => not_found("person", &id),
        Err(error) => use_case_error(error),
    }
}

async fn work(State(state): State<AppState>, Path(id): Path<String>) -> Response {
    match state.service.work_detail(&id) {
        Ok(Some(detail)) => ok_json(detail),
        Ok(None) => not_found("work", &id),
        Err(error) => use_case_error(error),
    }
}

async fn story(State(state): State<AppState>, Path(id): Path<String>) -> Response {
    match state.service.story_detail(&id) {
        Ok(Some(detail)) => ok_json(detail),
        Ok(None) => not_found("story", &id),
        Err(error) => use_case_error(error),
    }
}

#[cfg(test)]
mod tests {
    //! 路由 + 用例服务集成测试（黑盒，不监听真实端口：`oneshot` 直接调用）。

    use std::sync::Arc;

    use axum::body::to_bytes;
    use axum::http::{Request, StatusCode};
    use devtoolbox_application::history::{HistoryPortError, HistoryQueryPort, HistoryService};
    use devtoolbox_core::history_records::{
        DatasetStats, EventEvidenceResult, EventHistoricalTextResult, EventPersonResult,
        EventPlaceResult, EventRelationResult, EventResult, EventStoryResult, HistoricalTextResult,
        PeriodEventItem, PeriodPersonItem, PeriodResult, PersonEventResult, PersonPlaceResult,
        PersonRelationResult, PersonResult, PersonStoryResult, RegimeResult, SourceResult,
        StoryEventResult, StoryResult, WorkResult,
    };
    use serde_json::Value;
    use tower::ServiceExt;

    use super::router;

    fn boom() -> HistoryPortError {
        HistoryPortError("boom".to_string())
    }

    /// 灌入空数据的假端口（明细全部未命中 → 404；`fail_all` → 500）。
    struct FakeHistory {
        fail_all: bool,
    }

    impl HistoryQueryPort for FakeHistory {
        fn get_dataset_stats(&self) -> Result<DatasetStats, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(DatasetStats {
                    people: 0,
                    places: 0,
                    person_relations: 0,
                    person_places: 0,
                    works: 0,
                    historical_texts: 0,
                    events: 0,
                    periods: 0,
                    regimes: 0,
                    stories: 0,
                    event_relations: 0,
                    event_evidences: 0,
                })
            }
        }
        fn get_periods(&self) -> Result<Vec<PeriodResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_regimes_by_period(&self, _: &str) -> Result<Vec<RegimeResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_events_for_period(&self, _: &str) -> Result<Vec<PeriodEventItem>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_people_for_period(
            &self,
            _: &str,
            _: i64,
        ) -> Result<Vec<PeriodPersonItem>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_relations_for_period(
            &self,
            _: &str,
        ) -> Result<Vec<EventRelationResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_stories(&self) -> Result<Vec<StoryResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_stories_for_period(
            &self,
            _: Option<&str>,
        ) -> Result<Vec<StoryResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_story(&self, _: &str) -> Result<Option<StoryResult>, HistoryPortError> {
            if self.fail_all { Err(boom()) } else { Ok(None) }
        }
        fn get_story_events(&self, _: &str) -> Result<Vec<StoryEventResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_stories_for_event(
            &self,
            _: &str,
        ) -> Result<Vec<EventStoryResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_story_people(&self, _: &str) -> Result<Vec<EventPersonResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_story_places(&self, _: &str) -> Result<Vec<EventPlaceResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_story_texts(
            &self,
            _: &str,
        ) -> Result<Vec<EventHistoricalTextResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_story_evidences(
            &self,
            _: &str,
        ) -> Result<Vec<EventEvidenceResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_event(&self, _: &str) -> Result<Option<EventResult>, HistoryPortError> {
            if self.fail_all { Err(boom()) } else { Ok(None) }
        }
        fn get_events_for_place(&self, _: &str) -> Result<Vec<EventResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_event_people(&self, _: &str) -> Result<Vec<EventPersonResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_event_places(&self, _: &str) -> Result<Vec<EventPlaceResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_event_relations(
            &self,
            _: &str,
        ) -> Result<Vec<EventRelationResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_event_texts(
            &self,
            _: &str,
        ) -> Result<Vec<EventHistoricalTextResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_event_evidences(
            &self,
            _: &str,
        ) -> Result<Vec<EventEvidenceResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_person(&self, _: &str) -> Result<Option<PersonResult>, HistoryPortError> {
            if self.fail_all { Err(boom()) } else { Ok(None) }
        }
        fn get_person_relations(
            &self,
            _: &str,
        ) -> Result<Vec<PersonRelationResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_person_places(&self, _: &str) -> Result<Vec<PersonPlaceResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_person_events(&self, _: &str) -> Result<Vec<PersonEventResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_person_stories(&self, _: &str) -> Result<Vec<PersonStoryResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_work_by_id(&self, _: &str) -> Result<Option<WorkResult>, HistoryPortError> {
            if self.fail_all { Err(boom()) } else { Ok(None) }
        }
        fn get_work(&self, _: &str, _: i64) -> Result<Vec<WorkResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_historical_texts(
            &self,
            _: Option<&str>,
            _: i64,
        ) -> Result<Vec<HistoricalTextResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn search_people(&self, _: &str, _: i64) -> Result<Vec<PersonResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn search_events(&self, _: &str, _: i64) -> Result<Vec<EventResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
        fn get_sources_for_ids(&self, _: &[String]) -> Result<Vec<SourceResult>, HistoryPortError> {
            if self.fail_all {
                Err(boom())
            } else {
                Ok(Vec::new())
            }
        }
    }

    /// 历史路由测试用的装配：Language 侧给内存库（这些用例只断言 history）。
    /// 测试用共享运行时：走 AppCore 一次装配（与真实启动同一路径）。
    fn test_core() -> Arc<devtoolbox_runtime::AppCore> {
        static CORE: std::sync::OnceLock<Arc<devtoolbox_runtime::AppCore>> =
            std::sync::OnceLock::new();
        CORE.get_or_init(|| {
            let dir =
                std::env::temp_dir().join(format!("self-tools-test-core-{}", std::process::id()));
            let _ = std::fs::create_dir_all(&dir);
            // History 用仓库里那份真实 duckdb（与开发/生产一致）；
            // 其余库落临时目录，不污染开发者的 config/。
            let history_db = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
                .join("../../history-data-pipeline/dist/history.duckdb");
            Arc::new(
                devtoolbox_runtime::AppCore::build(
                    &dir,
                    history_db,
                    devtoolbox_runtime::server::web_trust(),
                )
                .expect("app core"),
            )
        })
        .clone()
    }

    /// 测试用 language.db 路径（跟读评分的播种与请求走同一个库）。
    fn test_language_db() -> std::path::PathBuf {
        std::env::temp_dir().join(format!(
            "self-tools-test-language-{}.db",
            std::process::id()
        ))
    }

    /// 共享运行时（`AppCore`）的数据目录 —— 跟读评分服务就装在这里。
    fn test_core_dir() -> std::path::PathBuf {
        std::env::temp_dir().join(format!("self-tools-test-core-{}", std::process::id()))
    }

    /// 播种一课真实课文（跟读评分必须能在库里查到目标句）。
    ///
    /// 写在 **`AppCore` 的 language.db** 里：`speaking` 服务来自共享运行时，
    /// 写错库的话评分端点只会说「没有第 0 句」。
    fn seed_shadow_lesson(tag: &str) -> String {
        let lesson_id = format!("nce:1:{tag}");
        let store =
            devtoolbox_infrastructure::LanguageStore::open(test_core_dir().join("language.db"))
                .expect("seed store");
        store
            .replace_lesson_content(
                &devtoolbox_core::language::CourseLesson {
                    id: lesson_id.clone(),
                    book_id: "nce:1".into(),
                    lesson_no: 1,
                    title: "Excuse me".into(),
                    audio_path: None,
                    duration_ms: Some(2_000),
                    sentence_count: 2,
                    vocab_count: 0,
                },
                &[
                    devtoolbox_core::language::LessonSentence {
                        id: format!("{lesson_id}#0"),
                        lesson_id: lesson_id.clone(),
                        sequence: 0,
                        start_ms: 0,
                        end_ms: 1_200,
                        english: "Excuse me! Yes?".into(),
                        chinese: Some("对不起，是吗？".into()),
                    },
                    devtoolbox_core::language::LessonSentence {
                        id: format!("{lesson_id}#1"),
                        lesson_id: lesson_id.clone(),
                        sequence: 1,
                        start_ms: 1_200,
                        end_ms: 2_000,
                        english: "This is your handbag.".into(),
                        chinese: Some("这是你的手提包。".into()),
                    },
                ],
                &[],
            )
            .expect("seed lesson");
        lesson_id
    }

    fn test_router(fail_all: bool) -> axum::Router {
        test_router_with_history(Arc::new(HistoryService::new(Box::new(FakeHistory {
            fail_all,
        }))))
    }

    fn test_router_with_history(service: Arc<HistoryService>) -> axum::Router {
        let language_store = Arc::new(parking_lot::Mutex::new(
            devtoolbox_infrastructure::LanguageStore::open(test_language_db())
                .expect("language store"),
        ));
        let content: Arc<dyn devtoolbox_application::language::LanguageStorePort> = Arc::new(
            devtoolbox_infrastructure::LanguageStoreAdapter::new(Arc::clone(&language_store)),
        );
        let learning_store = Arc::new(parking_lot::Mutex::new(
            devtoolbox_infrastructure::LearningStore::open(std::env::temp_dir().join(format!(
                "self-tools-test-learning-{}.db",
                std::process::id()
            )))
            .expect("learning store"),
        ));
        let geography = Arc::new(devtoolbox_application::geography::GeographyService::new(
            Arc::new(devtoolbox_infrastructure::GeographyQueryAdapter::new(
                Arc::new(parking_lot::Mutex::new(
                    devtoolbox_infrastructure::GeographyStore::open(std::env::temp_dir().join(
                        format!("self-tools-test-geography-{}.db", std::process::id()),
                    ))
                    .expect("geography store"),
                )),
            )),
        ));
        let learning_os = Arc::new(devtoolbox_application::learning::LearningService::new(
            Arc::new(devtoolbox_infrastructure::LearningStoreAdapter::new(
                learning_store,
            )),
        ));
        let learning = Arc::new(
            devtoolbox_application::language::LanguageLearningService::new(
                Arc::clone(&content),
                Arc::clone(&learning_os),
            ),
        );
        let course = Arc::new(
            devtoolbox_application::language::course::CourseService::new(
                Arc::new(devtoolbox_infrastructure::ports::CourseStoreAdapter::new(
                    Arc::clone(&language_store),
                )),
                Arc::clone(&learning_os),
            ),
        );
        router(
            service,
            learning,
            Arc::new(devtoolbox_application::language::LanguageService::new(
                Arc::clone(&content),
            )),
            content,
            course,
            // readiness 探测用的数据目录（测试里指向系统临时目录）。
            std::env::temp_dir(),
            test_core().knowledge.clone(),
            Arc::clone(&language_store),
            Arc::new(crate::travel_api::test_deps(&std::env::temp_dir())),
            Arc::new(crate::language_data_api::DataPaths {
                config_dir: std::env::temp_dir(),
            }),
            Arc::default(),
            Arc::new(TestSettings),
            None,
            learning_os,
            geography,
            news_service(),
            // 泛型参数直传具体类型：FeedFetcherPort 用 `-> impl Future` 声明，
            // 不是 dyn 兼容的。
            Arc::new(devtoolbox_application::news::NewsIngestService::new(
                news_service(),
                devtoolbox_infrastructure::FeedFetcherAdapter::new(
                    devtoolbox_infrastructure::feed_fetcher::feed_client().expect("http client"),
                ),
            )) as Arc<dyn devtoolbox_application::news::NewsIngestPort>,
            Arc::clone(&test_core().study_board),
            Arc::clone(&test_core().speaking),
            Arc::clone(&test_core().mining),
            Arc::clone(&test_core().roadmap),
        )
    }

    /// News 测试装配：**每个用例一个独立库** + 不联网的抓取器。
    ///
    /// 之前所有用例共用同一个 `self-tools-test-news-{pid}.db`：测试是并行的，
    /// 多个 `NewsRepository::open` 会互相抢写锁，报 `database is locked`
    /// （踩过一次：给 news 库加了启动期迁移写入后，稳定的测试开始随机失败）。
    fn news_service() -> Arc<devtoolbox_application::news::NewsService> {
        static SEQ: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
        let seq = SEQ.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        Arc::new(devtoolbox_application::news::NewsService::new(Arc::new(
            devtoolbox_infrastructure::NewsRepositoryAdapter::new(Arc::new(
                parking_lot::Mutex::new(
                    devtoolbox_infrastructure::NewsRepository::open(std::env::temp_dir().join(
                        format!("self-tools-test-news-{}-{seq}.db", std::process::id()),
                    ))
                    .expect("news store"),
                ),
            )),
        )))
    }

    /// 设置测试替身（不碰磁盘）。
    struct TestSettings;

    impl crate::ai_api::SettingsAccess for TestSettings {
        fn load(&self) -> devtoolbox_core::settings::AppSettings {
            let mut settings = devtoolbox_core::settings::AppSettings::default();
            settings.ai.api_key = Some("server-test-secret-marker".into());
            settings.travel.qweather_api_key = Some("weather-test-secret-marker".into());
            settings
        }
    }

    /// 契约护栏：前端 `transport.ts` 的映射必须与服务端路由一一对应。
    /// 少注册一个，网页端对应功能就是「静默 404」。
    #[test]
    fn language_endpoints_are_registered() {
        let router = test_router(false);
        let source = include_str!("routes.rs");
        for path in [
            "/api/v1/language/languages",
            "/api/v1/language/sources",
            "/api/v1/language/search",
            "/api/v1/language/sentences",
            "/api/v1/language/items/{id}",
            "/api/v1/language/detail/{id}",
            "/api/v1/language/study-queue",
            "/api/v1/language/study",
            "/api/v1/language/add-to-review",
            "/api/v1/language/review-queue",
            "/api/v1/language/review",
            "/api/v1/language/mistakes",
            "/api/v1/language/lessons",
            "/api/v1/language/continue",
            "/api/v1/language/progress",
            "/api/v1/language/weak-items",
        ] {
            assert!(source.contains(path), "路由未注册：{path}");
        }
        let _ = router;
    }

    /// 请求体必须与前端 `aiClient` **实际发送的形状一致**（外层包 `request`）。
    ///
    /// 回归：server 曾自造 `{message, session_id}`，而前端发
    /// `{request:{message, app_context, capabilities, ...}}`，于是网页端
    /// 一点「问 AI」就 422，报错还被包装成「无法连接本地数据服务」——
    /// 看起来像服务没起，实际是两端契约从未对齐。
    /// 这个用例直接用前端真实形状，契约再改就会红。
    #[tokio::test]
    async fn ai_chat_accepts_frontend_request_shape() {
        let app = test_router(false);
        let (status, body) = post_json(
            &app,
            "/api/v1/ai/chat",
            &serde_json::json!({
                "request": {
                    "message": "你好",
                    "session_id": null,
                    "app_context": {
                        "module": "language",
                        "page": "home",
                        "entity": null,
                        "view_state": {}
                    },
                    "capabilities": [],
                    "locale": "zh"
                }
            }),
        )
        .await;
        assert_eq!(status, StatusCode::BAD_REQUEST, "body={body}");
        assert_eq!(
            body["code"], "ai_not_configured",
            "请求体应被接受并走到「未配置」分支，而不是 422：{body}"
        );
        assert!(
            body["message"]
                .as_str()
                .is_some_and(|m| m.contains("未配置")),
            "错误信息应说明未配置：{body}"
        );
    }

    #[tokio::test]
    async fn ai_status_reports_unconfigured() {
        let app = test_router(false);
        let (status, body) = request(&app, "/api/v1/ai/status").await;
        assert_eq!(status, StatusCode::OK);
        assert_eq!(body["configured"], false);
    }

    #[tokio::test]
    async fn settings_http_exposes_only_redacted_status() {
        let app = test_router(false);
        let (status, body) = request(&app, "/api/v1/settings").await;
        assert_eq!(status, StatusCode::OK);
        assert_eq!(body["ai_configured"], false);
        assert_eq!(body["secrets"]["ai_api_key_configured"], true);
        assert_eq!(body["secrets"]["travel_qweather_api_key_configured"], true);
        let serialized = body.to_string();
        assert!(!serialized.contains("server-test-secret-marker"));
        assert!(!serialized.contains("weather-test-secret-marker"));
        assert!(
            body.get("ai").is_none(),
            "HTTP must not expose full AI config"
        );
        assert!(
            body.get("knowledge").is_none(),
            "HTTP must not expose filesystem roots"
        );
    }

    #[tokio::test]
    async fn settings_http_write_is_rejected_without_authenticated_admin_api() {
        let app = test_router(false);
        let (status, body) = post_json(
            &app,
            "/api/v1/settings",
            &serde_json::json!({ "ai": { "api_key": "attacker-controlled" } }),
        )
        .await;
        assert_eq!(status, StatusCode::FORBIDDEN);
        assert_eq!(body["code"], "settings_write_requires_desktop");
        assert!(!body.to_string().contains("attacker-controlled"));
    }

    #[tokio::test]
    async fn travel_plan_http_round_trip_persists_backend_owned_itinerary_state() {
        let app = test_router(false);
        let plan = serde_json::json!({
            "context": {
                "city": "杭州",
                "days": 2,
                "date_range": { "start": "2026-10-01", "end": "2026-10-02" }
            },
            "selected_keys": ["poi-west-lake"],
            "assigned_days": { "poi-west-lake": 2 },
            "must_visit_keys": ["poi-west-lake"],
            "updated_at": 1
        });
        let (status, saved) = post_json(
            &app,
            "/api/v1/travel/plans",
            &serde_json::json!({ "plan": plan.clone() }),
        )
        .await;
        assert_eq!(status, StatusCode::OK, "body={saved}");
        assert!(saved["updated_at"].as_i64().is_some_and(|value| value > 1));
        assert_eq!(saved["revision"], 1);

        let mut updated = saved.clone();
        updated["title"] = serde_json::json!("西湖慢行");
        let (status, latest) = post_json(
            &app,
            "/api/v1/travel/plans",
            &serde_json::json!({ "plan": updated }),
        )
        .await;
        assert_eq!(status, StatusCode::OK, "body={latest}");
        assert_eq!(latest["revision"], 2);

        let (status, conflict) = post_json(
            &app,
            "/api/v1/travel/plans",
            &serde_json::json!({ "plan": plan }),
        )
        .await;
        assert_eq!(status, StatusCode::CONFLICT, "body={conflict}");
        assert_eq!(conflict["code"], "travel_plan_conflict");

        let (status, loaded) = request(
            &app,
            "/api/v1/travel/plans?city=%E6%9D%AD%E5%B7%9E&days=2&date_start=2026-10-01&date_end=2026-10-02",
        )
        .await;
        assert_eq!(status, StatusCode::OK, "body={loaded}");
        assert_eq!(loaded["context"]["city"], "杭州");
        assert_eq!(loaded["selected_keys"][0], "poi-west-lake");
        assert_eq!(loaded["assigned_days"]["poi-west-lake"], 2);
        assert_eq!(loaded["title"], "西湖慢行");
        assert_eq!(loaded["revision"], 2);

        let (status, recent) = request(&app, "/api/v1/travel/plans/recent?limit=5").await;
        assert_eq!(status, StatusCode::OK, "body={recent}");
        assert_eq!(recent[0]["context"]["city"], "杭州");
        assert_eq!(recent[0]["title"], "西湖慢行");

        let invalid = serde_json::json!({
            "plan": {
                "context": { "city": "杭州", "days": 2 },
                "selected_keys": ["poi-west-lake"],
                "assigned_days": { "poi-west-lake": 3 },
                "must_visit_keys": []
            }
        });
        let (status, body) = post_json(&app, "/api/v1/travel/plans", &invalid).await;
        assert_eq!(status, StatusCode::BAD_REQUEST, "body={body}");
        assert_eq!(body["code"], "travel_plan_invalid");
    }

    #[tokio::test]
    async fn independent_sessions_conflict_when_a_stale_edit_changes_trip_dates() {
        let app = test_router(false);
        let city = format!("Sprint4-CAS-{}", std::process::id());
        let base_uri = format!("/api/v1/travel/plans?city={city}&days=2");
        let initial = serde_json::json!({
            "context": { "city": city, "days": 2, "date_range": null },
            "selected_keys": [],
            "assigned_days": {},
            "must_visit_keys": [],
            "notes": "两会话冲突场景"
        });
        let (status, created) = post_json(
            &app,
            "/api/v1/travel/plans",
            &serde_json::json!({ "plan": initial }),
        )
        .await;
        assert_eq!(status, StatusCode::OK, "{created}");

        // 两个独立 HTTP 客户端读取同一个 revision；B 的提交用 oneshot 明确延后，
        // 不用 sleep 或计时假设来构造竞态。
        let session_a = app.clone();
        let session_b = app.clone();
        let (status, revision_a) = request(&session_a, &base_uri).await;
        assert_eq!(status, StatusCode::OK, "{revision_a}");
        let (status, revision_b) = request(&session_b, &base_uri).await;
        assert_eq!(status, StatusCode::OK, "{revision_b}");
        assert_eq!(revision_a["revision"], revision_b["revision"]);
        assert_eq!(revision_a["revision"], 1);

        let (release_b, wait_for_a) = tokio::sync::oneshot::channel::<()>();
        let session_b_uri = "/api/v1/travel/plans".to_string();
        let mut date_edit = revision_b.clone();
        date_edit["context"]["date_range"] = serde_json::json!({
            "start": "2026-10-03",
            "end": "2026-10-04"
        });
        let session_b_task = tokio::spawn(async move {
            let _ = wait_for_a.await;
            post_json(
                &session_b,
                &session_b_uri,
                &serde_json::json!({ "plan": date_edit }),
            )
            .await
        });

        let mut place_edit = revision_a.clone();
        place_edit["selected_keys"] = serde_json::json!(["poi-session-a"]);
        place_edit["assigned_days"] = serde_json::json!({ "poi-session-a": 1 });
        let (status, saved_a) = post_json(
            &session_a,
            "/api/v1/travel/plans",
            &serde_json::json!({ "plan": place_edit }),
        )
        .await;
        assert_eq!(status, StatusCode::OK, "{saved_a}");
        assert_eq!(saved_a["revision"], 2);
        release_b.send(()).expect("release delayed session B");

        let (status, conflict) = session_b_task.await.expect("session B completed");
        assert_eq!(status, StatusCode::CONFLICT, "{conflict}");
        assert_eq!(conflict["code"], "travel_plan_conflict");

        let (status, reloaded_a) = request(&app, &base_uri).await;
        assert_eq!(status, StatusCode::OK, "{reloaded_a}");
        assert_eq!(reloaded_a["selected_keys"][0], "poi-session-a");
        assert_eq!(reloaded_a["revision"], 2);
        let (status, unsaved_b_context) = request(
            &app,
            &format!(
                "/api/v1/travel/plans?city={city}&days=2&date_start=2026-10-03&date_end=2026-10-04"
            ),
        )
        .await;
        assert_eq!(status, StatusCode::OK);
        assert!(
            unsaved_b_context.is_null(),
            "conflicted date edit is not saved: {unsaved_b_context}"
        );
    }

    #[tokio::test]
    async fn travel_write_rejects_request_bodies_over_one_megabyte() {
        let app = test_router(false);
        let response = app
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/travel/plans")
                    .header("host", "127.0.0.1:8080")
                    .header("origin", "http://127.0.0.1:1420")
                    .header("content-type", "application/json")
                    .body(axum::body::Body::from(vec![b' '; 1024 * 1024 + 1]))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::PAYLOAD_TOO_LARGE);
    }

    /// 契约护栏：Learning OS 的端点必须全部注册。
    /// 少注册一个，网页端 Collections / Graph / Review Center / Home 今日面板就是空的。
    #[test]
    fn learning_endpoints_are_registered() {
        let router = test_router(false);
        let source = include_str!("routes.rs");
        for path in [
            "/api/v1/learning/progress",
            "/api/v1/learning/review/queue",
            "/api/v1/learning/review/stats",
            "/api/v1/learning/review",
            "/api/v1/learning/today",
            "/api/v1/learning/graph",
            "/api/v1/learning/explore",
            "/api/v1/learning/collections",
        ] {
            assert!(source.contains(path), "Learning 路由未注册：{path}");
        }
        let _ = router;
    }

    #[tokio::test]
    async fn collections_round_trip_over_http() {
        let app = test_router(false);

        let (status, before) = request(&app, "/api/v1/learning/collections").await;
        assert_eq!(status, StatusCode::OK);
        let start = before.as_array().map_or(0, Vec::len);

        let (status, created) = post_json(
            &app,
            "/api/v1/learning/collections",
            &serde_json::json!({ "title": "验收合集", "tags": ["测试"] }),
        )
        .await;
        assert_eq!(status, StatusCode::OK, "创建失败：{created}");
        let id = created["id"].as_str().expect("id").to_string();

        // 重新读回：验证真的落库，而不是只回显请求
        let (_, after) = request(&app, "/api/v1/learning/collections").await;
        let items = after.as_array().expect("array");
        assert_eq!(items.len(), start + 1);
        assert!(
            items.iter().any(|c| c["id"] == id),
            "新建的合集应出现在列表里"
        );

        // 删除
        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("DELETE")
                    .uri(format!("/api/v1/learning/collections/{id}"))
                    .header("host", "127.0.0.1:8080")
                    .header("origin", "http://127.0.0.1:1420")
                    .body(axum::body::Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::OK);

        let (_, final_state) = request(&app, "/api/v1/learning/collections").await;
        assert_eq!(
            final_state.as_array().map_or(0, Vec::len),
            start,
            "删除后应恢复原状"
        );
    }

    #[tokio::test]
    async fn global_search_finds_saved_note_and_returns_the_original_history_target() {
        let app = test_router(false);
        let marker = format!("sprint6-history-note-{}", std::process::id());
        let (status, collection) = post_json(
            &app,
            "/api/v1/learning/collections",
            &serde_json::json!({ "title": "地理与安史之乱" }),
        )
        .await;
        assert_eq!(status, StatusCode::OK, "{collection}");
        let collection_id = collection["id"].as_str().expect("collection id");

        let (status, saved) = post_json(
            &app,
            &format!("/api/v1/learning/collections/{collection_id}/items"),
            &serde_json::json!({
                "module": "history",
                "entityType": "event",
                "entityId": "event-anlu-luoyang",
                "title": "安史之乱攻陷洛阳",
                "note": format!("{marker}: 洛阳作为唐代东都的背景线索"),
            }),
        )
        .await;
        assert_eq!(status, StatusCode::OK, "{saved}");

        let (status, result) = request(
            &app,
            &format!("/api/v1/search/global?query={marker}&limit=8"),
        )
        .await;
        assert_eq!(status, StatusCode::OK, "{result}");
        let hit = result["hits"]
            .as_array()
            .expect("hits")
            .iter()
            .find(|hit| hit["source"] == "collections")
            .expect("saved note should be searchable");
        assert!(
            hit["snippet"]
                .as_str()
                .unwrap_or_default()
                .contains(&marker)
        );
        assert_eq!(hit["action_target"]["module"], "history");
        assert_eq!(hit["action_target"]["kind"], "event");
        assert_eq!(hit["action_target"]["id"], "event-anlu-luoyang");
        assert_eq!(hit["action_target"]["collection_item_id"], saved["id"]);

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("DELETE")
                    .uri(format!("/api/v1/learning/collections/{collection_id}"))
                    .header("host", "127.0.0.1:8080")
                    .header("origin", "http://127.0.0.1:1420")
                    .body(axum::body::Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::OK);
    }

    #[tokio::test]
    async fn empty_collection_title_is_rejected() {
        let app = test_router(false);
        let (status, body) = post_json(
            &app,
            "/api/v1/learning/collections",
            &serde_json::json!({ "title": "   " }),
        )
        .await;
        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert_eq!(body["code"], "invalid");
    }

    #[tokio::test]
    async fn geography_search_reads_real_database() {
        let app = test_router(false);
        // 搜一个真实库里存在的实体名：命中即证明走的是 geography.db，
        // 而不是前端那份 12 条硬编码示例。
        let (status, body) = request(
            &app,
            "/api/v1/geography/search?query=%E4%B8%8A%E6%B5%B7&limit=5",
        )
        .await;
        assert_eq!(status, StatusCode::OK);
        let groups = body.as_array().expect("groups array");
        assert!(!groups.is_empty(), "上海应当能搜到");
        assert!(
            groups
                .iter()
                .any(|g| g["items"].as_array().is_some_and(|items| !items.is_empty())),
            "至少要有一个分组带条目"
        );
    }

    #[tokio::test]
    async fn exploration_location_uses_reviewed_crosswalk_and_real_history_data() {
        let history = Arc::new(HistoryService::new(Box::new(
            devtoolbox_runtime::history_query::HistoryQueryAdapter::new(Arc::clone(
                &test_core().history_repo,
            )),
        )));
        let app = test_router_with_history(history);
        let (status, body) = request(&app, "/api/v1/exploration/geography/chengdu/history").await;
        assert_eq!(status, StatusCode::OK, "{body}");
        assert_eq!(body["geography"]["entity"]["id"], "chengdu");
        assert_eq!(body["crosswalk"]["history_place_id"], "cbdb-place-406333");
        assert_eq!(body["crosswalk"]["status"], "reviewed");
        assert_eq!(body["crosswalks"].as_array().map(Vec::len), Some(1));
        assert_eq!(body["crosswalk"]["evidence_time_scope"]["start_year"], 756);
        let events = body["events"].as_array().expect("event list");
        assert!(
            events.iter().any(|event| {
                event["event"]["id"] == "event-anlu-xuanzong-shu"
                    && event["event"]["quality_status"] == "reviewed"
                    && event["places"].as_array().is_some_and(|places| {
                        places.iter().any(|place| {
                            place["place_id"] == "cbdb-place-406333"
                                && place["link_status"] == "linked"
                                && place["link_quality_status"] == "reviewed"
                        })
                    })
            }),
            "expected source-backed 唐玄宗入蜀 event: {body}"
        );

        let (status, reverse) = request(
            &app,
            "/api/v1/exploration/history-places/cbdb-place-406333/geography",
        )
        .await;
        assert_eq!(status, StatusCode::OK, "{reverse}");
        assert_eq!(reverse["entity"]["id"], "chengdu");

        let (status, luoyang) =
            request(&app, "/api/v1/exploration/geography/luoyang/history").await;
        assert_eq!(status, StatusCode::OK, "{luoyang}");
        assert_eq!(luoyang["crosswalk"]["history_place_id"], "cbdb-place-14693");
        assert_eq!(
            luoyang["crosswalk"]["relation_type"],
            "modern_urban_area_anchor"
        );
        let luoyang_event = luoyang["events"]
            .as_array()
            .unwrap()
            .iter()
            .find(|event| {
                event["event"]["id"] == "event-anlu-luoyang"
                    && event["event"]["start_year"] == 756
                    && event["event"]["quality_status"] == "reviewed"
            })
            .expect("reviewed 756 event, not a place ID rendered as a year");
        assert_eq!(
            luoyang_event["related_stories"][0]["story"]["id"],
            "story-an-lushan-rebellion"
        );
        assert_eq!(
            luoyang_event["related_stories"][0]["link_quality_status"],
            "reviewed"
        );
        assert_eq!(luoyang_event["related_stories"][0]["story"]["usable"], true);
        let (status, reverse_luoyang) = request(
            &app,
            "/api/v1/exploration/history-places/cbdb-place-14693/geography",
        )
        .await;
        assert_eq!(status, StatusCode::OK, "{reverse_luoyang}");
        assert_eq!(reverse_luoyang["entity"]["id"], "luoyang");
    }

    #[tokio::test]
    async fn exploration_unmapped_geography_has_a_real_empty_state() {
        let app = test_router(false);
        let (status, body) = request(&app, "/api/v1/exploration/geography/shanghai/history").await;
        assert_eq!(status, StatusCode::OK, "{body}");
        assert_eq!(body["crosswalk"], Value::Null);
        assert_eq!(body["crosswalks"].as_array().map(Vec::len), Some(0));
        assert_eq!(body["events"].as_array().map(Vec::len), Some(0));

        // A river is not implicitly linked to the similarly named historic city, and
        // a rejected ambiguous History ID remains absent from the reverse index.
        let (status, river) = request(&app, "/api/v1/exploration/geography/yangtze/history").await;
        assert_eq!(status, StatusCode::OK, "{river}");
        assert_eq!(river["crosswalk"], Value::Null);
        let (status, ambiguous) = request(
            &app,
            "/api/v1/exploration/history-places/cbdb-place-100409/geography",
        )
        .await;
        assert_eq!(status, StatusCode::OK);
        assert_eq!(ambiguous, Value::Null);

        let unavailable_history = test_router(true);
        let (status, unavailable) = request(
            &unavailable_history,
            "/api/v1/exploration/geography/chengdu/history",
        )
        .await;
        assert!(
            status.is_server_error(),
            "source outage must not look like empty data: {unavailable}"
        );
    }

    #[tokio::test]
    async fn geography_search_empty_query_returns_empty_not_error() {
        let app = test_router(false);
        // 空白 query 不该 400 —— 前端在用户清空输入框时会正常发请求。
        let (status, body) = request(&app, "/api/v1/geography/search?query=%20%20").await;
        assert_eq!(status, StatusCode::OK);
        assert_eq!(body.as_array().map_or(0, Vec::len), 0);
    }

    #[tokio::test]
    async fn geography_search_unknown_type_is_rejected() {
        let app = test_router(false);
        // 静默忽略未知类型会让「筛选没生效」伪装成「搜不到」，必须 400。
        let (status, body) =
            request(&app, "/api/v1/geography/search?query=x&entity_type=banana").await;
        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert_eq!(body["code"], "invalid");
    }

    #[tokio::test]
    async fn geography_detail_unknown_id_is_404() {
        let app = test_router(false);
        let (status, _) = request(&app, "/api/v1/geography/entities/definitely-not-a-place").await;
        assert_eq!(status, StatusCode::NOT_FOUND);
    }

    /// 请求体键必须是驼峰（与前端 transport 的参数约定一致），
    /// 否则每个写操作都会 422。
    #[tokio::test]
    async fn study_accepts_camel_case_body() {
        let app = test_router(false);
        let (status, body) = post_json(
            &app,
            "/api/v1/language/study",
            &serde_json::json!({ "entityId": "jmdict:nope", "action": "study" }),
        )
        .await;
        // id 不存在 → 404（说明**成功反序列化**了请求体，否则会是 422）
        assert_eq!(status, StatusCode::NOT_FOUND, "body={body}");
        assert_eq!(body["code"], "not_found");
    }

    #[tokio::test]
    async fn study_rejects_unknown_language_code() {
        let app = test_router(false);
        let (status, _) = get_query(&app, "/api/v1/language/study-queue?language=klingon").await;
        assert_eq!(status, StatusCode::BAD_REQUEST);
    }

    #[tokio::test]
    async fn language_item_unknown_id_returns_not_found() {
        let app = test_router(false);
        let (status, body) = request(&app, "/api/v1/language/items/nope").await;
        assert_eq!(status, StatusCode::NOT_FOUND);
        assert_eq!(body["code"], "not_found");
    }

    async fn post_json(app: &axum::Router, uri: &str, payload: &Value) -> (StatusCode, Value) {
        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(uri)
                    .header("host", "127.0.0.1:8080")
                    .header("origin", "http://127.0.0.1:1420")
                    .header("content-type", "application/json")
                    .body(axum::body::Body::from(payload.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        let status = response.status();
        let body = to_bytes(response.into_body(), 1 << 20).await.unwrap();
        (status, serde_json::from_slice(&body).unwrap_or(Value::Null))
    }

    async fn get_query(app: &axum::Router, uri: &str) -> (StatusCode, Value) {
        request(app, uri).await
    }

    async fn request(app: &axum::Router, uri: &str) -> (StatusCode, Value) {
        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri(uri)
                    .header("host", "127.0.0.1:8080")
                    .body(axum::body::Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        let status = response.status();
        let body = to_bytes(response.into_body(), 1 << 20).await.unwrap();
        let value: Value = serde_json::from_slice(&body).unwrap_or(Value::Null);
        (status, value)
    }

    #[tokio::test]
    async fn health_ok() {
        let (status, body) = request(&test_router(false), "/health").await;
        assert_eq!(status, StatusCode::OK);
        assert_eq!(body, serde_json::json!({ "status": "ok" }));
    }

    #[tokio::test]
    async fn home_returns_semantic_home_shape() {
        let (status, body) = request(&test_router(false), "/api/v1/history/home").await;
        assert_eq!(status, StatusCode::OK);
        assert!(body.get("periods").unwrap().is_array());
        assert!(body.get("stories").unwrap().is_array());
        assert!(body.get("stats").unwrap().is_object());
    }

    #[tokio::test]
    async fn search_with_query_ok() {
        let (status, body) =
            request(&test_router(false), "/api/v1/history/search?q=%E5%B8%9D").await;
        assert_eq!(status, StatusCode::OK);
        assert!(body.is_array());
    }

    #[tokio::test]
    async fn search_missing_q_is_400_error_contract() {
        let (status, body) = request(&test_router(false), "/api/v1/history/search").await;
        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert_eq!(body["code"], "history_error");
        assert!(body["message"].is_string());
    }

    #[tokio::test]
    async fn detail_endpoints_404_with_error_contract() {
        for path in [
            "/api/v1/history/periods/missing",
            "/api/v1/history/events/missing",
            "/api/v1/history/people/missing",
            "/api/v1/history/works/missing",
            "/api/v1/history/stories/missing",
        ] {
            let (status, body) = request(&test_router(false), path).await;
            assert_eq!(status, StatusCode::NOT_FOUND, "{path}");
            assert_eq!(body["code"], "history_error", "{path}");
            assert!(
                body["message"].as_str().unwrap().contains("not found"),
                "{path}"
            );
        }
    }

    #[tokio::test]
    async fn failing_query_returns_500_error_contract() {
        let (status, body) = request(&test_router(true), "/api/v1/history/home").await;
        assert_eq!(status, StatusCode::INTERNAL_SERVER_ERROR);
        assert_eq!(body["code"], "history_error");
        assert!(body["message"].is_string());
    }

    // ---- 26 周能力路线图（V13 W6）：不达标就说没达标 ----

    #[tokio::test]
    async fn roadmap_returns_real_plan_and_never_invents_a_start_date() {
        let app = test_router(false);
        let (status, body) = request(&app, "/api/v1/english/roadmap").await;
        assert_eq!(status, StatusCode::OK, "{body}");
        // 计划完整（至少 8 个检查点，覆盖到第 26 周）。
        let checkpoints = body["checkpoints"].as_array().expect("checkpoints");
        assert!(checkpoints.len() >= 8, "{body}");
        assert_eq!(checkpoints.last().unwrap()["week"], 26);
        // 每个检查项都带 current/threshold，判定必须与数字一致。
        for checkpoint in checkpoints {
            let week = checkpoint["week"].as_u64().unwrap_or(0);
            for check in checkpoint["checks"].as_array().expect("checks") {
                let current = check["current"].as_u64().unwrap_or(0);
                let threshold = check["threshold"].as_u64().unwrap_or(0);
                assert!(threshold > 0, "第 {week} 周的检查项必须有阈值：{check}");
                let met = check["met"].as_bool().unwrap_or(false);
                if check["auto"].as_bool().unwrap_or(false) {
                    assert_eq!(
                        met,
                        current >= threshold,
                        "第 {week} 周：判定与数值不一致 {check}"
                    );
                } else {
                    assert!(!met, "自评项不能自动判达标：{check}");
                }
            }
        }
        // 指标字段齐全（界面要显示数字来源）。
        for field in [
            "lessons_completed",
            "spoken_minutes",
            "review_mastery",
            "sentence_cards",
            "words_learned",
            "streak_days",
        ] {
            assert!(
                body["metrics"].get(field).is_some(),
                "缺少指标 {field}: {body}"
            );
        }
    }

    // ---- 句子挖掘（V13 W3）：读过的句子进 SRS ----

    #[tokio::test]
    async fn mining_preview_does_not_write_cards_but_add_does() {
        let app = test_router(false);
        let lesson_id = shadow_lesson_id("950");

        // 预览是只读的：这一步不能让复习队列多出卡片。
        let (status, preview) = request(
            &app,
            &format!("/api/v1/language/mining/lesson/{lesson_id}?maxPerKind=2"),
        )
        .await;
        assert_eq!(status, StatusCode::OK, "{preview}");
        let items = preview["items"].as_array().expect("items").clone();
        assert!(!items.is_empty(), "播种的课文应能挖出卡：{preview}");
        assert!(
            items.len() <= 6,
            "maxPerKind=2 → 三种卡最多 6 张：{preview}"
        );
        // 填空卡的题干必须真的挖了空，答案与原因都可解释。
        let cloze = items
            .iter()
            .find(|item| item["kind"] == "cloze")
            .expect("应有填空卡");
        assert!(
            cloze["prompt"]
                .as_str()
                .unwrap_or_default()
                .contains("_____"),
            "{cloze}"
        );
        assert!(!cloze["answer"].as_str().unwrap_or_default().is_empty());
        assert!(cloze["reason"].is_string(), "挖空理由必须可解释");
        // 原文完整保留（复习时要看到语境）。
        assert!(cloze["sentence"].as_str().unwrap_or_default().contains(' '));

        // 入库：写进平台 SRS，且重复调用不产生重复卡。
        let (status, report) = post_query(
            &app,
            &format!("/api/v1/language/mining/lesson/{lesson_id}?maxPerKind=2"),
        )
        .await;
        assert_eq!(status, StatusCode::OK, "{report}");
        let first = report["cards"].as_u64().expect("cards");
        assert_eq!(first, items.len() as u64, "入库数量 = 预览数量");

        let (_, again) = post_query(
            &app,
            &format!("/api/v1/language/mining/lesson/{lesson_id}?maxPerKind=2"),
        )
        .await;
        assert_eq!(
            again["cards"].as_u64(),
            Some(first),
            "重复挖掘幂等（id 内容派生，不重复计数）"
        );
    }

    #[tokio::test]
    async fn mining_of_lesson_without_sentences_is_empty_not_error() {
        let app = test_router(false);
        let (status, body) = request(
            &app,
            "/api/v1/language/mining/lesson/nce:9:999?maxPerKind=3",
        )
        .await;
        assert_eq!(status, StatusCode::OK, "{body}");
        assert_eq!(body["count"], 0, "没有句子就是 0 张，不硬凑");
        assert_eq!(body["items"].as_array().map(Vec::len), Some(0));
    }

    /// POST 但没有请求体（挖掘端点用 query 传参）。
    async fn post_query(app: &axum::Router, uri: &str) -> (StatusCode, Value) {
        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(uri)
                    .header("host", "127.0.0.1:8080")
                    .header("origin", "http://127.0.0.1:1420")
                    .body(axum::body::Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        let status = response.status();
        let body = to_bytes(response.into_body(), 1 << 20).await.unwrap();
        (status, serde_json::from_slice(&body).unwrap_or(Value::Null))
    }

    // ---- 跟读发音评分（V13 W2）：没有转写就没有分数 ----

    /// 播种一课并返回 lesson id。
    ///
    /// **按用例隔离**：共用同一课时，统计类断言会被并行用例互相污染
    /// （这条是踩过的坑：A 用例写了记录，B 用例断言 attempts == 1 却拿到 3）。
    fn shadow_lesson_id(tag: &str) -> String {
        seed_shadow_lesson(tag)
    }

    #[tokio::test]
    async fn shadow_score_rejects_empty_transcript_without_writing_anything() {
        let app = test_router(false);
        // 统计必须**按本课**看：用全局统计会被并行用例的记录污染
        // （踩过一次：A 用例写记录，B 用例断言 attempts 没变却看到 3）。
        let lesson_id = shadow_lesson_id("902");
        let before = stats_of(&app, Some(&lesson_id)).await;
        let (status, body) = post_json(
            &app,
            "/api/v1/language/shadow/score",
            &serde_json::json!({
                "lessonId": lesson_id,
                "sentenceSeq": 0,
                "transcript": "   ",
                "durationMs": 1200,
            }),
        )
        .await;
        assert_eq!(status, StatusCode::BAD_REQUEST, "{body}");
        assert_eq!(body["code"], "language_shadow_empty_transcript");
        let after = stats_of(&app, Some(&lesson_id)).await;
        assert_eq!(before, after, "被拒绝的请求不能留下任何记录");
    }

    #[tokio::test]
    async fn shadow_score_of_unknown_sentence_is_400_not_zero_score() {
        let app = test_router(false);
        let (status, body) = post_json(
            &app,
            "/api/v1/language/shadow/score",
            &serde_json::json!({
                "lessonId": shadow_lesson_id("903"),
                "sentenceSeq": 9_999,
                "transcript": "hello there",
                "durationMs": 900,
            }),
        )
        .await;
        assert_eq!(status, StatusCode::BAD_REQUEST, "{body}");
        assert_eq!(body["code"], "language_shadow_no_sentence", "{body}");
        assert!(
            body["message"].as_str().unwrap().contains("没有第 9999 句"),
            "{body}"
        );
    }

    #[tokio::test]
    async fn shadow_score_uses_server_side_target_and_returns_word_diff() {
        let app = test_router(false);
        let lesson_id = shadow_lesson_id("900");
        // 目标句是库里的 "Excuse me! Yes?"；这里故意只说第一个词。
        let (status, body) = post_json(
            &app,
            "/api/v1/language/shadow/score",
            &serde_json::json!({
                "lessonId": lesson_id,
                "sentenceSeq": 0,
                "transcript": "excuse",
                "durationMs": 4_000,
                "targetMs": 1_500,
            }),
        )
        .await;
        assert_eq!(status, StatusCode::OK, "{body}");
        assert_eq!(
            body["target"], "Excuse me! Yes?",
            "目标句必须来自服务端（不接受前端自报）"
        );
        assert!(
            body["completeness"].as_u64().unwrap() < 100,
            "只说一个词不该满分"
        );
        assert!(
            body["missing"]
                .as_array()
                .map(|list| !list.is_empty())
                .unwrap_or(false),
            "应当指出漏说的词：{body}"
        );
        // 说全了：完整度 100，逐词对上。
        let (status, full) = post_json(
            &app,
            "/api/v1/language/shadow/score",
            &serde_json::json!({
                "lessonId": lesson_id,
                "sentenceSeq": 0,
                "transcript": "Excuse me yes",
                "durationMs": 1_100,
                "targetMs": 1_200,
            }),
        )
        .await;
        assert_eq!(status, StatusCode::OK, "{full}");
        assert_eq!(full["completeness"], 100, "{full}");
        assert_eq!(full["accuracy"], 100, "{full}");
        assert!(full["missing"].as_array().expect("missing").is_empty());
    }

    #[tokio::test]
    async fn shadow_stats_counts_spoken_seconds_and_strong_attempts() {
        let app = test_router(false);
        let lesson_id = shadow_lesson_id("901");
        post_json(
            &app,
            "/api/v1/language/shadow/score",
            &serde_json::json!({
                "lessonId": lesson_id,
                "sentenceSeq": 0,
                "transcript": "Excuse me yes",
                "durationMs": 2_000,
                "targetMs": 1_200,
            }),
        )
        .await;
        let stats = stats_of(&app, Some(&lesson_id)).await;
        assert_eq!(stats["attempts"], 1, "{stats}");
        assert_eq!(stats["spoken_seconds"], 2, "开口秒数进账：{stats}");
        assert_eq!(stats["strong_attempts"], 1, "说得不错：{stats}");
        assert_eq!(stats["avg_completeness"], 100, "{stats}");
    }

    /// 读跟读统计（`lessonId` 为空 = 全部）。
    async fn stats_of(app: &axum::Router, lesson_id: Option<&str>) -> Value {
        let uri = match lesson_id {
            Some(id) => format!("/api/v1/language/shadow/stats?lessonId={id}"),
            None => "/api/v1/language/shadow/stats".to_string(),
        };
        let (status, body) = request(app, &uri).await;
        assert_eq!(status, StatusCode::OK, "{body}");
        body
    }

    #[tokio::test]
    async fn unknown_route_is_404() {
        let (status, _) = request(&test_router(false), "/api/v1/history/charts").await;
        assert_eq!(status, StatusCode::NOT_FOUND);
    }

    // ---- 学习板：网页端画的板与桌面端 / AI 是同一块 ----

    /// 每轮用独立 id，避免与共享测试运行时里的其它用例互相覆盖。
    fn board_id(tag: &str) -> String {
        format!("b-test-{tag}-{}", std::process::id())
    }

    #[tokio::test]
    async fn study_board_save_then_list_then_get_round_trips_strokes() {
        let app = test_router(false);
        let id = board_id("roundtrip");
        let strokes = serde_json::json!({
            "strokes": [{"color": "#000", "width": 3, "points": [0, 0, 10, 10]}]
        });

        let (status, body) = post_json(
            &app,
            "/api/v1/study-boards",
            &serde_json::json!({
                "board_id": id,
                "title": "网页端画的板",
                "strokes": strokes,
                "module_origin": "study-board",
            }),
        )
        .await;
        assert_eq!(status, StatusCode::OK, "{body}");
        assert_eq!(body["created"], true);
        assert_eq!(body["board"]["strokes"], strokes, "笔迹原样存取");
        assert_eq!(body["board"]["title"], "网页端画的板");

        // 列表里只有元数据（不含笔迹正文）。
        let (status, list) = request(&app, "/api/v1/study-boards?limit=200").await;
        assert_eq!(status, StatusCode::OK);
        let items = list.as_array().expect("array");
        let item = items
            .iter()
            .find(|item| item["id"] == id.as_str())
            .expect("新建的板在列表里");
        assert_eq!(item["title"], "网页端画的板");
        assert_eq!(item["stroke_count"], 1);
        assert!(item.get("strokes").is_none(), "列表不得回传笔迹正文");

        // 读回：笔迹一致（浏览器刷新后能接着画）。
        let (status, board) = request(&app, &format!("/api/v1/study-boards/{id}")).await;
        assert_eq!(status, StatusCode::OK);
        assert_eq!(board["strokes"], strokes);
    }

    #[tokio::test]
    async fn study_board_save_is_idempotent_and_keeps_untouched_fields() {
        let app = test_router(false);
        let id = board_id("idempotent");
        post_json(
            &app,
            "/api/v1/study-boards",
            &serde_json::json!({
                "board_id": id,
                "title": "初稿",
                "strokes": {"strokes": [{"points": [1, 1]}]},
            }),
        )
        .await;
        // 只改标题：笔迹保留，且不新增第二块板。
        let (status, body) = post_json(
            &app,
            "/api/v1/study-boards",
            &serde_json::json!({"board_id": id, "title": "定稿"}),
        )
        .await;
        assert_eq!(status, StatusCode::OK, "{body}");
        assert_eq!(body["created"], false);
        assert_eq!(body["board"]["title"], "定稿");
        assert_eq!(
            body["board"]["strokes"],
            serde_json::json!({"strokes": [{"points": [1, 1]}]}),
            "未给笔迹时保留原笔迹"
        );
    }

    #[tokio::test]
    async fn study_board_unknown_id_is_404_and_injection_shaped_id_is_400() {
        let app = test_router(false);
        let (status, body) = request(&app, "/api/v1/study-boards/b-none").await;
        assert_eq!(status, StatusCode::NOT_FOUND);
        assert_eq!(body["code"], "not_found");

        let (status, body) = post_json(
            &app,
            "/api/v1/study-boards",
            &serde_json::json!({"board_id": "../etc/passwd", "title": "x"}),
        )
        .await;
        assert_eq!(status, StatusCode::BAD_REQUEST, "{body}");
        assert_eq!(body["code"], "invalid");
    }

    #[tokio::test]
    async fn study_board_new_without_title_is_400_not_silent_ghost() {
        let app = test_router(false);
        let (status, body) = post_json(
            &app,
            "/api/v1/study-boards",
            &serde_json::json!({
                "board_id": board_id("no-title"),
                "strokes": {"strokes": []},
            }),
        )
        .await;
        assert_eq!(status, StatusCode::BAD_REQUEST, "{body}");
        assert!(body["message"].as_str().unwrap().contains("必须提供 title"));
    }

    #[tokio::test]
    async fn study_board_snapshot_registers_reference_for_saved_board() {
        let app = test_router(false);
        let id = board_id("snapshot");
        post_json(
            &app,
            "/api/v1/study-boards",
            &serde_json::json!({
                "board_id": id,
                "title": "快照板",
                "strokes": {"strokes": [{"points": [1, 2], "color": "#f00"}]},
            }),
        )
        .await;
        let (status, body) = post_json(
            &app,
            &format!("/api/v1/study-boards/{id}/snapshots"),
            &serde_json::json!({}),
        )
        .await;
        assert_eq!(status, StatusCode::OK, "{body}");
        assert_eq!(body["board_id"], id.as_str());
        assert_eq!(body["has_png"], false);
        assert!(
            !body["strokes_summary"].as_str().unwrap().contains("1, 2"),
            "摘要不得含坐标"
        );

        // 未保存的板不能登记快照。
        let (status, _) = post_json(
            &app,
            &format!("/api/v1/study-boards/{}/snapshots", board_id("ghost")),
            &serde_json::json!({}),
        )
        .await;
        assert_eq!(status, StatusCode::NOT_FOUND);
    }
}
